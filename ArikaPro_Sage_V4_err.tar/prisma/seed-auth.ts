import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('Starting auth seed...')

  // Create admin users
  const users = [
    {
      email: 'admin@arika.com',
      password: 'admin123', // In production, hash this!
      name: 'Super Admin',
      role: 'super_admin',
    },
    {
      email: 'frontdesk@arika.com',
      password: 'frontdesk123', // In production, hash this!
      name: 'Front Desk Staff',
      role: 'admin',
    },
    {
      email: 'housekeeping@arika.com',
      password: 'housekeeping123', // In production, hash this!
      name: 'Housekeeping Staff',
      role: 'housekeeping',
    },
  ]

  for (const userData of users) {
    const existingUser = await prisma.user.findUnique({
      where: { email: userData.email }
    })

    if (existingUser) {
      console.log(`User ${userData.email} already exists, skipping...`)
      continue
    }

    const user = await prisma.user.create({
      data: userData
    })

    console.log(`Created user: ${user.email} (${user.role})`)
  }

  console.log('Auth seed completed!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
