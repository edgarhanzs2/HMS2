import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('Starting seed...')

  // Clean existing data
  await prisma.booking.deleteMany()
  await prisma.guest.deleteMany()
  await prisma.room.deleteMany()

  // Create rooms
  const rooms = await Promise.all([
    prisma.room.create({
      data: {
        roomNumber: '101',
        type: 'Standard',
        price: 500000,
        status: 'Available',
        description: 'Kamar standar dengan view taman yang asri',
      },
    }),
    prisma.room.create({
      data: {
        roomNumber: '102',
        type: 'Standard',
        price: 500000,
        status: 'Available',
        description: 'Kamar standar dengan view kolam renang',
      },
    }),
    prisma.room.create({
      data: {
        roomNumber: '103',
        type: 'Standard',
        price: 500000,
        status: 'Available',
        description: 'Kamar standar nyaman dengan fasilitas lengkap',
      },
    }),
    prisma.room.create({
      data: {
        roomNumber: '201',
        type: 'Deluxe',
        price: 850000,
        status: 'Available',
        description: 'Kamar deluxe dengan balkon dan view kota',
      },
    }),
    prisma.room.create({
      data: {
        roomNumber: '202',
        type: 'Deluxe',
        price: 850000,
        status: 'Available',
        description: 'Kamar deluxe dengan balkon dan view gunung',
      },
    }),
    prisma.room.create({
      data: {
        roomNumber: '301',
        type: 'Suite',
        price: 1500000,
        status: 'Available',
        description: 'Suite premium dengan ruang tamu terpisah',
      },
    }),
    prisma.room.create({
      data: {
        roomNumber: '302',
        type: 'Suite',
        price: 1500000,
        status: 'Available',
        description: 'Suite premium dengan jacuzzi',
      },
    }),
    prisma.room.create({
      data: {
        roomNumber: '401',
        type: 'Presidential',
        price: 2500000,
        status: 'Maintenance',
        description: 'Suite presidential dengan layanan khusus dan fasilitas VIP',
      },
    }),
  ])

  console.log(`Created ${rooms.length} rooms`)

  // Create guests
  const guests = await Promise.all([
    prisma.guest.create({
      data: {
        name: 'Ahmad Wijaya',
        email: 'ahmad@email.com',
        phone: '081234567890',
      },
    }),
    prisma.guest.create({
      data: {
        name: 'Siti Rahayu',
        email: 'siti@email.com',
        phone: '081234567891',
      },
    }),
    prisma.guest.create({
      data: {
        name: 'Budi Santoso',
        email: 'budi@email.com',
        phone: '081234567892',
      },
    }),
  ])

  console.log(`Created ${guests.length} guests`)

  // Create sample bookings
  const booking = await prisma.booking.create({
    data: {
      roomId: rooms[3].id, // 201
      guestId: guests[0].id,
      checkInDate: new Date('2024-01-15'),
      checkOutDate: new Date('2024-01-18'),
      totalCost: 2550000,
      status: 'Confirmed',
      specialRequests: 'Permintaan kamar di lantai tinggi',
    },
  })

  // Update room status to booked
  await prisma.room.update({
    where: { id: rooms[3].id },
    data: { status: 'Booked' },
  })

  console.log(`Created ${1} booking`)

  console.log('Seed completed!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
