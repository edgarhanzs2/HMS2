import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const bookings = await db.booking.findMany({
      include: {
        room: true,
        guest: true
      },
      orderBy: { createdAt: 'desc' }
    })
    return NextResponse.json(bookings)
  } catch (error) {
    console.error('Error fetching bookings:', error)
    return NextResponse.json(
      { error: 'Failed to fetch bookings' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { roomId, guestName, guestEmail, guestPhone, checkInDate, checkOutDate, specialRequests } = body

    if (!roomId || !guestName || !guestEmail || !guestPhone || !checkInDate || !checkOutDate) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Find or create guest
    let guest = await db.guest.findFirst({
      where: { email: guestEmail }
    })

    if (!guest) {
      guest = await db.guest.create({
        data: {
          name: guestName,
          email: guestEmail,
          phone: guestPhone
        }
      })
    } else {
      // Update existing guest info
      guest = await db.guest.update({
        where: { id: guest.id },
        data: {
          name: guestName,
          phone: guestPhone
        }
      })
    }

    // Get room to calculate price
    const room = await db.room.findUnique({
      where: { id: roomId }
    })

    if (!room) {
      return NextResponse.json(
        { error: 'Room not found' },
        { status: 404 }
      )
    }

    // Calculate total cost
    const checkIn = new Date(checkInDate)
    const checkOut = new Date(checkOutDate)
    const nights = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24))
    const totalCost = nights * room.price

    // Create booking
    const booking = await db.booking.create({
      data: {
        roomId,
        guestId: guest.id,
        checkInDate,
        checkOutDate,
        totalCost,
        status: 'Confirmed',
        specialRequests: specialRequests || ''
      }
    })

    // Update room status
    await db.room.update({
      where: { id: roomId },
      data: { status: 'Booked' }
    })

    return NextResponse.json({ ...booking, room, guest }, { status: 201 })
  } catch (error) {
    console.error('Error creating booking:', error)
    return NextResponse.json(
      { error: 'Failed to create booking' },
      { status: 500 }
    )
  }
}
