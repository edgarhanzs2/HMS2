
import React from 'react';

const Logo: React.FC<{ className?: string }> = ({ className = "w-8 h-8" }) => (
  <svg 
    viewBox="0 0 100 100" 
    className={className} 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    {/* House Shape */}
    <path 
      d="M50 15L15 45V85H85V45L50 15Z" 
      fill="#10b981" 
      stroke="#065f46" 
      strokeWidth="2"
    />
    {/* Chimney */}
    <path d="M65 25V35H75V25H65Z" fill="#059669" />
    {/* Leaves - Left Top */}
    <path 
      d="M20 20C25 15 35 15 35 25C35 35 25 35 20 30C15 25 15 20 20 20Z" 
      fill="#34d399" 
      stroke="#064e3b" 
      strokeWidth="1"
    />
    {/* Leaves - Right Top */}
    <path 
      d="M80 20C75 15 65 15 65 25C65 35 75 35 80 30C85 25 85 20 80 20Z" 
      fill="#34d399" 
      stroke="#064e3b" 
      strokeWidth="1"
    />
    {/* Leaves - Left Bottom */}
    <path 
      d="M10 50C10 40 20 35 25 45C30 55 20 65 15 60C10 55 5 50 10 50Z" 
      fill="#6ee7b7" 
      stroke="#064e3b" 
      strokeWidth="1"
    />
    {/* Leaves - Right Bottom */}
    <path 
      d="M90 50C90 40 80 35 75 45C70 55 80 65 85 60C90 55 95 50 90 50Z" 
      fill="#6ee7b7" 
      stroke="#064e3b" 
      strokeWidth="1"
    />
    {/* Door */}
    <rect x="42" y="60" width="16" height="25" fill="#064e3b" rx="2" />
  </svg>
);

export default Logo;
