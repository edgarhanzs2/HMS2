
import React from 'react';
import { LayoutDashboard, BedDouble, CalendarCheck, Settings, LogOut, Menu, X, Users, History } from 'lucide-react';
import { User } from '../types';
import Logo from './Logo';

interface LayoutProps {
  children: React.ReactNode;
  isAdmin: boolean;
  currentUser: User | null;
  onViewToggle: () => void;
  currentPath: string;
  onNavigate: (path: string) => void;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, isAdmin, currentUser, onViewToggle, currentPath, onNavigate, onLogout }) => {
  const [isSidebarOpen, setSidebarOpen] = React.useState(true);

  if (!isAdmin || currentPath === 'admin-login') {
    return (
      <div className="min-h-screen flex flex-col">
        {currentPath !== 'admin-login' && (
          <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
              <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onNavigate('home')}>
                <Logo className="w-12 h-12" />
                <div className="flex flex-col">
                  <span className="text-xl font-bold text-green-800 leading-tight">Arika</span>
                  <span className="text-sm font-semibold text-green-600 tracking-wider -mt-1">HOMESTAY</span>
                </div>
              </div>
              <nav className="hidden md:flex items-center space-x-8">
                <button onClick={() => onNavigate('home')} className="text-slate-600 hover:text-green-600 font-medium transition">Rooms</button>
                <button className="text-slate-600 hover:text-green-600 font-medium transition">Facilities</button>
                <button className="text-slate-600 hover:text-green-600 font-medium transition">About Us</button>
                <button 
                  onClick={onViewToggle}
                  className="bg-green-600 text-white px-5 py-2.5 rounded-xl hover:bg-green-700 transition font-bold shadow-lg shadow-green-100"
                >
                  Staff Login
                </button>
              </nav>
            </div>
          </header>
        )}
        <main className="flex-grow">{children}</main>
        {currentPath !== 'admin-login' && (
          <footer className="bg-slate-900 text-slate-400 py-12">
            <div className="max-w-7xl mx-auto px-4 text-center">
              <p>© 2026 Arika Homestay. All rights reserved.</p>
            </div>
          </footer>
        )}
      </div>
    );
  }

  const hasAccess = (roles: User['role'][]) => currentUser && roles.includes(currentUser.role);

  return (
    <div className="min-h-screen flex bg-slate-50">
      {/* Sidebar */}
      <aside className={`${isSidebarOpen ? 'w-64' : 'w-20'} bg-green-900 text-white transition-all duration-300 flex flex-col z-50 fixed md:relative h-full`}>
        <div className="p-4 flex items-center justify-between">
          {isSidebarOpen && (
            <div className="flex items-center space-x-2">
              <Logo className="w-8 h-8" />
              <span className="text-xl font-bold tracking-tight">ARIKA Admin</span>
            </div>
          )}
          <button onClick={() => setSidebarOpen(!isSidebarOpen)} className="p-2 hover:bg-green-800 rounded-lg transition">
            {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
        
        <nav className="flex-grow py-6 px-4 space-y-2">
          <SidebarItem 
            icon={<LayoutDashboard size={20} />} 
            label="Dashboard" 
            active={currentPath === 'admin-dashboard'} 
            isOpen={isSidebarOpen} 
            onClick={() => onNavigate('admin-dashboard')}
          />
          <SidebarItem 
            icon={<BedDouble size={20} />} 
            label="Manage Rooms" 
            active={currentPath === 'admin-rooms'} 
            isOpen={isSidebarOpen}
            onClick={() => onNavigate('admin-rooms')}
          />
          {hasAccess(['Super Admin', 'Front Desk']) && (
            <SidebarItem 
              icon={<CalendarCheck size={20} />} 
              label="Reservations" 
              active={currentPath === 'admin-bookings'} 
              isOpen={isSidebarOpen}
              onClick={() => onNavigate('admin-bookings')}
            />
          )}
          {hasAccess(['Super Admin']) && (
            <SidebarItem 
              icon={<Users size={20} />} 
              label="User Management" 
              active={currentPath === 'admin-users'} 
              isOpen={isSidebarOpen}
              onClick={() => onNavigate('admin-users')}
            />
          )}
          {hasAccess(['Super Admin', 'Front Desk']) && (
            <SidebarItem 
              icon={<History size={20} />} 
              label="Audit Logs" 
              active={currentPath === 'admin-logs'} 
              isOpen={isSidebarOpen}
              onClick={() => onNavigate('admin-logs')}
            />
          )}
        </nav>

        <div className="p-4 border-t border-green-800 space-y-2">
          <button 
            onClick={onLogout}
            className="flex items-center space-x-3 w-full p-2 hover:bg-rose-900/30 rounded-lg transition text-rose-200"
          >
            <LogOut size={20} />
            {isSidebarOpen && <span>Logout</span>}
          </button>
          <button 
            onClick={onViewToggle}
            className="flex items-center space-x-3 w-full p-2 hover:bg-green-800 rounded-lg transition text-green-300 text-sm"
          >
            <Settings size={20} />
            {isSidebarOpen && <span>Public Site</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow flex flex-col min-w-0">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 sticky top-0 z-40">
          <h2 className="text-lg font-semibold text-slate-700 capitalize">
            {currentPath.replace('admin-', '').replace('-', ' ')}
          </h2>
          <div className="flex items-center space-x-4">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-bold text-slate-800">{currentUser?.name}</p>
              <p className="text-xs text-slate-500">{currentUser?.role}</p>
            </div>
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold shadow-md ${
              currentUser?.role === 'Super Admin' ? 'bg-indigo-600' : 
              currentUser?.role === 'Front Desk' ? 'bg-green-600' : 'bg-amber-600'
            }`}>
              {currentUser?.name.substring(0, 2).toUpperCase()}
            </div>
          </div>
        </header>
        <div className="p-8 overflow-auto">{children}</div>
      </main>
    </div>
  );
};

const SidebarItem: React.FC<{ 
  icon: React.ReactNode; 
  label: string; 
  active: boolean; 
  isOpen: boolean;
  onClick: () => void;
}> = ({ icon, label, active, isOpen, onClick }) => (
  <button 
    onClick={onClick}
    className={`flex items-center space-x-3 w-full p-3 rounded-lg transition ${
      active ? 'bg-green-700 text-white shadow-lg shadow-green-950/20' : 'text-green-100 hover:bg-green-800'
    }`}
  >
    {icon}
    {isOpen && <span className="font-medium whitespace-nowrap">{label}</span>}
  </button>
);

export default Layout;
