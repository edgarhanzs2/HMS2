
import { createClient } from '@supabase/supabase-js';

// GANTI DENGAN KREDENSIAL DARI DASHBOARD SUPABASE ANDA
const supabaseUrl = 'https://YOUR_PROJECT_ID.supabase.co';
const supabaseAnonKey = 'YOUR_ANON_KEY';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
