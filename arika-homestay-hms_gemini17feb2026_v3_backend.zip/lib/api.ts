
import { Room, Booking, Guest, User, ActivityLog } from '../types';
import { supabase } from './supabase';

export const ApiService = {
  // Rooms
  getRooms: async (): Promise<Room[]> => {
    const { data, error } = await supabase
      .from('rooms')
      .select('*')
      .order('room_number', { ascending: true });
    
    if (error) throw error;
    return data as Room[];
  },

  createRoom: async (room: Omit<Room, 'id'>) => {
    const { data, error } = await supabase
      .from('rooms')
      .insert(room)
      .select()
      .single();
    
    if (error) throw error;
    return data as Room;
  },

  updateRoom: async (room: Room) => {
    const { data, error } = await supabase
      .from('rooms')
      .update({
        room_number: room.roomNumber,
        type: room.type,
        price: room.price,
        status: room.status,
        image: room.image
      })
      .eq('id', room.id)
      .select()
      .single();
    
    if (error) throw error;
    return data as Room;
  },

  deleteRoom: async (id: string) => {
    const { error } = await supabase
      .from('rooms')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  },

  // Bookings & Reservation Logic
  getBookings: async (): Promise<Booking[]> => {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data as Booking[];
  },

  createBooking: async (bookingData: { 
    room: Room, 
    guest: Omit<Guest, 'id'>, 
    checkIn: string, 
    checkOut: string 
  }) => {
    // 1. Simpan Guest terlebih dahulu
    const { data: guest, error: guestError } = await supabase
      .from('guests')
      .insert({
        name: bookingData.guest.name,
        email: bookingData.guest.email,
        phone: bookingData.guest.phone
      })
      .select()
      .single();

    if (guestError) throw guestError;

    // 2. Buat Booking
    const totalDays = Math.ceil((new Date(bookingData.checkOut).getTime() - new Date(bookingData.checkIn).getTime()) / (1000 * 3600 * 24)) || 1;
    const totalCost = bookingData.room.price * totalDays;

    const { data: booking, error: bookingError } = await supabase
      .from('bookings')
      .insert({
        room_id: bookingData.room.id,
        guest_id: guest.id,
        check_in_date: bookingData.checkIn,
        check_out_date: bookingData.checkOut,
        total_cost: totalCost,
        status: 'Confirmed'
      })
      .select()
      .single();

    if (bookingError) throw bookingError;

    // 3. Update Status Kamar jadi 'Booked'
    const { error: roomError } = await supabase
      .from('rooms')
      .update({ status: 'Booked' })
      .eq('id', bookingData.room.id);

    if (roomError) throw roomError;

    return { booking, guest };
  },

  updateBookingStatus: async (id: string, status: string) => {
    const { data: updatedBooking, error } = await supabase
      .from('bookings')
      .update({ status })
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;

    // Jika status Checked-Out atau Canceled, bebaskan kamar
    if (status === 'Checked-Out' || status === 'Canceled') {
      await supabase
        .from('rooms')
        .update({ status: 'Available' })
        .eq('id', updatedBooking.room_id);
    }

    return updatedBooking;
  },

  // Guests
  getGuests: async (): Promise<Guest[]> => {
    const { data, error } = await supabase
      .from('guests')
      .select('*');
    
    if (error) throw error;
    return data as Guest[];
  },

  // Logs
  getLogs: async (): Promise<ActivityLog[]> => {
    const { data, error } = await supabase
      .from('activity_logs')
      .select('*')
      .order('timestamp', { ascending: false });
    
    if (error) throw error;
    return data as ActivityLog[];
  },

  createLog: async (log: Omit<ActivityLog, 'id'>) => {
    await supabase
      .from('activity_logs')
      .insert({
        user_id: log.userId,
        username: log.username,
        action: log.action,
        details: log.details
      });
  }
};
