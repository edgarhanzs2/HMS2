
import { Room, Booking, Guest, User, ActivityLog } from './types';

export const INITIAL_ROOMS: Room[] = [
  { id: '1', roomNumber: '101', type: 'Standard', price: 500000, status: 'Available', image: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&w=800&q=80' },
  { id: '2', roomNumber: '102', type: 'Standard', price: 500000, status: 'Available', image: 'https://images.unsplash.com/photo-1611892440504-42a792e24d32?auto=format&fit=crop&w=800&q=80' },
  { id: '3', roomNumber: '201', type: 'Deluxe', price: 850000, status: 'Booked', image: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80' },
  { id: '4', roomNumber: '202', type: 'Deluxe', price: 850000, status: 'Available', image: 'https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=800&q=80' },
  { id: '5', roomNumber: '301', type: 'Suite', price: 1500000, status: 'Available', image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80' },
  { id: '6', roomNumber: '401', type: 'Penthouse', price: 3500000, status: 'Available', image: 'https://images.unsplash.com/photo-1560185007-cde436f6a4d0?auto=format&fit=crop&w=800&q=80' },
];

export const INITIAL_GUESTS: Guest[] = [
  { id: 'g1', name: 'John Doe', email: 'john@example.com', phone: '08123456789' }
];

export const INITIAL_BOOKINGS: Booking[] = [
  {
    id: 'b1',
    roomId: '3',
    guestId: 'g1',
    checkInDate: '2023-10-25',
    checkOutDate: '2023-10-27',
    totalCost: 1700000,
    status: 'Confirmed'
  }
];

export const INITIAL_USERS: User[] = [
  { id: 'u1', name: 'Admin Utama', email: 'admin@arikahomestay.com', role: 'Super Admin', password: 'admin123' },
  { id: 'u2', name: 'Siti Receptionist', email: 'frontdesk@arikahomestay.com', role: 'Front Desk', password: 'staff123' },
  { id: 'u3', name: 'Budi Maintenance', email: 'hk@arikahomestay.com', role: 'Housekeeping', password: 'staff123' },
];

export const INITIAL_LOGS: ActivityLog[] = [
  { id: 'l1', timestamp: new Date().toISOString(), userId: 'u1', username: 'Admin Utama', action: 'System Setup', details: 'Initialized hotel database' }
];

export const ROOM_TYPES = ['Standard', 'Deluxe', 'Suite', 'Penthouse'];
export const USER_ROLES: User['role'][] = ['Super Admin', 'Front Desk', 'Housekeeping'];
