
import React, { useState } from 'react';
import { User, UserRole } from '../types';
import { Plus, Edit2, Trash2, X, UserCircle, Shield } from 'lucide-react';
import { USER_ROLES } from '../constants';

interface ManageUsersProps {
  users: User[];
  onAdd: (user: Omit<User, 'id'>) => void;
  onUpdate: (user: User) => void;
  onDelete: (id: string) => void;
}

const ManageUsers: React.FC<ManageUsersProps> = ({ users, onAdd, onUpdate, onDelete }) => {
  const [isModalOpen, setModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('Front Desk');
  const [password, setPassword] = useState('staff123');

  const openAddModal = () => {
    setEditingUser(null);
    setName('');
    setEmail('');
    setRole('Front Desk');
    setPassword('staff123');
    setModalOpen(true);
  };

  const openEditModal = (user: User) => {
    setEditingUser(user);
    setName(user.name);
    setEmail(user.email);
    setRole(user.role);
    setPassword(user.password || '');
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingUser) {
      onUpdate({ ...editingUser, name, email, role, password });
    } else {
      onAdd({ name, email, role, password });
    }
    setModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">User Management</h2>
          <p className="text-slate-500">Configure system access levels and staff accounts.</p>
        </div>
        <button 
          onClick={openAddModal}
          className="bg-indigo-600 text-white px-6 py-2.5 rounded-xl hover:bg-indigo-700 transition flex items-center font-bold shadow-lg shadow-indigo-100"
        >
          <Plus size={20} className="mr-2" />
          Add User
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-100 text-xs uppercase font-bold text-slate-400">
            <tr>
              <th className="px-6 py-4 text-center w-16">Avatar</th>
              <th className="px-6 py-4">Full Name</th>
              <th className="px-6 py-4">Email</th>
              <th className="px-6 py-4">Role</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {users.map((u) => (
              <tr key={u.id} className="hover:bg-slate-50 transition group">
                <td className="px-6 py-4 text-center">
                  <div className={`w-10 h-10 rounded-full mx-auto flex items-center justify-center text-white font-bold text-xs ${
                    u.role === 'Super Admin' ? 'bg-indigo-600' : 'bg-teal-600'
                  }`}>
                    {u.name.charAt(0)}
                  </div>
                </td>
                <td className="px-6 py-4 font-bold text-slate-700">{u.name}</td>
                <td className="px-6 py-4 text-slate-600">{u.email}</td>
                <td className="px-6 py-4">
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    u.role === 'Super Admin' ? 'bg-indigo-50 text-indigo-700 border border-indigo-100' : 
                    u.role === 'Front Desk' ? 'bg-teal-50 text-teal-700 border border-teal-100' : 'bg-amber-50 text-amber-700 border border-amber-100'
                  }`}>
                    {u.role}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex justify-end space-x-2">
                    <button onClick={() => openEditModal(u)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"><Edit2 size={16} /></button>
                    <button onClick={() => onDelete(u.id)} className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg"><Trash2 size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-indigo-50/50">
              <div className="flex items-center space-x-3">
                 <UserCircle className="text-indigo-600 w-6 h-6" />
                 <h3 className="text-xl font-bold text-slate-800">{editingUser ? 'Edit User' : 'New User'}</h3>
              </div>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={24} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-sm font-semibold text-slate-600">Full Name</label>
                <input required type="text" value={name} onChange={(e) => setName(e.target.value)} className="w-full p-3 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" placeholder="John Doe" />
              </div>
              <div className="space-y-1">
                <label className="text-sm font-semibold text-slate-600">Email Address</label>
                <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full p-3 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" placeholder="staff@arikahomestay.com" />
              </div>
              <div className="space-y-1">
                <label className="text-sm font-semibold text-slate-600">System Role</label>
                <select value={role} onChange={(e) => setRole(e.target.value as UserRole)} className="w-full p-3 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500">
                  {USER_ROLES.map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-sm font-semibold text-slate-600">Initial Password</label>
                <input required type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full p-3 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="pt-4 flex space-x-3">
                <button type="button" onClick={() => setModalOpen(false)} className="flex-1 px-4 py-3 border border-slate-200 text-slate-600 font-bold rounded-xl">Cancel</button>
                <button type="submit" className="flex-1 bg-indigo-600 text-white font-bold rounded-xl shadow-lg shadow-indigo-100">Save Account</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManageUsers;
