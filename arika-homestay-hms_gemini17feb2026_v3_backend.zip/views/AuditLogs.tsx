
import React from 'react';
import { ActivityLog } from '../types';
import { Clock, Info, User as UserIcon, Calendar } from 'lucide-react';

interface AuditLogsProps {
  logs: ActivityLog[];
}

const AuditLogs: React.FC<AuditLogsProps> = ({ logs }) => {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-800">Audit Trail</h2>
        <p className="text-slate-500">A historical record of all system activities and staff actions.</p>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 border-b border-slate-100 text-xs uppercase font-bold text-slate-400">
              <tr>
                <th className="px-6 py-4 w-48">Timestamp</th>
                <th className="px-6 py-4 w-48">User</th>
                <th className="px-6 py-4 w-48">Action</th>
                <th className="px-6 py-4">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50 transition">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-slate-500">
                      <Clock size={14} className="mr-2" />
                      {new Date(log.timestamp).toLocaleString()}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center font-bold text-slate-700">
                      <UserIcon size={14} className="mr-2 text-teal-600" />
                      {log.username}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 bg-teal-50 text-teal-700 rounded-md font-bold text-[10px] uppercase border border-teal-100">
                      {log.action}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-slate-600 italic">
                    {log.details}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {logs.length === 0 && (
          <div className="p-12 text-center text-slate-400">No activity logs recorded yet.</div>
        )}
      </div>
    </div>
  );
};

export default AuditLogs;
