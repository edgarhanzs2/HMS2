
import React, { useState } from 'react';
import { User } from '../types';
import { Lock, Mail, ArrowRight } from 'lucide-react';
import Logo from '../components/Logo';

interface AdminLoginProps {
  users: User[];
  onLogin: (user: User) => void;
}

const AdminLogin: React.FC<AdminLoginProps> = ({ users, onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = users.find(u => u.email === email && u.password === password);
    if (user) {
      onLogin(user);
    } else {
      setError('Invalid email or password. Please try again.');
    }
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-4 bg-slate-100">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-[2rem] shadow-2xl shadow-green-900/10 border border-slate-100 overflow-hidden">
          <div className="bg-green-700 p-10 text-white text-center">
            <div className="bg-white w-24 h-24 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-green-900/40">
              <Logo className="w-16 h-16" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight">Staff Portal</h1>
            <p className="text-green-100 mt-2 opacity-80 font-medium">Arika Homestay Management</p>
          </div>
          
          <form onSubmit={handleLogin} className="p-8 space-y-6">
            {error && (
              <div className="bg-rose-50 text-rose-600 p-4 rounded-xl text-sm font-medium border border-rose-100 animate-pulse">
                {error}
              </div>
            )}
            
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                  <input 
                    type="email" 
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-green-500 outline-none transition"
                    placeholder="name@arikahomestay.com"
                  />
                </div>
              </div>
              
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                  <input 
                    type="password" 
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-green-500 outline-none transition"
                    placeholder="••••••••"
                  />
                </div>
              </div>
            </div>

            <button 
              type="submit"
              className="w-full bg-green-700 text-white py-4 rounded-2xl hover:bg-green-800 transition font-bold shadow-lg shadow-green-100 flex items-center justify-center group text-lg"
            >
              Sign In
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition" />
            </button>
          </form>

          <div className="p-6 bg-slate-50 border-t border-slate-100 text-center">
             <div className="flex justify-center flex-wrap gap-2">
                <DemoBadge label="Admin" email="admin@arikahomestay.com" />
                <DemoBadge label="Staff" email="frontdesk@arikahomestay.com" />
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const DemoBadge: React.FC<{ label: string, email: string }> = ({ label, email }) => (
  <div className="text-[10px] bg-white border border-slate-200 px-3 py-1.5 rounded-full cursor-help hover:border-green-300 transition" title={email}>
     <span className="font-bold text-green-700">{label}:</span> {email}
  </div>
);

export default AdminLogin;
