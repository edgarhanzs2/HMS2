
-- Database Schema for Arika Homestay HMS

-- 1. Rooms Table
CREATE TABLE rooms (
    id SERIAL PRIMARY KEY,
    room_number VARCHAR(10) UNIQUE NOT NULL,
    type VARCHAR(20) NOT NULL CHECK (type IN ('Standard', 'Deluxe', 'Suite', 'Penthouse')),
    price DECIMAL(12, 2) NOT NULL,
    status VARCHAR(20) DEFAULT 'Available' CHECK (status IN ('Available', 'Booked')),
    image TEXT
);

-- 2. Guests Table
CREATE TABLE guests (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL
);

-- 3. Bookings Table
CREATE TABLE bookings (
    id SERIAL PRIMARY KEY,
    room_id INTEGER REFERENCES rooms(id) ON DELETE CASCADE,
    guest_id INTEGER REFERENCES guests(id) ON DELETE CASCADE,
    check_in_date DATE NOT NULL,
    check_out_date DATE NOT NULL,
    total_cost DECIMAL(12, 2) NOT NULL,
    status VARCHAR(20) DEFAULT 'Confirmed' CHECK (status IN ('Confirmed', 'Checked-In', 'Checked-Out', 'Canceled')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. Users (Staff) Table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('Super Admin', 'Front Desk', 'Housekeeping')),
    password VARCHAR(255) NOT NULL
);

-- 5. Activity Logs Table
CREATE TABLE activity_logs (
    id SERIAL PRIMARY KEY,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    user_id VARCHAR(50),
    username VARCHAR(100),
    action VARCHAR(100),
    details TEXT
);

-- Initial Data
INSERT INTO users (name, email, role, password) VALUES 
('Admin Utama', 'admin@arikahomestay.com', 'Super Admin', 'admin123');
