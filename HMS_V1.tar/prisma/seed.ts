import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('Starting database seed...')

  // Delete existing data
  await prisma.booking.deleteMany()
  await prisma.guest.deleteMany()
  await prisma.room.deleteMany()

  console.log('Cleared existing data')

  // Create rooms
  const rooms = await Promise.all([
    prisma.room.create({
      data: {
        roomNumber: '101',
        roomType: 'Standard',
        price: 500000,
        status: 'Available',
        description: 'Kamar standar yang nyaman dengan fasilitas lengkap',
        capacity: 2,
        imageUrl: ''
      }
    }),
    prisma.room.create({
      data: {
        roomNumber: '102',
        roomType: 'Standard',
        price: 500000,
        status: 'Available',
        description: 'Kamar standar yang nyaman dengan fasilitas lengkap',
        capacity: 2,
        imageUrl: ''
      }
    }),
    prisma.room.create({
      data: {
        roomNumber: '201',
        roomType: 'Deluxe',
        price: 750000,
        status: 'Available',
        description: 'Kamar deluxe dengan pemandangan kota',
        capacity: 2,
        imageUrl: ''
      }
    }),
    prisma.room.create({
      data: {
        roomNumber: '202',
        roomType: 'Deluxe',
        price: 750000,
        status: 'Available',
        description: 'Kamar deluxe dengan pemandangan taman',
        capacity: 2,
        imageUrl: ''
      }
    }),
    prisma.room.create({
      data: {
        roomNumber: '301',
        roomType: 'Suite',
        price: 1500000,
        status: 'Available',
        description: 'Suite mewah dengan ruang tamu terpisah',
        capacity: 4,
        imageUrl: ''
      }
    }),
    prisma.room.create({
      data: {
        roomNumber: '302',
        roomType: 'Suite',
        price: 1800000,
        status: 'Available',
        description: 'Suite premium dengan balkon pribadi',
        capacity: 3,
        imageUrl: ''
      }
    })
  ])

  console.log(`Created ${rooms.length} rooms`)

  // Create sample guests
  const guests = await Promise.all([
    prisma.guest.create({
      data: {
        name: 'Ahmad Wijaya',
        email: 'ahmad@example.com',
        phone: '+62 812 3456 7890',
        address: 'Jakarta Selatan'
      }
    }),
    prisma.guest.create({
      data: {
        name: 'Siti Rahayu',
        email: 'siti@example.com',
        phone: '+62 813 4567 8901',
        address: 'Jakarta Pusat'
      }
    })
  ])

  console.log(`Created ${guests.length} guests`)

  // Create sample bookings
  const bookings = await Promise.all([
    prisma.booking.create({
      data: {
        bookingCode: 'BKG-001',
        roomId: rooms[0].id,
        guestId: guests[0].id,
        checkInDate: new Date('2024-01-15'),
        checkOutDate: new Date('2024-01-17'),
        totalPrice: 1000000,
        status: 'Completed',
        guestCount: 2
      }
    }),
    prisma.booking.create({
      data: {
        bookingCode: 'BKG-002',
        roomId: rooms[2].id,
        guestId: guests[1].id,
        checkInDate: new Date('2024-01-20'),
        checkOutDate: new Date('2024-01-22'),
        totalPrice: 1500000,
        status: 'Confirmed',
        guestCount: 2
      }
    })
  ])

  console.log(`Created ${bookings.length} bookings`)

  console.log('Database seed completed successfully!')
}

main()
  .catch((e) => {
    console.error('Error seeding database:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
