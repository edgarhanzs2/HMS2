'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { 
  LayoutDashboard, 
  Bed, 
  CalendarCheck, 
  Users, 
  Settings, 
  LogOut,
  Menu,
  X,
  Plus,
  Edit2,
  Trash2,
  DollarSign,
  CheckCircle,
  XCircle
} from 'lucide-react'
import { format } from 'date-fns'

interface StatCard {
  title: string
  value: string
  change: string
  icon: any
  color: string
}

interface Room {
  id: string
  roomNumber: string
  roomType: string
  price: number
  status: string
  capacity: number
  description: string
}

interface Guest {
  id: string
  name: string
  email: string
  phone?: string
}

interface Booking {
  id: string
  bookingCode: string
  checkInDate: string
  checkOutDate: string
  totalPrice: number
  status: string
  guestCount: number
  specialRequests?: string
  room: Room
  guest: Guest
}

export default function AdminDashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [activePage, setActivePage] = useState('dashboard')
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  
  // Stats
  const [stats, setStats] = useState<StatCard[]>([
    { title: 'Total Kamar', value: '0', change: 'Total', icon: Bed, color: 'bg-teal-500' },
    { title: 'Kamar Terisi', value: '0', change: 'Hari ini', icon: CalendarCheck, color: 'bg-teal-600' },
    { title: 'Pendapatan', value: 'Rp 0', change: 'Bulan ini', icon: DollarSign, color: 'bg-teal-700' }
  ])
  
  const [bookings, setBookings] = useState<Booking[]>([])
  const [rooms, setRooms] = useState<Room[]>([])
  const [guests, setGuests] = useState<Guest[]>([])

  // Room Dialog States
  const [roomDialogOpen, setRoomDialogOpen] = useState(false)
  const [editingRoom, setEditingRoom] = useState<Room | null>(null)
  const [roomForm, setRoomForm] = useState({
    roomNumber: '',
    roomType: 'Standard',
    price: '',
    capacity: 2,
    description: '',
    status: 'Available'
  })

  // Fetch data from API
  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      setLoading(true)
      
      const [bookingsRes, roomsRes, guestsRes] = await Promise.all([
        fetch('/api/bookings'),
        fetch('/api/rooms'),
        fetch('/api/guests')
      ])

      if (!bookingsRes.ok || !roomsRes.ok || !guestsRes.ok) {
        throw new Error('Failed to fetch data')
      }

      const bookingsData = await bookingsRes.json()
      const roomsData = await roomsRes.json()
      const guestsData = await guestsRes.json()

      setBookings(bookingsData)
      setRooms(roomsData)
      setGuests(guestsData)

      // Calculate stats
      const occupiedRooms = roomsData.filter((r: Room) => r.status === 'Booked').length
      const today = new Date()
      const currentMonth = today.getMonth()
      const currentYear = today.getFullYear()
      
      const monthlyRevenue = bookingsData
        .filter((b: Booking) => {
          const bookingDate = new Date(b.checkInDate)
          return b.status === 'Completed' && 
                 bookingDate.getMonth() === currentMonth && 
                 bookingDate.getFullYear() === currentYear
        })
        .reduce((sum: number, b: Booking) => sum + b.totalPrice, 0)

      setStats([
        {
          title: 'Total Kamar',
          value: roomsData.length.toString(),
          change: 'Total',
          icon: Bed,
          color: 'bg-teal-500'
        },
        {
          title: 'Kamar Terisi',
          value: `${occupiedRooms} / ${roomsData.length}`,
          change: 'Hari ini',
          icon: CalendarCheck,
          color: 'bg-teal-600'
        },
        {
          title: 'Pendapatan',
          value: formatCurrency(monthlyRevenue),
          change: 'Bulan ini',
          icon: DollarSign,
          color: 'bg-teal-700'
        }
      ])
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  // Room CRUD operations
  const handleAddRoom = () => {
    setEditingRoom(null)
    setRoomForm({
      roomNumber: '',
      roomType: 'Standard',
      price: '',
      capacity: 2,
      description: '',
      status: 'Available'
    })
    setRoomDialogOpen(true)
  }

  const handleEditRoom = (room: Room) => {
    setEditingRoom(room)
    setRoomForm({
      roomNumber: room.roomNumber,
      roomType: room.roomType,
      price: room.price.toString(),
      capacity: room.capacity,
      description: room.description,
      status: room.status
    })
    setRoomDialogOpen(true)
  }

  const handleSaveRoom = async () => {
    if (!roomForm.roomNumber || !roomForm.price) {
      alert('Mohon lengkapi nomor kamar dan harga')
      return
    }

    setSubmitting(true)
    try {
      const payload = {
        roomNumber: roomForm.roomNumber,
        roomType: roomForm.roomType,
        price: parseFloat(roomForm.price),
        capacity: roomForm.capacity,
        description: roomForm.description,
        status: roomForm.status
      }

      let response
      if (editingRoom) {
        response = await fetch(`/api/rooms/${editingRoom.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        })
      } else {
        response = await fetch('/api/rooms', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        })
      }

      if (!response.ok) throw new Error('Failed to save room')

      setRoomDialogOpen(false)
      await fetchDashboardData()
    } catch (error) {
      console.error('Error saving room:', error)
      alert('Terjadi kesalahan saat menyimpan kamar')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDeleteRoom = async (id: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus kamar ini?')) {
      return
    }

    try {
      const response = await fetch(`/api/rooms/${id}`, {
        method: 'DELETE'
      })

      if (!response.ok) throw new Error('Failed to delete room')

      await fetchDashboardData()
    } catch (error) {
      console.error('Error deleting room:', error)
      alert('Terjadi kesalahan saat menghapus kamar')
    }
  }

  // Booking status update
  const handleUpdateBookingStatus = async (id: string, newStatus: string) => {
    try {
      const response = await fetch(`/api/bookings/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      })

      if (!response.ok) {
        const errorData = await response.json()
        const errorMessage = errorData.error || errorData.details || 'Gagal mengupdate reservasi'
        console.error('Update failed:', errorData)
        alert(`Error: ${errorMessage}`)
        return
      }

      const result = await response.json()
      console.log('Booking updated:', result.id, '→', result.status)
      await fetchDashboardData()
    } catch (error) {
      console.error('Error updating booking:', error)
      const errorMessage = error instanceof Error ? error.message : 'Terjadi kesalahan tidak diketahui'
      alert(`Error: ${errorMessage}. Silakan coba lagi.`)
    }
  }

  const handleDeleteBooking = async (id: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus reservasi ini?')) {
      return
    }

    try {
      console.log('Attempting to delete booking:', id)
      const response = await fetch(`/api/bookings/${id}`, {
        method: 'DELETE'
      })

      console.log('Delete response status:', response.status)

      if (!response.ok) {
        // Try to parse error JSON, but handle cases where response might not be JSON
        let errorData = {}
        let errorMessage = 'Gagal menghapus reservasi'
        
        try {
          const contentType = response.headers.get('content-type')
          if (contentType && contentType.includes('application/json')) {
            errorData = await response.json()
            errorMessage = errorData.error || errorData.details || errorMessage
          } else {
            errorMessage = `Server error (${response.status}): ${response.statusText}`
          }
        } catch (parseError) {
          errorMessage = `Error (${response.status}): ${response.statusText}`
        }
        
        console.error('Delete failed:', errorData)
        alert(`Error: ${errorMessage}`)
        return
      }

      const result = await response.json()
      console.log('Booking deleted:', result.message)
      await fetchDashboardData()
    } catch (error) {
      console.error('Error deleting booking:', error)
      const errorMessage = error instanceof Error ? error.message : 'Terjadi kesalahan tidak diketahui'
      alert(`Error: ${errorMessage}. Silakan coba lagi.`)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Confirmed':
        return 'bg-green-500'
      case 'Completed':
        return 'bg-blue-500'
      case 'Canceled':
        return 'bg-red-500'
      case 'Available':
        return 'bg-green-500'
      case 'Booked':
        return 'bg-orange-500'
      case 'Maintenance':
        return 'bg-gray-500'
      default:
        return 'bg-gray-500'
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'Confirmed':
        return 'Dikonfirmasi'
      case 'Completed':
        return 'Selesai'
      case 'Canceled':
        return 'Dibatalkan'
      case 'Available':
        return 'Tersedia'
      case 'Booked':
        return 'Terisi'
      case 'Maintenance':
        return 'Perbaikan'
      default:
        return status
    }
  }

  const formatCurrency = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price)
  }

  const Sidebar = () => (
    <>
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside className={`
        fixed lg:static inset-y-0 left-0 z-50
        w-64 bg-teal-900 text-white
        transform transition-transform duration-300 ease-in-out
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="flex flex-col h-full">
          <div className="p-6 border-b border-teal-800">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <LayoutDashboard className="h-6 w-6" />
                HMS Admin
              </h2>
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden text-white hover:bg-teal-800"
                onClick={() => setSidebarOpen(false)}
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
          </div>

          <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
            <Button
              variant={activePage === 'dashboard' ? 'secondary' : 'ghost'}
              className={`w-full justify-start ${
                activePage === 'dashboard' ? 'bg-teal-700 text-white' : 'text-teal-100 hover:bg-teal-800'
              }`}
              onClick={() => {
                setActivePage('dashboard')
                setSidebarOpen(false)
              }}
            >
              <LayoutDashboard className="mr-2 h-5 w-5" />
              Dasbor
            </Button>
            <Button
              variant={activePage === 'rooms' ? 'secondary' : 'ghost'}
              className={`w-full justify-start ${
                activePage === 'rooms' ? 'bg-teal-700 text-white' : 'text-teal-100 hover:bg-teal-800'
              }`}
              onClick={() => {
                setActivePage('rooms')
                setSidebarOpen(false)
              }}
            >
              <Bed className="mr-2 h-5 w-5" />
              Manajemen Kamar
            </Button>
            <Button
              variant={activePage === 'bookings' ? 'secondary' : 'ghost'}
              className={`w-full justify-start ${
                activePage === 'bookings' ? 'bg-teal-700 text-white' : 'text-teal-100 hover:bg-teal-800'
              }`}
              onClick={() => {
                setActivePage('bookings')
                setSidebarOpen(false)
              }}
            >
              <CalendarCheck className="mr-2 h-5 w-5" />
              Daftar Reservasi
            </Button>
          </nav>

          <div className="p-4 border-t border-teal-800">
            <Button
              variant="ghost"
              className="w-full justify-start text-teal-100 hover:bg-teal-800"
              onClick={() => window.location.href = '/'}
            >
              <LogOut className="mr-2 h-5 w-5" />
              Kembali ke Home
            </Button>
          </div>
        </div>
      </aside>
    </>
  )

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col lg:flex-row">
      <Sidebar />

      <main className="flex-1 min-h-screen">
        {/* Mobile Header */}
        <header className="lg:hidden bg-white shadow-sm sticky top-0 z-30">
          <div className="flex items-center justify-between p-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="h-6 w-6" />
            </Button>
            <h1 className="text-lg font-bold text-teal-900">HMS Admin</h1>
            <div className="w-10" />
          </div>
        </header>

        {/* Page Content */}
        <div className="p-6 lg:p-8">
          {/* Dashboard Page */}
          {activePage === 'dashboard' && (
            <>
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-800 mb-2">Dasbor Ringkasan</h1>
                <p className="text-gray-600">Metrik utama kinerja hotel</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                {stats.map((stat, index) => (
                  <Card key={index} className="border-l-4 border-l-teal-600 hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                          <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
                          <p className="text-xs text-green-600 mt-1">{stat.change}</p>
                        </div>
                        <div className={`${stat.color} p-3 rounded-lg`}>
                          <stat.icon className="h-6 w-6 text-white" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CalendarCheck className="h-5 w-5" />
                    Reservasi Terbaru
                  </CardTitle>
                  <CardDescription>{loading ? 'Memuat...' : `${bookings.slice(0, 5).length} reservasi terakhir`}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Kode</TableHead>
                          <TableHead>Tamu</TableHead>
                          <TableHead>Kamar</TableHead>
                          <TableHead>Check-in</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Total</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {loading ? (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center py-8">Memuat data...</TableCell>
                          </TableRow>
                        ) : bookings.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center py-8">Belum ada reservasi</TableCell>
                          </TableRow>
                        ) : (
                          bookings.slice(0, 5).map((booking) => (
                            <TableRow key={booking.id}>
                              <TableCell className="font-medium">{booking.bookingCode}</TableCell>
                              <TableCell>{booking.guest.name}</TableCell>
                              <TableCell>{booking.room.roomNumber}</TableCell>
                              <TableCell>{format(new Date(booking.checkInDate), 'dd/MM/yyyy')}</TableCell>
                              <TableCell>
                                <Badge className={getStatusColor(booking.status)}>
                                  {getStatusText(booking.status)}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-right font-medium">{formatCurrency(booking.totalPrice)}</TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </>
          )}

          {/* Rooms Management Page */}
          {activePage === 'rooms' && (
            <>
              <div className="mb-8 flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-gray-800 mb-2">Manajemen Kamar</h1>
                  <p className="text-gray-600">Kelola semua kamar di hotel</p>
                </div>
                <Button onClick={handleAddRoom} className="bg-teal-600 hover:bg-teal-700">
                  <Plus className="mr-2 h-5 w-5" />
                  Tambah Kamar
                </Button>
              </div>

              <Card>
                <CardContent className="p-6">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>No. Kamar</TableHead>
                          <TableHead>Tipe</TableHead>
                          <TableHead>Kapasitas</TableHead>
                          <TableHead>Harga</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Aksi</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {loading ? (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center py-8">Memuat data...</TableCell>
                          </TableRow>
                        ) : rooms.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={6} className="text-center py-8">Belum ada kamar</TableCell>
                          </TableRow>
                        ) : (
                          rooms.map((room) => (
                            <TableRow key={room.id}>
                              <TableCell className="font-medium">{room.roomNumber}</TableCell>
                              <TableCell>{room.roomType}</TableCell>
                              <TableCell>{room.capacity} Orang</TableCell>
                              <TableCell>{formatCurrency(room.price)}</TableCell>
                              <TableCell>
                                <Badge className={getStatusColor(room.status)}>
                                  {getStatusText(room.status)}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleEditRoom(room)}
                                    className="h-8 w-8"
                                  >
                                    <Edit2 className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleDeleteRoom(room.id)}
                                    className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </>
          )}

          {/* Bookings List Page */}
          {activePage === 'bookings' && (
            <>
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-800 mb-2">Daftar Reservasi</h1>
                <p className="text-gray-600">Kelola semua reservasi tamu</p>
              </div>

              <Card>
                <CardContent className="p-6">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Kode</TableHead>
                          <TableHead>Tamu</TableHead>
                          <TableHead>Kamar</TableHead>
                          <TableHead>Check-in</TableHead>
                          <TableHead>Check-out</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Total</TableHead>
                          <TableHead className="text-right">Aksi</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {loading ? (
                          <TableRow>
                            <TableCell colSpan={9} className="text-center py-8">Memuat data...</TableCell>
                          </TableRow>
                        ) : bookings.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={9} className="text-center py-8">Belum ada reservasi</TableCell>
                          </TableRow>
                        ) : (
                          bookings.map((booking) => (
                            <TableRow key={booking.id}>
                              <TableCell className="font-medium">{booking.bookingCode}</TableCell>
                              <TableCell>{booking.guest.name}</TableCell>
                              <TableCell>{booking.room.roomNumber}</TableCell>
                              <TableCell>{format(new Date(booking.checkInDate), 'dd/MM/yyyy')}</TableCell>
                              <TableCell>{format(new Date(booking.checkOutDate), 'dd/MM/yyyy')}</TableCell>
                              <TableCell>
                                <Badge className={getStatusColor(booking.status)}>
                                  {getStatusText(booking.status)}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-right font-medium">{formatCurrency(booking.totalPrice)}</TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  {booking.status === 'Confirmed' && (
                                    <>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => handleUpdateBookingStatus(booking.id, 'Completed')}
                                        className="h-8 w-8 text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                                        title="Selesaikan"
                                      >
                                        <CheckCircle className="h-4 w-4" />
                                      </Button>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => handleUpdateBookingStatus(booking.id, 'Canceled')}
                                        className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                                        title="Batalkan"
                                      >
                                        <XCircle className="h-4 w-4" />
                                      </Button>
                                    </>
                                  )}
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleDeleteBooking(booking.id)}
                                    className="h-8 w-8 text-gray-600 hover:text-gray-700 hover:bg-gray-50"
                                    title="Hapus"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </main>

      {/* Room Dialog */}
      <Dialog open={roomDialogOpen} onOpenChange={setRoomDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{editingRoom ? 'Edit Kamar' : 'Tambah Kamar Baru'}</DialogTitle>
            <DialogDescription>
              {editingRoom ? 'Edit detail kamar yang sudah ada' : 'Tambah kamar baru ke hotel'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="roomNumber">Nomor Kamar *</Label>
              <Input
                id="roomNumber"
                value={roomForm.roomNumber}
                onChange={(e) => setRoomForm({ ...roomForm, roomNumber: e.target.value })}
                placeholder="Contoh: 101"
              />
            </div>
            <div>
              <Label htmlFor="roomType">Tipe Kamar *</Label>
              <Select value={roomForm.roomType} onValueChange={(value) => setRoomForm({ ...roomForm, roomType: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Standard">Standard</SelectItem>
                  <SelectItem value="Deluxe">Deluxe</SelectItem>
                  <SelectItem value="Suite">Suite</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="price">Harga per Malam (IDR) *</Label>
              <Input
                id="price"
                type="number"
                value={roomForm.price}
                onChange={(e) => setRoomForm({ ...roomForm, price: e.target.value })}
                placeholder="500000"
              />
            </div>
            <div>
              <Label htmlFor="capacity">Kapasitas (Orang)</Label>
              <Select 
                value={roomForm.capacity.toString()} 
                onValueChange={(value) => setRoomForm({ ...roomForm, capacity: parseInt(value) })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 Orang</SelectItem>
                  <SelectItem value="2">2 Orang</SelectItem>
                  <SelectItem value="3">3 Orang</SelectItem>
                  <SelectItem value="4">4 Orang</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="status">Status</Label>
              <Select value={roomForm.status} onValueChange={(value) => setRoomForm({ ...roomForm, status: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Available">Tersedia</SelectItem>
                  <SelectItem value="Booked">Terisi</SelectItem>
                  <SelectItem value="Maintenance">Perbaikan</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="description">Deskripsi</Label>
              <Textarea
                id="description"
                value={roomForm.description}
                onChange={(e) => setRoomForm({ ...roomForm, description: e.target.value })}
                placeholder="Deskripsi kamar..."
                className="resize-none"
                rows={3}
              />
            </div>
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setRoomDialogOpen(false)} disabled={submitting}>
              Batal
            </Button>
            <Button onClick={handleSaveRoom} className="bg-teal-600 hover:bg-teal-700" disabled={submitting}>
              {submitting ? 'Menyimpan...' : 'Simpan'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
