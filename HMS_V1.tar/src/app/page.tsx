'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { format } from 'date-fns'
import { Calendar as CalendarIcon, Bed, Users, CreditCard, CheckCircle, MapPin, Star, Utensils, Car, Wifi, Waves } from 'lucide-react'
import { cn } from '@/lib/utils'

// Types
interface Room {
  id: string
  roomNumber: string
  roomType: string
  price: number
  status: string
  description: string
  capacity: number
  imageUrl?: string
}

export default function HomePage() {
  const [rooms, setRooms] = useState<Room[]>([])
  const [filteredRooms, setFilteredRooms] = useState<Room[]>([])
  const [loading, setLoading] = useState(true)
  const [searchPerformed, setSearchPerformed] = useState(false)
  const [checkInDate, setCheckInDate] = useState<Date>()
  const [checkOutDate, setCheckOutDate] = useState<Date>()
  const [roomTypeFilter, setRoomTypeFilter] = useState<string>('all')
  const [guestCount, setGuestCount] = useState<number>(1)
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null)
  const [bookingDialogOpen, setBookingDialogOpen] = useState(false)
  const [successDialogOpen, setSuccessDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [guestName, setGuestName] = useState('')
  const [guestEmail, setGuestEmail] = useState('')
  const [guestPhone, setGuestPhone] = useState('')
  const [specialRequests, setSpecialRequests] = useState('')

  // Fetch rooms from API
  useEffect(() => {
    fetchRooms()
  }, [])

  const fetchRooms = async () => {
    try {
      setLoading(true)
      const response = await fetch('/api/rooms')
      if (!response.ok) throw new Error('Failed to fetch rooms')
      
      const data = await response.json()
      setRooms(data)
      setFilteredRooms(data)
    } catch (error) {
      console.error('Error fetching rooms:', error)
      // Use empty array if fetch fails
      setRooms([])
      setFilteredRooms([])
    } finally {
      setLoading(false)
    }
  }

  const getRoomColor = (roomType: string) => {
    switch (roomType) {
      case 'Standard':
        return 'bg-teal-500'
      case 'Deluxe':
        return 'bg-teal-600'
      case 'Suite':
        return 'bg-teal-700'
      default:
        return 'bg-teal-500'
    }
  }

  const applyFilters = () => {
    // Validate dates
    if (!checkInDate || !checkOutDate) {
      alert('Mohon pilih tanggal Check-in dan Check-out')
      return
    }

    const today = new Date()
    today.setHours(0, 0, 0, 0)

    // Check if check-in is in the future
    if (checkInDate < today) {
      alert('Tanggal Check-in harus hari ini atau di masa depan')
      return
    }

    // Check if check-out is after check-in
    if (checkOutDate <= checkInDate) {
      alert('Tanggal Check-out harus setelah tanggal Check-in')
      return
    }

    let filtered = rooms

    // Filter by room type
    if (roomTypeFilter !== 'all') {
      filtered = filtered.filter(room => room.roomType === roomTypeFilter)
    }

    // Filter by capacity
    filtered = filtered.filter(room => room.capacity >= guestCount)

    // Filter by availability
    filtered = filtered.filter(room => room.status === 'Available')

    setFilteredRooms(filtered)
    setSearchPerformed(true)

    // Scroll to rooms section
    document.getElementById('rooms')?.scrollIntoView({ behavior: 'smooth' })
  }

  const handleBookRoom = (room: Room) => {
    setSelectedRoom(room)
    setBookingDialogOpen(true)
  }

  const handleSubmitBooking = async () => {
    // Validate required fields
    if (!guestName || !guestEmail || !guestPhone) {
      alert('Mohon lengkapi Nama, Email, dan Nomor Telepon')
      return
    }

    if (!checkInDate || !checkOutDate) {
      alert('Mohon pilih tanggal Check-in dan Check-out')
      return
    }

    if (!selectedRoom) return

    // Calculate total price
    const nights = Math.ceil((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24))
    const totalPrice = nights * selectedRoom.price

    setSubmitting(true)

    try {
      // Create guest first
      const guestResponse = await fetch('/api/guests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: guestName,
          email: guestEmail,
          phone: guestPhone
        })
      })

      const guestData = await guestResponse.json()
      
      // Handle guest API errors
      if (!guestResponse.ok) {
        const errorMessage = guestData.error || 'Gagal membuat data tamu'
        console.error('Guest creation failed:', guestData)
        alert(`Error: ${errorMessage}`)
        return
      }
      
      const guest = guestData

      // Then create booking
      const bookingResponse = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roomId: selectedRoom.id,
          guestId: guest.id,
          checkInDate: checkInDate.toISOString(),
          checkOutDate: checkOutDate.toISOString(),
          totalPrice,
          guestCount,
          specialRequests
        })
      })

      const bookingData = await bookingResponse.json()

      // Handle booking API errors
      if (!bookingResponse.ok) {
        const errorMessage = bookingData.error || bookingData.details || 'Gagal membuat reservasi'
        console.error('Booking creation failed:', bookingData)
        alert(`Error: ${errorMessage}`)
        return
      }

      const booking = bookingData

      // Reset form and show success
      setGuestName('')
      setGuestEmail('')
      setGuestPhone('')
      setSpecialRequests('')
      setBookingDialogOpen(false)
      setSuccessDialogOpen(true)
      setSelectedRoom(null)
      
      // Refresh rooms
      await fetchRooms()
    } catch (error) {
      console.error('Booking error:', error)
      const errorMessage = error instanceof Error ? error.message : 'Terjadi kesalahan tidak diketahui'
      alert(`Error: ${errorMessage}. Silakan coba lagi.`)
    } finally {
      setSubmitting(false)
    }
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(price)
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-teal-600 text-white shadow-lg sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Waves className="h-8 w-8" />
              <h1 className="text-2xl font-bold">Grand Hotel</h1>
            </div>
            <nav className="hidden md:flex items-center gap-6">
              <a href="#rooms" className="hover:text-teal-100 transition-colors">Kamar</a>
              <a href="#facilities" className="hover:text-teal-100 transition-colors">Fasilitas</a>
              <a href="#contact" className="hover:text-teal-100 transition-colors">Kontak</a>
            </nav>
            <Button 
              variant="outline" 
              className="text-teal-600 border-white hover:bg-white hover:text-teal-600"
              onClick={() => window.location.href = '/admin'}
            >
              Login Admin
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-teal-600 to-teal-700 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-5xl font-bold mb-4">Selamat Datang di Grand Hotel</h2>
          <p className="text-xl mb-8 text-teal-100">
            Pengalaman menginap mewah dan tak terlupakan dengan harga terjangkau
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-lg">
              <Star className="h-5 w-5 fill-current text-yellow-400" />
              <span>4.9 Rating</span>
            </div>
            <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-lg">
              <MapPin className="h-5 w-5" />
              <span>Lokasi Strategis</span>
            </div>
            <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-lg">
              <Bed className="h-5 w-5" />
              <span>100+ Kamar</span>
            </div>
          </div>
        </div>
      </section>

      {/* Search/Filter Section */}
      <section className="container mx-auto px-4 -mt-8">
        <Card className="shadow-2xl border-t-4 border-t-teal-600">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <div>
                <Label>Check-in</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left mt-2",
                        !checkInDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {checkInDate ? format(checkInDate, "dd/MM/yyyy") : "Pilih tanggal"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={checkInDate}
                      onSelect={setCheckInDate}
                      initialFocus
                      disabled={(date) => {
                        const today = new Date()
                        today.setHours(0, 0, 0, 0)
                        return date < today
                      }}
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div>
                <Label>Check-out</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left mt-2",
                        !checkOutDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {checkOutDate ? format(checkOutDate, "dd/MM/yyyy") : "Pilih tanggal"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={checkOutDate}
                      onSelect={setCheckOutDate}
                      initialFocus
                      disabled={(date) => checkInDate ? date <= checkInDate : false}
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div>
                <Label>Jumlah Tamu</Label>
                <Select value={guestCount.toString()} onValueChange={(value) => setGuestCount(parseInt(value))}>
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 Orang</SelectItem>
                    <SelectItem value="2">2 Orang</SelectItem>
                    <SelectItem value="3">3 Orang</SelectItem>
                    <SelectItem value="4">4 Orang</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Tipe Kamar</Label>
                <Select value={roomTypeFilter} onValueChange={setRoomTypeFilter}>
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Tipe</SelectItem>
                    <SelectItem value="Standard">Standard</SelectItem>
                    <SelectItem value="Deluxe">Deluxe</SelectItem>
                    <SelectItem value="Suite">Suite</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end">
                <Button 
                  onClick={applyFilters} 
                  className="w-full bg-teal-600 hover:bg-teal-700 h-11"
                >
                  Cari Kamar
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Room Listings */}
      <section id="rooms" className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-gray-800 mb-4">Kamar Tersedia</h3>
          <p className="text-gray-600">Pilih kamar yang sesuai dengan kebutuhan Anda</p>
          {searchPerformed && filteredRooms.length > 0 && (
            <div className="mt-4 inline-block bg-teal-100 text-teal-800 px-4 py-2 rounded-full">
              <Badge className="bg-teal-600 text-white">
                {filteredRooms.length} kamar ditemukan
              </Badge>
            </div>
          )}
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-16">
            <div className="text-center">
              <Bed className="h-16 w-16 mx-auto mb-4 text-teal-600 animate-pulse" />
              <p className="text-gray-600">Memuat kamar...</p>
            </div>
          </div>
        ) : !searchPerformed ? (
          <Card className="text-center py-16 border-2 border-dashed border-gray-300">
            <CardContent>
              <CalendarIcon className="h-16 w-16 mx-auto mb-4 text-teal-400" />
              <h4 className="text-xl font-semibold mb-2">Cari Ketersediaan Kamar</h4>
              <p className="text-gray-600 mb-4">
                Pilih tanggal Check-in dan Check-out untuk melihat kamar yang tersedia
              </p>
              <div className="flex justify-center">
                <Button 
                  onClick={() => window.scrollTo({ top: 300, behavior: 'smooth' })}
                  className="bg-teal-600 hover:bg-teal-700"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  Pilih Tanggal Sekarang
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : filteredRooms.length === 0 ? (
          <Card className="text-center py-16">
            <CardContent>
              <Bed className="h-16 w-16 mx-auto mb-4 text-gray-400" />
              <h4 className="text-xl font-semibold mb-2">Tidak ada kamar tersedia</h4>
              <p className="text-gray-600 mb-4">
                Coba ubah tanggal atau filter pencarian Anda
              </p>
              <Button 
                onClick={() => window.scrollTo({ top: 300, behavior: 'smooth' })}
                variant="outline"
              >
                Ubah Pencarian
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRooms.map((room) => (
              <Card key={room.id} className="overflow-hidden hover:shadow-xl transition-shadow border-2 hover:border-teal-200">
                <CardHeader className={cn("text-white p-6", getRoomColor(room.roomType))}>
                  <div className="flex justify-between items-start">
                    <div>
                      <Badge variant="secondary" className="mb-2 bg-white/20 text-white">
                        {room.roomType}
                      </Badge>
                      <CardTitle className="text-2xl">Kamar {room.roomNumber}</CardTitle>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold">{formatPrice(room.price)}</p>
                      <p className="text-sm text-teal-100">/ malam</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <p className="text-gray-600 mb-4">{room.description}</p>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      <span>{room.capacity} Tamu</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Bed className="h-4 w-4" />
                      <span>{room.roomType}</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="p-6 pt-0">
                  <Button 
                    onClick={() => handleBookRoom(room)}
                    className="w-full bg-teal-600 hover:bg-teal-700"
                  >
                    <CreditCard className="mr-2 h-4 w-4" />
                    Pesan Sekarang
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </section>

      {/* Facilities Section */}
      <section id="facilities" className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-800 mb-4">Fasilitas Hotel</h3>
            <p className="text-gray-600">Fasilitas lengkap untuk kenyamanan Anda</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <Wifi className="h-12 w-12 mx-auto mb-4 text-teal-600" />
              <h4 className="font-semibold mb-2">WiFi Gratis</h4>
              <p className="text-sm text-gray-600">Internet cepat di seluruh area hotel</p>
            </Card>
            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <Utensils className="h-12 w-12 mx-auto mb-4 text-teal-600" />
              <h4 className="font-semibold mb-2">Restoran</h4>
              <p className="text-sm text-gray-600">Menu lezat 24 jam</p>
            </Card>
            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <Car className="h-12 w-12 mx-auto mb-4 text-teal-600" />
              <h4 className="font-semibold mb-2">Parkir Gratis</h4>
              <p className="text-sm text-gray-600">Parkir aman dan luas</p>
            </Card>
            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <Bed className="h-12 w-12 mx-auto mb-4 text-teal-600" />
              <h4 className="font-semibold mb-2">Layanan Kamar</h4>
              <p className="text-sm text-gray-600">Layanan kamar 24 jam</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-teal-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Waves className="h-8 w-8" />
                <h4 className="text-xl font-bold">Grand Hotel</h4>
              </div>
              <p className="text-teal-200">
                Hotel bintang lima dengan pelayanan terbaik dan fasilitas lengkap untuk pengalaman menginap yang tak terlupakan.
              </p>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Kontak Kami</h5>
              <div className="space-y-2 text-teal-200">
                <p>📍 Jl. Sudirman No. 123, Jakarta</p>
                <p>📞 +62 21 1234 5678</p>
                <p>✉️ info@grandhotel.com</p>
              </div>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Jam Operasional</h5>
              <div className="space-y-2 text-teal-200">
                <p>Resepsionis: 24 Jam</p>
                <p>Check-in: 14:00 WIB</p>
                <p>Check-out: 12:00 WIB</p>
              </div>
            </div>
          </div>
          <div className="border-t border-teal-800 mt-8 pt-8 text-center text-teal-200">
            <p>&copy; 2024 Grand Hotel. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Booking Dialog */}
      <Dialog open={bookingDialogOpen} onOpenChange={setBookingDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Reservasi Kamar {selectedRoom?.roomNumber}</DialogTitle>
            <DialogDescription>
              {selectedRoom?.roomType} Room - {formatPrice(selectedRoom?.price || 0)} / malam
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="name">Nama Lengkap *</Label>
              <Input
                id="name"
                value={guestName}
                onChange={(e) => setGuestName(e.target.value)}
                placeholder="Masukkan nama lengkap"
                disabled={submitting}
              />
            </div>
            <div>
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={guestEmail}
                onChange={(e) => setGuestEmail(e.target.value)}
                placeholder="email@example.com"
                disabled={submitting}
              />
            </div>
            <div>
              <Label htmlFor="phone">No. Telepon *</Label>
              <Input
                id="phone"
                type="tel"
                value={guestPhone}
                onChange={(e) => setGuestPhone(e.target.value)}
                placeholder="+62 8xx xxxx xxxx"
                disabled={submitting}
              />
            </div>
            <div>
              <Label>Permintaan Khusus</Label>
              <Textarea
                value={specialRequests}
                onChange={(e) => setSpecialRequests(e.target.value)}
                placeholder="Permintaan tambahan (opsional)"
                className="resize-none"
                rows={3}
                disabled={submitting}
              />
            </div>
            {checkInDate && checkOutDate && selectedRoom && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-600">Check-in:</span>
                  <span className="font-medium">{format(checkInDate, 'dd/MM/yyyy')}</span>
                </div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-600">Check-out:</span>
                  <span className="font-medium">{format(checkOutDate, 'dd/MM/yyyy')}</span>
                </div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-600">Durasi:</span>
                  <span className="font-medium">
                    {Math.ceil((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24))} malam
                  </span>
                </div>
                <div className="flex justify-between items-center pt-2 border-t">
                  <span className="font-semibold">Total:</span>
                  <span className="text-xl font-bold text-teal-600">
                    {formatPrice(Math.ceil((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24)) * selectedRoom.price)}
                  </span>
                </div>
              </div>
            )}
          </div>
          <div className="flex justify-end gap-3">
            <Button 
              variant="outline" 
              onClick={() => setBookingDialogOpen(false)}
              disabled={submitting}
            >
              Batal
            </Button>
            <Button 
              onClick={handleSubmitBooking} 
              className="bg-teal-600 hover:bg-teal-700"
              disabled={submitting}
            >
              {submitting ? (
                <>
                  <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                  Memproses...
                </>
              ) : (
                'Konfirmasi Reservasi'
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Success Dialog */}
      <Dialog open={successDialogOpen} onOpenChange={setSuccessDialogOpen}>
        <DialogContent className="sm:max-w-[400px] text-center">
          <div className="flex flex-col items-center gap-4 py-6">
            <div className="bg-green-100 p-4 rounded-full">
              <CheckCircle className="h-12 w-12 text-green-600" />
            </div>
            <div>
              <DialogTitle className="text-xl mb-2">Reservasi Berhasil!</DialogTitle>
              <p className="text-gray-600">
                Terima kasih telah melakukan reservasi. Anda akan menerima konfirmasi melalui email.
              </p>
            </div>
          </div>
          <Button onClick={() => setSuccessDialogOpen(false)} className="w-full bg-teal-600 hover:bg-teal-700">
            Tutup
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  )
}
