import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET all bookings
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const status = searchParams.get('status')
    
    const bookings = await db.booking.findMany({
      where: status ? { status } : undefined,
      orderBy: { createdAt: 'desc' },
      include: {
        room: true,
        guest: true
      }
    })
    
    return NextResponse.json(bookings)
  } catch (error) {
    console.error('Error fetching bookings:', error)
    return NextResponse.json(
      { error: 'Failed to fetch bookings' },
      { status: 500 }
    )
  }
}

// POST create new booking
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    console.log('Received booking request:', body)
    
    const {
      roomId,
      guestId,
      checkInDate,
      checkOutDate,
      totalPrice,
      guestCount,
      specialRequests
    } = body

    // Validate required fields
    if (!roomId || !guestId || !checkInDate || !checkOutDate || !totalPrice) {
      console.error('Missing required fields:', { roomId, guestId, checkInDate, checkOutDate, totalPrice })
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Generate unique booking code
    const bookingCode = `BKG-${Date.now().toString().slice(-6)}`

    // Parse values with proper type handling
    const parsedTotalPrice = typeof totalPrice === 'number' ? totalPrice : parseFloat(totalPrice)
    const parsedGuestCount = typeof guestCount === 'number' ? guestCount : parseInt(guestCount as string) || 1

    const booking = await db.booking.create({
      data: {
        bookingCode,
        roomId,
        guestId,
        checkInDate: new Date(checkInDate),
        checkOutDate: new Date(checkOutDate),
        totalPrice: parsedTotalPrice,
        guestCount: parsedGuestCount,
        specialRequests: specialRequests || null,
        status: 'Confirmed'
      },
      include: {
        room: true,
        guest: true
      }
    })

    // Note: Room status remains Available to allow multiple bookings at different dates
    // In a real system, you would check date conflicts here
    console.log('Booking created successfully:', booking)
    return NextResponse.json(booking, { status: 201 })
  } catch (error) {
    console.error('Error creating booking:', error)
    console.error('Error details:', JSON.stringify(error))
    return NextResponse.json(
      { error: 'Failed to create booking', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
