import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET single booking
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const booking = await db.booking.findUnique({
      where: { id },
      include: {
        room: true,
        guest: true
      }
    })

    if (!booking) {
      return NextResponse.json(
        { error: 'Booking not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(booking)
  } catch (error) {
    console.error('Error fetching booking:', error)
    return NextResponse.json(
      { error: 'Failed to fetch booking' },
      { status: 500 }
    )
  }
}

// PUT update booking
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    console.log(`Updating booking ${id}:`, body)
    
    const { status } = body

    if (!status) {
      console.error('Missing status field')
      return NextResponse.json(
        { error: 'Status wajib diisi' },
        { status: 400 }
      )
    }

    // Validate status
    const validStatuses = ['Confirmed', 'Completed', 'Canceled']
    if (!validStatuses.includes(status)) {
      console.error('Invalid status:', status)
      return NextResponse.json(
        { error: 'Status tidak valid. Gunakan: Confirmed, Completed, atau Canceled' },
        { status: 400 }
      )
    }

    const existingBooking = await db.booking.findUnique({
      where: { id }
    })

    if (!existingBooking) {
      console.error('Booking not found:', id)
      return NextResponse.json(
        { error: 'Reservasi tidak ditemukan' },
        { status: 404 }
      )
    }

    console.log('Current booking status:', existingBooking.status)
    console.log('New booking status:', status)

    const booking = await db.booking.update({
      where: { id },
      data: {
        ...(status && { status })
      },
      include: {
        room: true,
        guest: true
      }
    })

    console.log('Booking updated successfully:', booking.id, booking.status)

    // Update room status based on booking status change
    if (status === 'Canceled' && existingBooking.status === 'Confirmed') {
      console.log('Booking canceled, making room available')
      await db.room.update({
        where: { id: existingBooking.roomId },
        data: { status: 'Available' }
      })
      console.log('Room status updated to Available')
    } else if (status === 'Completed' && existingBooking.status === 'Confirmed') {
      console.log('Booking completed, making room available')
      await db.room.update({
        where: { id: existingBooking.roomId },
        data: { status: 'Available' }
      })
      console.log('Room status updated to Available')
    }

    return NextResponse.json(booking)
  } catch (error) {
    console.error('Error updating booking:', error)
    console.error('Error details:', {
      message: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined
    })
    return NextResponse.json(
      { error: 'Gagal mengupdate reservasi', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}

// DELETE booking
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    console.log('DELETE request received for booking ID:', id)
    
    const booking = await db.booking.findUnique({
      where: { id }
    })

    if (!booking) {
      console.log('Booking not found:', id)
      return NextResponse.json(
        { error: 'Reservasi tidak ditemukan' },
        { status: 404 }
      )
    }

    console.log('Found booking:', booking.id, 'Status:', booking.status, 'Room ID:', booking.roomId)

    // Update room status to Available if booking was confirmed
    if (booking.status === 'Confirmed') {
      await db.room.update({
        where: { id: booking.roomId },
        data: { status: 'Available' }
      })
      console.log('Room status updated to Available due to booking deletion')
    }

    await db.booking.delete({
      where: { id }
    })

    console.log('Booking deleted successfully:', booking.id)
    return NextResponse.json({ message: 'Booking deleted successfully' })
  } catch (error) {
    const { id } = await params
    console.error('Error deleting booking:', error)
    console.error('Error details:', {
      message: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined,
      bookingId: id
    })
    return NextResponse.json(
      { error: 'Gagal menghapus reservasi', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
