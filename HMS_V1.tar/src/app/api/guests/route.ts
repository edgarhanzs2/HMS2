import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET all guests
export async function GET() {
  try {
    const guests = await db.guest.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        bookings: {
          orderBy: { createdAt: 'desc' },
          take: 5
        }
      }
    })
    
    return NextResponse.json(guests)
  } catch (error) {
    console.error('Error fetching guests:', error)
    return NextResponse.json(
      { error: 'Failed to fetch guests' },
      { status: 500 }
    )
  }
}

// POST create new guest
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    console.log('Received guest request:', body)
    
    const { name, email, phone, address } = body

    // Validate required fields
    if (!name || typeof name !== 'string' || name.trim() === '') {
      console.error('Invalid or missing name')
      return NextResponse.json(
        { error: 'Nama tamu harus diisi' },
        { status: 400 }
      )
    }

    if (!email || typeof email !== 'string' || email.trim() === '') {
      console.error('Invalid or missing email')
      return NextResponse.json(
        { error: 'Email harus diisi' },
        { status: 400 }
      )
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      console.error('Invalid email format:', email)
      return NextResponse.json(
        { error: 'Format email tidak valid' },
        { status: 400 }
      )
    }

    // Check if email already exists
    try {
      const existingGuest = await db.guest.findUnique({
        where: { email: email.trim() }
      })

      if (existingGuest) {
        console.log('Guest already exists, returning:', existingGuest.id)
        // Return existing guest with OK status
        return NextResponse.json(existingGuest, { status: 200 })
      }
    } catch (findError) {
      console.error('Error checking existing guest:', findError)
      // Continue to create even if check fails
    }

    // Create new guest
    const guest = await db.guest.create({
      data: {
        name: name.trim(),
        email: email.trim(),
        phone: phone ? phone.trim() : null,
        address: address ? address.trim() : null
      }
    })

    console.log('Guest created successfully:', guest.id)
    return NextResponse.json(guest, { status: 201 })
  } catch (error) {
    console.error('Error creating guest:', error)
    
    // Handle Prisma unique constraint errors
    const errorMessage = error instanceof Error ? error.message : 'Unknown error'
    const statusCode = errorMessage.includes('Unique constraint') ? 409 : 500
    
    console.error('Error details:', {
      message: errorMessage,
      stack: error instanceof Error ? error.stack : undefined
    })
    
    return NextResponse.json(
      { 
        error: 'Gagal membuat tamu', 
        details: errorMessage 
      },
      { status: statusCode }
    )
  }
}
