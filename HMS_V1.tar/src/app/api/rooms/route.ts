import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET all rooms
export async function GET() {
  try {
    const rooms = await db.room.findMany({
      orderBy: { roomNumber: 'asc' }
    })
    
    return NextResponse.json(rooms)
  } catch (error) {
    console.error('Error fetching rooms:', error)
    return NextResponse.json(
      { error: 'Failed to fetch rooms' },
      { status: 500 }
    )
  }
}

// POST create new room
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      roomNumber,
      roomType,
      price,
      description,
      capacity,
      imageUrl
    } = body

    // Validate required fields
    if (!roomNumber || !roomType || !price) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Check if room number already exists
    const existingRoom = await db.room.findUnique({
      where: { roomNumber }
    })

    if (existingRoom) {
      return NextResponse.json(
        { error: 'Room number already exists' },
        { status: 400 }
      )
    }

    const room = await db.room.create({
      data: {
        roomNumber,
        roomType,
        price: parseFloat(price),
        description,
        capacity: capacity || 2,
        imageUrl,
        status: 'Available'
      }
    })

    return NextResponse.json(room, { status: 201 })
  } catch (error) {
    console.error('Error creating room:', error)
    return NextResponse.json(
      { error: 'Failed to create room' },
      { status: 500 }
    )
  }
}
