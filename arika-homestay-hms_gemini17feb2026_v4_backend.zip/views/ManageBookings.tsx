
import React from 'react';
import { Booking, Room, Guest, BookingStatus } from '../types';
import { Check, XCircle, LogIn, LogOut as LogOutIcon, RefreshCw, AlertCircle } from 'lucide-react';

interface ManageBookingsProps {
  bookings: Booking[];
  rooms: Room[];
  guests: Guest[];
  onUpdateStatus: (id: string, status: BookingStatus) => void;
}

const ManageBookings: React.FC<ManageBookingsProps> = ({ bookings, rooms, guests, onUpdateStatus }) => {
  const handleForceRefresh = () => {
    window.location.reload();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Reservations</h2>
          <p className="text-slate-500">Monitor and manage all guest bookings and stay statuses.</p>
        </div>
        <div className="flex space-x-3">
            <button 
              onClick={handleForceRefresh}
              className="flex items-center space-x-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition text-sm font-bold"
            >
              <RefreshCw size={16} />
              <span>Refresh Data</span>
            </button>
            <span className="bg-teal-50 px-4 py-2 rounded-xl border border-teal-100 text-sm font-bold text-teal-600 flex items-center">
               Total: {bookings.length}
            </span>
        </div>
      </div>

      {bookings.length > 0 && guests.length === 0 && (
        <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex items-center space-x-3 text-amber-800 text-sm">
          <AlertCircle size={18} />
          <p>Bookings found, but Guest data is empty. Check your Supabase RLS policies for the "guests" table.</p>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-100 text-xs uppercase font-bold text-slate-400">
            <tr>
              <th className="px-6 py-4">Guest</th>
              <th className="px-6 py-4">Room Info</th>
              <th className="px-6 py-4">Check-in/Out</th>
              <th className="px-6 py-4">Payment</th>
              <th className="px-6 py-4">Status</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm">
            {bookings.map((booking) => {
              // Pastikan ID dicocokkan sebagai string
              const guest = guests.find(g => g.id === booking.guestId);
              const room = rooms.find(r => r.id === booking.roomId);
              
              return (
                <tr key={booking.id} className="hover:bg-slate-50/50 transition">
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="font-bold text-slate-800">{guest?.name || `Guest ID: ${booking.guestId}`}</span>
                      <span className="text-xs text-slate-400">{guest?.email || 'Email not loaded'}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="font-medium text-slate-700">Room {room?.roomNumber || booking.roomId}</span>
                      <span className="text-xs text-slate-400">{room?.type || 'Loading...'}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="text-slate-600 font-medium">{booking.checkInDate}</span>
                      <span className="text-xs text-slate-400">{booking.checkOutDate}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="font-bold text-slate-800">Rp {booking.totalCost.toLocaleString()}</span>
                  </td>
                  <td className="px-6 py-4">
                    <StatusBadge status={booking.status} />
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end space-x-1">
                      {booking.status === 'Confirmed' && (
                        <ActionButton 
                          onClick={() => onUpdateStatus(booking.id, 'Checked-In')} 
                          icon={<LogIn size={14} />} 
                          label="Check In" 
                          color="text-teal-600"
                        />
                      )}
                      {booking.status === 'Checked-In' && (
                        <ActionButton 
                          onClick={() => onUpdateStatus(booking.id, 'Checked-Out')} 
                          icon={<LogOutIcon size={14} />} 
                          label="Check Out" 
                          color="text-blue-600"
                        />
                      )}
                      {(booking.status === 'Confirmed') && (
                        <ActionButton 
                          onClick={() => onUpdateStatus(booking.id, 'Canceled')} 
                          icon={<XCircle size={14} />} 
                          label="Cancel" 
                          color="text-rose-600"
                        />
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {bookings.length === 0 && (
          <div className="p-20 text-center text-slate-400 italic flex flex-col items-center">
            <AlertCircle size={48} className="mb-4 opacity-20" />
            <p className="text-lg font-medium">No reservations found.</p>
            <p className="text-sm">If you just made a booking, try clicking "Refresh Data" above.</p>
          </div>
        )}
      </div>
    </div>
  );
};

const ActionButton: React.FC<{ onClick: () => void; icon: React.ReactNode; label: string; color: string }> = ({ onClick, icon, label, color }) => (
  <button 
    onClick={onClick}
    className={`flex items-center space-x-1 px-3 py-1.5 rounded-lg border border-slate-100 hover:bg-white hover:shadow-sm transition ${color}`}
  >
    {icon}
    <span className="text-xs font-bold uppercase">{label}</span>
  </button>
);

const StatusBadge: React.FC<{ status: BookingStatus }> = ({ status }) => {
  const styles = {
    'Confirmed': 'bg-teal-50 text-teal-600 border-teal-100',
    'Checked-In': 'bg-blue-50 text-blue-600 border-blue-100',
    'Checked-Out': 'bg-slate-100 text-slate-600 border-slate-200',
    'Canceled': 'bg-rose-50 text-rose-600 border-rose-100'
  };

  return (
    <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${styles[status]}`}>
      {status}
    </span>
  );
};

export default ManageBookings;
