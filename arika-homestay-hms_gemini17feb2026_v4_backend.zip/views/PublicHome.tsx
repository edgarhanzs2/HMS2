
import React, { useState, useMemo } from 'react';
import { Room, Guest } from '../types';
import { Search, Info, CheckCircle, CreditCard, TreePine, Calendar } from 'lucide-react';

interface PublicHomeProps {
  rooms: Room[];
  onBook: (data: { room: Room, guest: Omit<Guest, 'id'>, checkIn: string, checkOut: string }) => void;
}

const PublicHome: React.FC<PublicHomeProps> = ({ rooms, onBook }) => {
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [bookingStep, setBookingStep] = useState<'search' | 'details'>('search');
  
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [guestPhone, setGuestPhone] = useState('');

  const availableRooms = rooms.filter(r => r.status === 'Available');

  // Dynamic Total Calculation
  const bookingSummary = useMemo(() => {
    if (!selectedRoom || !checkIn || !checkOut) return { days: 1, total: selectedRoom?.price || 0 };
    const start = new Date(checkIn);
    const end = new Date(checkOut);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const days = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
    return { days, total: selectedRoom.price * days };
  }, [selectedRoom, checkIn, checkOut]);

  const handleBookNow = (room: Room) => {
    if (!checkIn || !checkOut) {
      alert("Please select Check-in and Check-out dates first.");
      return;
    }
    setSelectedRoom(room);
    setBookingStep('details');
  };

  const handleSubmitBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRoom) return;
    onBook({
      room: selectedRoom,
      guest: { name: guestName, email: guestEmail, phone: guestPhone },
      checkIn,
      checkOut
    });
    setBookingStep('search');
    setSelectedRoom(null);
  };

  return (
    <div className="space-y-12 pb-20">
      {/* Hero Section */}
      <section className="relative h-[450px] flex items-center justify-center text-white overflow-hidden">
        <div className="absolute inset-0 bg-green-950">
          <img 
            src="https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1920&q=80" 
            className="w-full h-full object-cover opacity-30"
            alt="Hero Background"
          />
        </div>
        <div className="relative z-10 text-center space-y-4 px-4">
          <h1 className="text-5xl md:text-6xl font-black tracking-tight">Nature Meets Comfort</h1>
          <p className="text-lg md:text-xl text-green-100 max-w-2xl mx-auto font-medium">
            Discover a peaceful retreat at <span className="text-white border-b-2 border-green-500">Arika Homestay</span>.
          </p>
        </div>
      </section>

      {/* Search Bar */}
      <div className="max-w-4xl mx-auto -mt-16 relative z-20 px-4">
        <div className="bg-white p-6 rounded-3xl shadow-xl border border-slate-100 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center">
              <Calendar size={12} className="mr-1" /> Check-In
            </label>
            <input 
              type="date" 
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none transition"
              value={checkIn}
              onChange={(e) => setCheckIn(e.target.value)}
              min={new Date().toISOString().split('T')[0]}
            />
          </div>
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center">
              <Calendar size={12} className="mr-1" /> Check-Out
            </label>
            <input 
              type="date" 
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none transition"
              value={checkOut}
              onChange={(e) => setCheckOut(e.target.value)}
              min={checkIn || new Date().toISOString().split('T')[0]}
            />
          </div>
          <div className="flex items-end">
            <button className="w-full bg-green-600 text-white p-3 rounded-xl hover:bg-green-700 transition font-bold flex items-center justify-center">
              <Search className="w-4 h-4 mr-2" /> Find Available Rooms
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {bookingStep === 'search' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {availableRooms.map((room) => (
              <div key={room.id} className="bg-white rounded-3xl border border-slate-200 overflow-hidden hover:shadow-xl transition duration-300 group">
                <div className="h-56 overflow-hidden relative">
                  <img 
                    src={room.image || `https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=800&q=80`} 
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                    alt={`Room ${room.roomNumber}`}
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold text-green-700 uppercase tracking-widest shadow-sm">
                      {room.type}
                    </span>
                  </div>
                </div>
                <div className="p-6 space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-xl font-bold text-slate-800">Room {room.roomNumber}</h3>
                    <div className="text-right">
                      <p className="text-xl font-black text-green-700">Rp {room.price.toLocaleString()}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase">per night</p>
                    </div>
                  </div>
                  <div className="flex space-x-3 text-xs text-slate-500 font-medium">
                    <span className="bg-slate-50 px-2 py-1 rounded border border-slate-100">Wifi Free</span>
                    <span className="bg-slate-50 px-2 py-1 rounded border border-slate-100">Hot Water</span>
                  </div>
                  <button 
                    onClick={() => handleBookNow(room)}
                    className="w-full bg-slate-900 text-white py-3.5 rounded-xl hover:bg-green-600 transition font-bold"
                  >
                    Select Room
                  </button>
                </div>
              </div>
            ))}
            {availableRooms.length === 0 && (
              <div className="col-span-full py-20 text-center space-y-4">
                <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-300">
                   <Info size={40} />
                </div>
                <p className="text-slate-500 font-medium italic">No rooms available for your selected dates.</p>
              </div>
            )}
          </div>
        ) : (
          <div className="max-w-2xl mx-auto bg-white p-8 rounded-3xl shadow-xl border border-slate-100">
            <button 
              onClick={() => setBookingStep('search')}
              className="mb-6 text-sm text-green-600 font-bold hover:text-green-800 transition flex items-center"
            >
              &larr; Return to Selection
            </button>
            <h2 className="text-2xl font-black text-slate-800 mb-6">Complete Reservation</h2>
            
            <div className="bg-green-50 p-5 rounded-2xl border border-green-100 mb-8 flex items-center justify-between">
               <div className="space-y-1">
                  <p className="text-[10px] text-green-600 font-bold uppercase tracking-widest">Selected Details</p>
                  <p className="font-bold text-slate-800 text-sm">Room {selectedRoom?.roomNumber} • {bookingSummary.days} Night(s)</p>
                  <p className="text-xs text-slate-500">{checkIn} to {checkOut}</p>
               </div>
               <div className="text-right">
                  <p className="text-[10px] text-green-600 font-bold uppercase tracking-widest">Total Price</p>
                  <p className="text-2xl font-black text-green-700">Rp {bookingSummary.total.toLocaleString()}</p>
               </div>
            </div>

            <form onSubmit={handleSubmitBooking} className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase ml-1">Full Name</label>
                  <input required value={guestName} onChange={(e) => setGuestName(e.target.value)} type="text" className="w-full p-3.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none transition" placeholder="John Smith" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase ml-1">Phone Number</label>
                  <input required value={guestPhone} onChange={(e) => setGuestPhone(e.target.value)} type="tel" className="w-full p-3.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none transition" placeholder="0812..." />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase ml-1">Email Address</label>
                <input required value={guestEmail} onChange={(e) => setGuestEmail(e.target.value)} type="email" className="w-full p-3.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none transition" placeholder="john@example.com" />
              </div>

              <div className="pt-6">
                <button 
                  type="submit"
                  className="w-full bg-green-600 text-white py-4 rounded-xl hover:bg-green-700 transition font-black text-lg shadow-lg flex items-center justify-center space-x-2"
                >
                  <CheckCircle className="w-5 h-5" />
                  <span>Confirm Booking</span>
                </button>
                <div className="flex items-center justify-center space-x-2 mt-6">
                  <CreditCard className="w-4 h-4 text-slate-400" />
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Pay at Check-in</p>
                </div>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};

export default PublicHome;
