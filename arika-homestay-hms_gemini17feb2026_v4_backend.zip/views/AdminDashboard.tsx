
import React from 'react';
import { DashboardMetrics, Booking, Room, Guest } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Users, Home, Wallet } from 'lucide-react';

interface AdminDashboardProps {
  metrics: DashboardMetrics;
  bookings: Booking[];
  rooms: Room[];
  guests: Guest[];
}

const COLORS = ['#0d9488', '#e2e8f0'];

const AdminDashboard: React.FC<AdminDashboardProps> = ({ metrics, bookings, rooms, guests }) => {
  // Mock data for charts
  const occupancyData = [
    { name: 'Occupied', value: metrics.totalOccupied },
    { name: 'Available', value: metrics.availableToday },
  ];

  const revenueData = [
    { month: 'Jul', rev: metrics.monthlyRevenue * 0.7 },
    { month: 'Aug', rev: metrics.monthlyRevenue * 0.8 },
    { month: 'Sep', rev: metrics.monthlyRevenue * 0.9 },
    { month: 'Oct', rev: metrics.monthlyRevenue },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard 
          title="Occupied Today" 
          value={metrics.totalOccupied.toString()} 
          icon={<Users className="text-teal-600" />} 
          trend="+12% from last week" 
        />
        <MetricCard 
          title="Available Rooms" 
          value={metrics.availableToday.toString()} 
          icon={<Home className="text-slate-600" />} 
          trend={`${Math.round((metrics.availableToday / Math.max(1, rooms.length)) * 100)}% vacancy rate`}
        />
        <MetricCard 
          title="Monthly Revenue" 
          value={`Rp ${metrics.monthlyRevenue.toLocaleString()}`} 
          icon={<Wallet className="text-amber-600" />} 
          trend="+5.4% targets met" 
        />
        <MetricCard 
          title="Average Booking" 
          value="Rp 1.2M" 
          icon={<TrendingUp className="text-blue-600" />} 
          trend="+2.1% higher" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Revenue Growth</h3>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0d9488" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#0d9488" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                />
                <Area type="monotone" dataKey="rev" stroke="#0d9488" strokeWidth={3} fillOpacity={1} fill="url(#colorRev)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Status Pie Chart */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Occupancy Rate</h3>
          <div className="h-80 w-full flex flex-col items-center justify-center">
            <ResponsiveContainer width="100%" height="80%">
              <PieChart>
                <Pie
                  data={occupancyData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {occupancyData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="mt-4 space-y-2 w-full">
               <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center"><div className="w-3 h-3 rounded-full bg-teal-600 mr-2"></div> Occupied</div>
                  <span className="font-bold">{metrics.totalOccupied}</span>
               </div>
               <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center"><div className="w-3 h-3 rounded-full bg-slate-200 mr-2"></div> Available</div>
                  <span className="font-bold">{metrics.availableToday}</span>
               </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <h3 className="text-lg font-bold text-slate-800 mb-6">Recent Bookings</h3>
        <div className="overflow-x-auto">
           <table className="w-full text-left">
              <thead className="text-xs uppercase text-slate-400 font-bold border-b border-slate-100">
                <tr>
                  <th className="pb-4 px-2">ID</th>
                  <th className="pb-4">Guest</th>
                  <th className="pb-4">Room</th>
                  <th className="pb-4">Dates</th>
                  <th className="pb-4">Status</th>
                </tr>
              </thead>
              <tbody className="text-sm text-slate-600 divide-y divide-slate-50">
                {bookings.slice(0, 5).map((b) => {
                  const guest = guests.find(g => g.id === b.guestId);
                  const room = rooms.find(r => r.id === b.roomId);
                  return (
                    <tr key={b.id} className="hover:bg-slate-50 transition">
                      <td className="py-4 px-2 font-medium text-slate-400">#{b.id}</td>
                      <td className="py-4">
                        <div className="font-bold text-slate-800">{guest?.name || 'Unknown'}</div>
                        <div className="text-[10px] text-slate-400 truncate max-w-[150px]">{guest?.email}</div>
                      </td>
                      <td className="py-4">Room {room?.roomNumber || b.roomId}</td>
                      <td className="py-4 text-xs">
                        <span className="text-slate-500">{b.checkInDate}</span>
                        <span className="mx-1 opacity-30">&rarr;</span>
                        <span className="text-slate-500">{b.checkOutDate}</span>
                      </td>
                      <td className="py-4">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          b.status === 'Confirmed' ? 'bg-teal-50 text-teal-600' : 
                          b.status === 'Checked-In' ? 'bg-blue-50 text-blue-600' : 
                          b.status === 'Canceled' ? 'bg-rose-50 text-rose-600' : 'bg-slate-100 text-slate-500'
                        }`}>
                          {b.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
           </table>
           {bookings.length === 0 && <div className="py-10 text-center text-slate-400 italic">No recent activity.</div>}
        </div>
      </div>
    </div>
  );
};

const MetricCard: React.FC<{ title: string; value: string; icon: React.ReactNode; trend: string }> = ({ title, value, icon, trend }) => (
  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
    <div className="flex items-center justify-between">
      <div className="p-3 bg-slate-50 rounded-xl">{icon}</div>
      <span className="text-xs font-semibold text-slate-400">Real-time</span>
    </div>
    <div>
      <h4 className="text-sm font-medium text-slate-500">{title}</h4>
      <p className="text-2xl font-bold text-slate-800">{value}</p>
    </div>
    <div className="text-xs font-medium text-teal-600">{trend}</div>
  </div>
);

export default AdminDashboard;
