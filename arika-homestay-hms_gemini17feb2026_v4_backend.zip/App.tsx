
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import Layout from './components/Layout';
import PublicHome from './views/PublicHome';
import AdminDashboard from './views/AdminDashboard';
import ManageRooms from './views/ManageRooms';
import ManageBookings from './views/ManageBookings';
import ManageUsers from './views/ManageUsers';
import AuditLogs from './views/AuditLogs';
import AdminLogin from './views/AdminLogin';
import { Room, Guest, Booking, DashboardMetrics, User, ActivityLog } from './types';
import { ApiService } from './lib/api';
import { INITIAL_USERS } from './constants';
import { AlertCircle, RefreshCw } from 'lucide-react';

const App: React.FC = () => {
  // Application State
  const [isAdmin, setIsAdmin] = useState(false);
  const [currentPath, setCurrentPath] = useState('home');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [connError, setConnError] = useState<string | null>(null);
  
  // Database State (from API)
  const [rooms, setRooms] = useState<Room[]>([]);
  const [guests, setGuests] = useState<Guest[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);

  // Initial Data Fetching
  const fetchData = useCallback(async () => {
    try {
      setIsLoading(true);
      setConnError(null);
      
      const [roomsData, bookingsData, guestsData, logsData] = await Promise.all([
        ApiService.getRooms(),
        ApiService.getBookings(),
        ApiService.getGuests(),
        ApiService.getLogs()
      ]);
      
      setRooms(roomsData);
      setBookings(bookingsData);
      setGuests(guestsData);
      setActivityLogs(logsData);
      console.log("Data loaded:", { rooms: roomsData.length, bookings: bookingsData.length, guests: guestsData.length });
    } catch (error: any) {
      console.error("Supabase Fetch Error:", error);
      setConnError(error.message || "Failed to fetch data from Supabase.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Fetch on mount
  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Re-fetch data specifically when navigating to admin pages to ensure freshness
  useEffect(() => {
    if (currentPath.startsWith('admin')) {
      fetchData();
    }
  }, [currentPath]);

  // Activity Logger Utility
  const logActivity = useCallback(async (action: string, details: string) => {
    try {
      const log = {
        timestamp: new Date().toISOString(),
        userId: currentUser?.id || 'anonymous',
        username: currentUser?.name || 'System Guest',
        action,
        details
      };
      await ApiService.createLog(log);
    } catch (e) {
      console.warn("Could not log activity", e);
    }
  }, [currentUser]);

  // Routing Logic
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '') || 'home';
      setCurrentPath(hash);
      const is_admin_path = hash.startsWith('admin');
      setIsAdmin(is_admin_path);
      if (is_admin_path && hash !== 'admin-login' && !currentUser) {
        window.location.hash = 'admin-login';
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    handleHashChange();
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [currentUser]);

  const navigate = (path: string) => {
    window.location.hash = path;
  };

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    logActivity('Login', `User ${user.name} logged in`);
    navigate('admin-dashboard');
  };

  const handleLogout = () => {
    logActivity('Logout', `User ${currentUser?.name} logged out`);
    setCurrentUser(null);
    setIsAdmin(false);
    navigate('home');
  };

  const toggleView = () => {
    if (isAdmin) {
      navigate('home');
    } else {
      navigate(currentUser ? 'admin-dashboard' : 'admin-login');
    }
  };

  // CRUD Handlers
  const addRoom = async (room: Omit<Room, 'id'>) => {
    try {
      const newRoom = await ApiService.createRoom(room);
      setRooms(prev => [...prev, newRoom]);
      logActivity('Create Room', `Added Room ${newRoom.roomNumber}`);
    } catch (e: any) {
      alert("Error adding room: " + e.message);
    }
  };

  const updateRoom = async (updatedRoom: Room) => {
    try {
      const result = await ApiService.updateRoom(updatedRoom);
      setRooms(prev => prev.map(r => r.id === result.id ? result : r));
      logActivity('Update Room', `Modified Room ${updatedRoom.roomNumber}`);
    } catch (e: any) {
      alert("Error updating room: " + e.message);
    }
  };

  const deleteRoom = async (id: string) => {
    try {
      await ApiService.deleteRoom(id);
      setRooms(prev => prev.filter(item => item.id !== id));
      logActivity('Delete Room', `Removed room ID ${id}`);
    } catch (e: any) {
      alert("Error deleting room: " + e.message);
    }
  };

  const handleNewBooking = async (bookingData: any) => {
    try {
      setIsLoading(true);
      const result = await ApiService.createBooking(bookingData);
      alert(`Booking Successful! ID: ${result.booking.id}`);
      await fetchData(); // Refresh data before navigating
      navigate('home');
    } catch (e: any) {
      alert("Booking failed: " + e.message);
    } finally {
      setIsLoading(false);
    }
  };

  const updateBookingStatus = async (id: string, status: Booking['status']) => {
    try {
      await ApiService.updateBookingStatus(id, status);
      await fetchData();
    } catch (e: any) {
      alert("Update failed: " + e.message);
    }
  };

  // Metrics
  const metrics: DashboardMetrics = useMemo(() => {
    const activeBookings = bookings.filter(b => b.status === 'Confirmed' || b.status === 'Checked-In');
    const revenue = bookings.filter(b => b.status !== 'Canceled').reduce((acc, b) => acc + Number(b.totalCost), 0);
    return {
      totalOccupied: activeBookings.length,
      availableToday: rooms.filter(r => r.status === 'Available').length,
      monthlyRevenue: revenue
    };
  }, [rooms, bookings]);

  if (connError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
        <div className="max-w-md w-full bg-white rounded-[2rem] shadow-xl p-10 text-center space-y-6 border border-rose-100">
          <div className="w-20 h-20 bg-rose-50 rounded-3xl flex items-center justify-center mx-auto">
            <AlertCircle className="text-rose-500 w-10 h-10" />
          </div>
          <div className="space-y-2">
            <h1 className="text-2xl font-bold text-slate-800">Connection Error</h1>
            <p className="text-slate-500 text-sm leading-relaxed">{connError}</p>
          </div>
          <button 
            onClick={fetchData}
            className="w-full bg-slate-900 text-white py-4 rounded-2xl hover:bg-slate-800 transition font-bold flex items-center justify-center space-x-2"
          >
            <RefreshCw size={18} />
            <span>Retry Connection</span>
          </button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-green-50">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 border-4 border-green-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-green-800 font-bold animate-pulse">Processing Data...</p>
        </div>
      </div>
    );
  }

  const renderView = () => {
    if (isAdmin && !currentUser && currentPath !== 'admin-login') {
       return <AdminLogin users={users} onLogin={handleLogin} />;
    }

    switch (currentPath) {
      case 'home': return <PublicHome rooms={rooms} onBook={handleNewBooking} />;
      case 'admin-login': return <AdminLogin users={users} onLogin={handleLogin} />;
      case 'admin-dashboard': return <AdminDashboard metrics={metrics} bookings={bookings} rooms={rooms} guests={guests} />;
      case 'admin-rooms': return <ManageRooms rooms={rooms} onAdd={addRoom} onUpdate={updateRoom} onDelete={deleteRoom} userRole={currentUser?.role} />;
      case 'admin-bookings': return <ManageBookings bookings={bookings} rooms={rooms} guests={guests} onUpdateStatus={updateBookingStatus} />;
      case 'admin-users': return <ManageUsers users={users} onAdd={()=>{}} onUpdate={()=>{}} onDelete={()=>{}} />;
      case 'admin-logs': return <AuditLogs logs={activityLogs} />;
      default: return <PublicHome rooms={rooms} onBook={handleNewBooking} />;
    }
  };

  return (
    <Layout 
      isAdmin={isAdmin} 
      currentUser={currentUser}
      onViewToggle={toggleView} 
      currentPath={currentPath}
      onNavigate={navigate}
      onLogout={handleLogout}
    >
      {renderView()}
    </Layout>
  );
};

export default App;
