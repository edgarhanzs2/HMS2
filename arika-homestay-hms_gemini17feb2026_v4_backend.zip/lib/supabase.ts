
import { createClient } from '@supabase/supabase-js';

// GANTI DENGAN KREDENSIAL DARI DASHBOARD SUPABASE ANDA
const supabaseUrl = 'https://mezlxzgdytxwokgqcpeb.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1lemx4emdkeXR4d29rZ3FjcGViIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA0NTI5MjYsImV4cCI6MjA4NjAyODkyNn0.TW3uIlNoERAONT3L7KpGIKLUI3FNj0hPtJ9FicxXfMg';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
