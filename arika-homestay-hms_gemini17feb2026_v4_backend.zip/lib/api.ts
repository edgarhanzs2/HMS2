
import { Room, Booking, Guest, User, ActivityLog } from '../types';
import { supabase } from './supabase';

export const ApiService = {
  // Rooms
  getRooms: async (): Promise<Room[]> => {
    const { data, error } = await supabase
      .from('rooms')
      .select('*')
      .order('room_number', { ascending: true });
    
    if (error) throw error;
    
    return (data || []).map(r => ({
      id: r.id.toString(),
      roomNumber: r.room_number,
      type: r.type,
      price: parseFloat(r.price),
      status: r.status,
      image: r.image
    }));
  },

  createRoom: async (room: Omit<Room, 'id'>) => {
    const { data, error } = await supabase
      .from('rooms')
      .insert({
        room_number: room.roomNumber,
        type: room.type,
        price: room.price,
        status: room.status,
        image: room.image
      })
      .select()
      .single();
    
    if (error) throw error;
    return {
      id: data.id.toString(),
      roomNumber: data.room_number,
      type: data.type,
      price: parseFloat(data.price),
      status: data.status,
      image: data.image
    } as Room;
  },

  updateRoom: async (room: Room) => {
    const { data, error } = await supabase
      .from('rooms')
      .update({
        room_number: room.roomNumber,
        type: room.type,
        price: room.price,
        status: room.status,
        image: room.image
      })
      .eq('id', room.id)
      .select()
      .single();
    
    if (error) throw error;
    return {
      id: data.id.toString(),
      roomNumber: data.room_number,
      type: data.type,
      price: parseFloat(data.price),
      status: data.status,
      image: data.image
    } as Room;
  },

  deleteRoom: async (id: string) => {
    const { error } = await supabase
      .from('rooms')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  },

  // Bookings & Reservation Logic
  getBookings: async (): Promise<Booking[]> => {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error("Error fetching bookings:", error);
      throw error;
    }
    
    // Pastikan data dipetakan dengan aman, gunakan optional chaining
    return (data || []).map(b => ({
      id: b.id?.toString() || '',
      roomId: b.room_id?.toString() || '',
      guestId: b.guest_id?.toString() || '',
      checkInDate: b.check_in_date,
      checkOutDate: b.check_out_date,
      totalCost: parseFloat(b.total_cost || 0),
      status: b.status
    }));
  },

  createBooking: async (bookingData: { 
    room: Room, 
    guest: Omit<Guest, 'id'>, 
    checkIn: string, 
    checkOut: string 
  }) => {
    // 1. Cek atau Buat Guest
    const { data: existingGuest } = await supabase
      .from('guests')
      .select('*')
      .eq('email', bookingData.guest.email)
      .maybeSingle();

    let guestId;

    if (existingGuest) {
      guestId = existingGuest.id;
      await supabase
        .from('guests')
        .update({ phone: bookingData.guest.phone, name: bookingData.guest.name })
        .eq('id', guestId);
    } else {
      const { data: newGuest, error: guestError } = await supabase
        .from('guests')
        .insert({
          name: bookingData.guest.name,
          email: bookingData.guest.email,
          phone: bookingData.guest.phone
        })
        .select()
        .single();

      if (guestError) throw guestError;
      guestId = newGuest.id;
    }

    // 2. Hitung Biaya
    const diffTime = Math.abs(new Date(bookingData.checkOut).getTime() - new Date(bookingData.checkIn).getTime());
    const totalDays = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
    const totalCost = bookingData.room.price * totalDays;

    // 3. Buat Booking (Pastikan room_id dikirim sebagai integer)
    const { data: booking, error: bookingError } = await supabase
      .from('bookings')
      .insert({
        room_id: parseInt(bookingData.room.id),
        guest_id: guestId,
        check_in_date: bookingData.checkIn,
        check_out_date: bookingData.checkOut,
        total_cost: totalCost,
        status: 'Confirmed'
      })
      .select()
      .single();

    if (bookingError) throw bookingError;

    // 4. Update Status Kamar
    await supabase
      .from('rooms')
      .update({ status: 'Booked' })
      .eq('id', bookingData.room.id);

    return { 
      booking: {
        id: booking.id.toString(),
        roomId: booking.room_id.toString(),
        guestId: booking.guest_id.toString(),
        checkInDate: booking.check_in_date,
        checkOutDate: booking.check_out_date,
        totalCost: parseFloat(booking.total_cost),
        status: booking.status
      }
    };
  },

  updateBookingStatus: async (id: string, status: string) => {
    const { data: bookingCheck, error: fetchError } = await supabase
      .from('bookings')
      .select('room_id')
      .eq('id', id)
      .single();
    
    if (fetchError) throw fetchError;

    const { data: updatedBooking, error } = await supabase
      .from('bookings')
      .update({ status })
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;

    if (status === 'Checked-Out' || status === 'Canceled') {
      await supabase
        .from('rooms')
        .update({ status: 'Available' })
        .eq('id', bookingCheck.room_id);
    }

    return updatedBooking;
  },

  // Guests
  getGuests: async (): Promise<Guest[]> => {
    const { data, error } = await supabase
      .from('guests')
      .select('*');
    
    if (error) throw error;
    return (data || []).map(g => ({
      id: g.id.toString(),
      name: g.name,
      email: g.email,
      phone: g.phone
    }));
  },

  // Logs
  getLogs: async (): Promise<ActivityLog[]> => {
    const { data, error } = await supabase
      .from('activity_logs')
      .select('*')
      .order('timestamp', { ascending: false });
    
    if (error) throw error;
    return (data || []).map(l => ({
      id: l.id.toString(),
      timestamp: l.timestamp,
      userId: l.user_id,
      username: l.username,
      action: l.action,
      details: l.details
    }));
  },

  createLog: async (log: Omit<ActivityLog, 'id'>) => {
    await supabase
      .from('activity_logs')
      .insert({
        user_id: log.userId,
        username: log.username,
        action: log.action,
        details: log.details
      });
  }
};
