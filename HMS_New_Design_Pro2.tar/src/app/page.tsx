'use client';

import { useState, useEffect } from 'react';
import { Building2, Menu, X, Calendar, Users, MapPin, Phone, Mail, Clock, CheckCircle, XCircle, Bed, Wifi, Car, Coffee, ArrowLeft, Plus, Edit, Trash2, Search, Settings, Globe, Languages, Star, Shield, Leaf, Sparkles, ChevronRight, Filter, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';

type ViewMode = 'public' | 'admin';
type Language = 'id' | 'en';

interface Room {
  id: string;
  roomNumber: string;
  type: string;
  price: number;
  status: 'AVAILABLE' | 'BOOKED' | 'MAINTENANCE';
  image?: string;
  amenities?: string;
}

interface Guest {
  id: string;
  name: string;
  email: string;
  phone: string;
}

interface Booking {
  id: string;
  reservationId: string;
  roomId: string;
  guestId: string;
  checkInDate: string;
  checkOutDate: string;
  totalCost: number;
  status: 'CONFIRMED' | 'CANCELED' | 'COMPLETED' | 'CHECKED_IN';
  room?: Room;
  guest?: Guest;
}

const translations = {
  en: {
    tagline: 'Your Home Away From Home',
    nav: { home: 'Home', about: 'About', contact: 'Contact' },
    welcome: 'Welcome to Arika Homestay',
    description: 'Experience comfort and tranquility in our carefully designed rooms',
    features: { comfortable: 'Comfortable Rooms', wifi: 'Free WiFi', location: 'Prime Location' },
    ourRooms: 'Our Rooms',
    roomsDesc: 'Choose from our selection of comfortable rooms designed for your perfect stay',
    noRooms: 'No rooms available at the moment. Please check back later.',
    room: 'Room',
    perNight: 'per night',
    bookNow: 'Book Now',
    searchAvailability: 'Check Room Availability',
    searchBtn: 'Search Available Rooms',
    selectDates: 'Select your check-in and check-out dates',
    availableRooms: 'Available Rooms',
    noAvailableRooms: 'No rooms available for the selected dates. Please try different dates.',
    showingRooms: 'Showing {count} room(s) available for your dates',
    makeReservation: 'Make a Reservation',
    checkIn: 'Check-in Date',
    checkOut: 'Check-out Date',
    fullName: 'Full Name',
    email: 'Email',
    phone: 'Phone',
    nights: 'nights',
    total: 'Total',
    cancel: 'Cancel',
    confirm: 'Confirm Reservation',
    contactUs: 'Contact Us',
    quickLinks: 'Quick Links',
    rights: '© 2024 Arika Homestay. All rights reserved.',
    adminDashboard: 'Admin Dashboard',
    available: 'Available',
    booked: 'Booked',
    maintenance: 'Maintenance',
    confirmed: 'Confirmed',
    canceled: 'Canceled',
    completed: 'Completed',
    checkedIn: 'Checked-In',
    reservationSuccess: 'Reservation successful! Your reservation ID: ',
    errorMakingReservation: 'Error making reservation',
    roomCreated: 'Room created successfully',
    errorCreatingRoom: 'Error creating room',
    roomUpdated: 'Room updated successfully',
    roomDeleted: 'Room deleted successfully',
    bookingStatusUpdated: 'Booking status updated successfully',
    bookingCanceled: 'Booking canceled successfully',
    errorCancelingBooking: 'Error canceling booking',
    roomStatusUpdated: 'Room status updated successfully',
    errorUpdatingRoom: 'Error updating room',
    adminPanel: 'Admin Dashboard',
    dashboardSummary: 'Dashboard Summary',
    totalRooms: 'Total Rooms',
    availableToday: 'Available Today',
    monthlyRevenue: 'Monthly Revenue',
    roomsTable: 'Rooms Table',
    bookingsTable: 'Bookings Table',
    backToPublic: 'Back to Public',
    roomsTab: 'Rooms',
    bookingsTab: 'Bookings',
    guestsTab: 'Guests',
    search: 'Search...',
    addRoom: 'Add Room',
    addNewRoom: 'Add New Room',
    editRoom: 'Edit Room',
    deleteRoom: 'Delete Room',
    deleteRoomConfirm: 'Are you sure you want to delete this room?',
    enterRoomDetails: 'Enter the details for the new room',
    roomNumber: 'Room Number',
    roomType: 'Room Type',
    pricePerNight: 'Price per Night',
    amenities: 'Amenities (comma separated)',
    status: 'Status',
    createRoom: 'Create Room',
    updateRoom: 'Update Room',
    actions: 'Actions',
    updateBookingStatus: 'Update Status',
    stats: {
      availableRooms: 'Available Rooms',
      bookedRooms: 'Booked Rooms',
      activeBookings: 'Active Bookings',
      totalBookingsThisMonth: 'Total Bookings This Month',
      confirmedBookings: 'Confirmed Bookings',
      checkedInBookings: 'Checked-In Bookings',
      completedBookings: 'Completed Bookings'
    },
    standard: 'Standard',
    deluxe: 'Deluxe',
    suite: 'Suite',
    family: 'Family'
  },
  id: {
    tagline: 'Rumah Kedua Anda',
    nav: { home: 'Beranda', about: 'Tentang', contact: 'Kontak' },
    welcome: 'Selamat Datang di Arika Homestay',
    description: 'Nikmati kenyamanan dan ketenangan di kamar yang kami desain dengan hati',
    features: { comfortable: 'Kamar Nyaman', wifi: 'WiFi Gratis', location: 'Lokasi Strategis' },
    ourRooms: 'Kamar Kami',
    roomsDesc: 'Pilih dari koleksi kamar nyaman kami yang dirancang untuk kenyamanan Anda',
    noRooms: 'Tidak ada kamar tersedia saat ini. Silakan periksa kembali nanti.',
    room: 'Kamar',
    perNight: 'per malam',
    bookNow: 'Pesan Sekarang',
    searchAvailability: 'Cek Ketersediaan Kamar',
    searchBtn: 'Cari Kamar Tersedia',
    selectDates: 'Pilih tanggal check-in dan check-out Anda',
    availableRooms: 'Kamar Tersedia',
    noAvailableRooms: 'Tidak ada kamar tersedia untuk tanggal yang dipilih. Silakan coba tanggal lain.',
    showingRooms: 'Menampilkan {count} kamar yang tersedia untuk tanggal Anda',
    makeReservation: 'Buat Reservasi',
    checkIn: 'Tanggal Check-in',
    checkOut: 'Tanggal Check-out',
    fullName: 'Nama Lengkap',
    email: 'Email',
    phone: 'Telepon',
    nights: 'malam',
    total: 'Total',
    cancel: 'Batal',
    confirm: 'Konfirmasi Reservasi',
    contactUs: 'Hubungi Kami',
    quickLinks: 'Tautan Cepat',
    rights: '© 2024 Arika Homestay. Hak Cipta Dilindungi.',
    adminDashboard: 'Dasbor Admin',
    available: 'Tersedia',
    booked: 'Terpesan',
    maintenance: 'Perbaikan',
    confirmed: 'Dikonfirmasi',
    canceled: 'Dibatalkan',
    completed: 'Selesai',
    checkedIn: 'Check-In',
    reservationSuccess: 'Reservasi berhasil! ID reservasi Anda: ',
    errorMakingReservation: 'Gagal membuat reservasi',
    roomCreated: 'Kamar berhasil dibuat',
    errorCreatingRoom: 'Gagal membuat kamar',
    roomUpdated: 'Kamar berhasil diperbarui',
    roomDeleted: 'Kamar berhasil dihapus',
    bookingStatusUpdated: 'Status pemesanan berhasil diperbarui',
    bookingCanceled: 'Pemesanan berhasil dibatalkan',
    errorCancelingBooking: 'Gagal membatalkan pemesanan',
    roomStatusUpdated: 'Status kamar berhasil diperbarui',
    errorUpdatingRoom: 'Gagal memperbarui kamar',
    adminPanel: 'Dasbor Admin',
    dashboardSummary: 'Ringkasan Dasbor',
    totalRooms: 'Total Kamar',
    availableToday: 'Tersedia Hari Ini',
    monthlyRevenue: 'Pendapatan Bulan Ini',
    roomsTable: 'Tabel Kamar',
    bookingsTable: 'Tabel Pemesanan',
    backToPublic: 'Kembali ke Publik',
    roomsTab: 'Kamar',
    bookingsTab: 'Pemesanan',
    guestsTab: 'Tamu',
    search: 'Cari...',
    addRoom: 'Tambah Kamar',
    addNewRoom: 'Tambah Kamar Baru',
    editRoom: 'Edit Kamar',
    deleteRoom: 'Hapus Kamar',
    deleteRoomConfirm: 'Apakah Anda yakin ingin menghapus kamar ini?',
    enterRoomDetails: 'Masukkan detail untuk kamar baru',
    roomNumber: 'Nomor Kamar',
    roomType: 'Tipe Kamar',
    pricePerNight: 'Harga per Malam',
    amenities: 'Fasilitas (pisahkan dengan koma)',
    status: 'Status',
    createRoom: 'Buat Kamar',
    updateRoom: 'Perbarui Kamar',
    actions: 'Aksi',
    updateBookingStatus: 'Perbarui Status',
    stats: {
      availableRooms: 'Kamar Tersedia',
      bookedRooms: 'Kamar Terpesan',
      activeBookings: 'Pemesanan Aktif',
      totalBookingsThisMonth: 'Total Pemesanan Bulan Ini',
      confirmedBookings: 'Pemesanan Dikonfirmasi',
      checkedInBookings: 'Pemesanan Check-In',
      completedBookings: 'Pemesanan Selesai'
    },
    standard: 'Standard',
    deluxe: 'Deluxe',
    suite: 'Suite',
    family: 'Family'
  }
};

export default function HomePage() {
  const [viewMode, setViewMode] = useState<ViewMode>('public');
  const [language, setLanguage] = useState<Language>('id');
  const t = translations[language];

  const handleSwitchToAdmin = () => {
    window.location.href = '/login';
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-emerald-50 via-green-50 to-sage-50">
      {viewMode === 'public' ? (
        <PublicInterface
          onSwitchToAdmin={handleSwitchToAdmin}
          language={language}
          setLanguage={setLanguage}
          t={t}
        />
      ) : (
        <AdminDashboard
          onBackToPublic={() => setViewMode('public')}
          language={language}
          setLanguage={setLanguage}
          t={t}
        />
      )}
    </div>
  );
}

function PublicInterface({
  onSwitchToAdmin,
  language,
  setLanguage,
  t
}: {
  onSwitchToAdmin: () => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations.en;
}) {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [guests, setGuests] = useState<Guest[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Search functionality
  const [searchCheckIn, setSearchCheckIn] = useState('');
  const [searchCheckOut, setSearchCheckOut] = useState('');
  const [hasSearched, setHasSearched] = useState(false);

  // Reservation
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [reservationDialogOpen, setReservationDialogOpen] = useState(false);
  const [reservationForm, setReservationForm] = useState({
    guestName: '',
    guestEmail: '',
    guestPhone: '',
    checkInDate: '',
    checkOutDate: ''
  });

  const seedDatabase = async () => {
    try {
      await fetch('/api/seed', { method: 'POST' });
      loadData();
    } catch (error) {
      console.error('Error seeding database:', error);
    }
  };

  const loadData = async () => {
    try {
      const [roomsRes, bookingsRes, guestsRes] = await Promise.all([
        fetch('/api/rooms'),
        fetch('/api/bookings'),
        fetch('/api/guests')
      ]);
      const roomsData = await roomsRes.json();
      const bookingsData = await bookingsRes.json();
      const guestsData = await guestsRes.json();

      setRooms(roomsData);
      setBookings(bookingsData.map((b: any) => ({
        ...b,
        checkInDate: new Date(b.checkInDate).toISOString(),
        checkOutDate: new Date(b.checkOutDate).toISOString()
      })));
      setGuests(guestsData);

      if (roomsData.length === 0) {
        seedDatabase();
      }
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const isRoomAvailable = (roomId: string, checkIn: string, checkOut: string) => {
    return !bookings.some(booking => {
      if (booking.roomId !== roomId || booking.status === 'CANCELED') return false;
      const bookingCheckIn = new Date(booking.checkInDate);
      const bookingCheckOut = new Date(booking.checkOutDate);
      const searchCheckInDate = new Date(checkIn);
      const searchCheckOutDate = new Date(checkOut);
      return searchCheckInDate < bookingCheckOut && searchCheckOutDate > bookingCheckIn;
    });
  };

  const availableRoomsForDates = hasSearched && searchCheckIn && searchCheckOut
    ? rooms.filter(room => isRoomAvailable(room.id, searchCheckIn, searchCheckOut))
    : rooms;

  const handleMakeReservation = (room: Room) => {
    setSelectedRoom(room);
    setReservationForm({
      guestName: '',
      guestEmail: '',
      guestPhone: '',
      checkInDate: searchCheckIn,
      checkOutDate: searchCheckOut
    });
    setReservationDialogOpen(true);
  };

  const submitReservation = async () => {
    if (!selectedRoom) return;

    const nights = Math.ceil((new Date(reservationForm.checkOutDate).getTime() - new Date(reservationForm.checkInDate).getTime()) / (1000 * 60 * 60 * 24));
    const totalCost = nights * selectedRoom.price;

    try {
      const guestRes = await fetch('/api/guests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: reservationForm.guestName,
          email: reservationForm.guestEmail,
          phone: reservationForm.guestPhone
        })
      });
      const guest = await guestRes.json();

      const bookingRes = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reservationId: `RES-${Date.now()}`,
          roomId: selectedRoom.id,
          guestId: guest.id,
          checkInDate: reservationForm.checkInDate,
          checkOutDate: reservationForm.checkOutDate,
          totalCost,
          status: 'CONFIRMED'
        })
      });
      const booking = await bookingRes.json();

      await fetch(`/api/rooms/${selectedRoom.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'BOOKED' })
      });

      await loadData();
      setReservationDialogOpen(false);
      setReservationForm({
        guestName: '',
        guestEmail: '',
        guestPhone: '',
        checkInDate: '',
        checkOutDate: ''
      });
      alert(t.reservationSuccess + booking.reservationId);
    } catch (error) {
      alert(t.errorMakingReservation);
    }
  };

  const filteredRooms = rooms.filter(room =>
    room.roomNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    room.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getRoomTypeTranslation = (type: string) => {
    const typeMap: Record<string, string> = {
      'Standard': t.standard,
      'Deluxe': t.deluxe,
      'Suite': t.suite,
      'Family': t.family
    };
    return typeMap[type] || type;
  };

  const getStatusTranslation = (status: string) => {
    const statusMap: Record<string, string> = {
      'AVAILABLE': t.available,
      'BOOKED': t.booked,
      'MAINTENANCE': t.maintenance,
      'CONFIRMED': t.confirmed,
      'CANCELED': t.canceled,
      'COMPLETED': t.completed,
      'CHECKED_IN': t.checkedIn
    };
    return statusMap[status] || status;
  };

  return (
    <>
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-lg border-b border-emerald-100 shadow-sm">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-200">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-emerald-800 tracking-tight">Arika Homestay</h1>
                <p className="text-xs text-emerald-600 font-medium">{t.tagline}</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              <a href="#" className="text-emerald-700 hover:text-emerald-900 font-medium transition-colors flex items-center gap-2">
                <Home className="w-4 h-4" />
                {t.nav.home}
              </a>
              <a href="#" className="text-emerald-700 hover:text-emerald-900 font-medium transition-colors flex items-center gap-2">
                <Building2 className="w-4 h-4" />
                {t.nav.about}
              </a>
              <a href="#" className="text-emerald-700 hover:text-emerald-900 font-medium transition-colors flex items-center gap-2">
                <Mail className="w-4 h-4" />
                {t.nav.contact}
              </a>
            </nav>

            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLanguage(language === 'id' ? 'en' : 'id')}
                className="border-emerald-300 text-emerald-700 hover:bg-emerald-50 hover:border-emerald-400 font-medium"
              >
                <Languages className="w-4 h-4 mr-2" />
                {language === 'id' ? 'EN' : 'ID'}
              </Button>
              <Button
                onClick={onSwitchToAdmin}
                className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white shadow-lg shadow-emerald-200 font-medium"
              >
                <Settings className="w-4 h-4 mr-2" />
                {t.adminDashboard}
              </Button>

              {/* Mobile Menu Button */}
              <Button
                variant="ghost"
                size="sm"
                className="md:hidden"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-emerald-100 bg-white/95 backdrop-blur-lg">
            <nav className="container mx-auto px-4 py-4 space-y-3">
              <a href="#" className="block text-emerald-700 hover:text-emerald-900 font-medium py-2 flex items-center gap-2">
                <Home className="w-4 h-4" />
                {t.nav.home}
              </a>
              <a href="#" className="block text-emerald-700 hover:text-emerald-900 font-medium py-2 flex items-center gap-2">
                <Building2 className="w-4 h-4" />
                {t.nav.about}
              </a>
              <a href="#" className="block text-emerald-700 hover:text-emerald-900 font-medium py-2 flex items-center gap-2">
                <Mail className="w-4 h-4" />
                {t.nav.contact}
              </a>
            </nav>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-32">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-600 via-green-600 to-emerald-700 opacity-95" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMtOS45NDEgMC0xOCA4LjA1OS0xOCAxOHM4LjA1OSAxOCAxOCAxOGM5Ljk0MSAwIDE4LTguMDU5IDE4LTE4cy04LjA1OS0xOC0xOC0xOHptMCAzMmMtNy43MzIgMC0xNC02LjI2OC0xNC0xNHM2LjI2OC0xNCAxNC0xNHMxNCA2LjI2OCAxNCAxNC02LjI2OCAxNC0xNCAxNHoiIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIi8+PC9nPjwvc3ZnPg==')] opacity-30" />
        
        <div className="relative container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full mb-6 border border-white/30">
              <Sparkles className="w-4 h-4 text-yellow-300" />
              <span className="text-white/90 text-sm font-medium">{language === 'id' ? 'Pengalaman Menginap Terbaik' : 'Best Stay Experience'}</span>
            </div>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 tracking-tight leading-tight">
              {t.welcome}
            </h2>
            <p className="text-xl md:text-2xl text-white/90 mb-8 font-light max-w-2xl mx-auto">
              {t.description}
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button
                size="lg"
                onClick={() => document.getElementById('rooms-section')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-white text-emerald-700 hover:bg-emerald-50 font-semibold shadow-xl px-8"
              >
                {t.bookNow}
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white/10 font-semibold px-8"
              >
                {language === 'id' ? 'Pelajari Lebih Lanjut' : 'Learn More'}
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="border-emerald-100 hover:shadow-xl hover:border-emerald-200 transition-all duration-300 group">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-emerald-100 to-green-100 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Bed className="w-8 h-8 text-emerald-600" />
                </div>
                <h3 className="text-lg font-bold text-emerald-900 mb-2">{t.features.comfortable}</h3>
                <p className="text-emerald-700/70">{language === 'id' ? 'Kamar luas dengan fasilitas modern' : 'Spacious rooms with modern amenities'}</p>
              </CardContent>
            </Card>
            <Card className="border-emerald-100 hover:shadow-xl hover:border-emerald-200 transition-all duration-300 group">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-100 to-cyan-100 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Wifi className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-lg font-bold text-emerald-900 mb-2">{t.features.wifi}</h3>
                <p className="text-emerald-700/70">{language === 'id' ? 'Internet cepat dan gratis di semua kamar' : 'Fast and free internet in all rooms'}</p>
              </CardContent>
            </Card>
            <Card className="border-emerald-100 hover:shadow-xl hover:border-emerald-200 transition-all duration-300 group">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-amber-100 to-orange-100 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <MapPin className="w-8 h-8 text-amber-600" />
                </div>
                <h3 className="text-lg font-bold text-emerald-900 mb-2">{t.features.location}</h3>
                <p className="text-emerald-700/70">{language === 'id' ? 'Lokasi strategis dekat pusat kota' : 'Strategic location near city center'}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Search Form */}
      <section className="py-12 bg-gradient-to-b from-emerald-50 to-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="shadow-2xl border-emerald-200 max-w-4xl mx-auto">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <Calendar className="w-6 h-6 text-emerald-600" />
                <h3 className="text-2xl font-bold text-emerald-900">{t.searchAvailability}</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <Label htmlFor="check-in" className="text-emerald-800 font-semibold mb-2 block">{t.checkIn}</Label>
                  <Input
                    id="check-in"
                    type="date"
                    value={searchCheckIn}
                    onChange={(e) => setSearchCheckIn(e.target.value)}
                    className="border-emerald-300 focus:border-emerald-500 h-12 text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="check-out" className="text-emerald-800 font-semibold mb-2 block">{t.checkOut}</Label>
                  <Input
                    id="check-out"
                    type="date"
                    value={searchCheckOut}
                    onChange={(e) => setSearchCheckOut(e.target.value)}
                    className="border-emerald-300 focus:border-emerald-500 h-12 text-base"
                  />
                </div>
              </div>
              <Button
                onClick={() => setHasSearched(true)}
                disabled={!searchCheckIn || !searchCheckOut}
                className="w-full bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white font-semibold h-12 text-base shadow-lg shadow-emerald-200"
              >
                <Search className="w-5 h-5 mr-2" />
                {t.searchBtn}
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Rooms Section */}
      <section id="rooms-section" className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-emerald-900 mb-2">{t.ourRooms}</h2>
              <p className="text-emerald-700/80 text-lg">{t.roomsDesc}</p>
            </div>
            {!hasSearched && (
              <div className="relative w-full md:w-80">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-emerald-400" />
                <Input
                  placeholder={t.search}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 border-emerald-300 focus:border-emerald-500 h-12"
                />
              </div>
            )}
          </div>

          {hasSearched && searchCheckIn && searchCheckOut && (
            <div className="mb-6">
              <div className="flex items-center gap-3 bg-emerald-50 border border-emerald-200 px-6 py-4 rounded-xl">
                <CheckCircle className="w-6 h-6 text-emerald-600" />
                <p className="text-emerald-800 font-medium">
                  {t.showingRooms.replace('{count}', String(availableRoomsForDates.length))} - {searchCheckIn} to {searchCheckOut}
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => { setHasSearched(false); setSearchCheckIn(''); setSearchCheckOut(''); }}
                  className="ml-auto border-emerald-300 text-emerald-700 hover:bg-emerald-100"
                >
                  {language === 'id' ? 'Cari Lagi' : 'Search Again'}
                </Button>
              </div>
            </div>
          )}

          {availableRoomsForDates.length === 0 ? (
            <Card className="border-emerald-200 bg-emerald-50">
              <CardContent className="p-12 text-center">
                <XCircle className="w-16 h-16 text-emerald-400 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-emerald-900 mb-2">{t.noAvailableRooms}</h3>
                <p className="text-emerald-700/80">{language === 'id' ? 'Silakan coba tanggal lain' : 'Please try different dates'}</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {availableRoomsForDates.filter(room =>
                room.roomNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
                room.type.toLowerCase().includes(searchQuery.toLowerCase())
              ).map((room) => (
                <Card
                  key={room.id}
                  className="border-emerald-200 hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 overflow-hidden group"
                >
                  <div className="h-48 bg-gradient-to-br from-emerald-100 via-green-100 to-emerald-50 relative overflow-hidden">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Bed className="w-20 h-20 text-emerald-400/50" />
                    </div>
                    <div className="absolute top-4 right-4">
                      <Badge className={`
                        px-3 py-1 font-semibold text-sm
                        ${room.status === 'AVAILABLE' ? 'bg-emerald-500 hover:bg-emerald-600 text-white' : ''}
                        ${room.status === 'BOOKED' ? 'bg-amber-500 hover:bg-amber-600 text-white' : ''}
                        ${room.status === 'MAINTENANCE' ? 'bg-red-500 hover:bg-red-600 text-white' : ''}
                      `}>
                        {getStatusTranslation(room.status)}
                      </Badge>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-xl font-bold text-emerald-900">{t.room} {room.roomNumber}</h3>
                        <p className="text-emerald-700 font-medium">{getRoomTypeTranslation(room.type)}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-emerald-600">Rp {room.price.toLocaleString('id-ID')}</p>
                        <p className="text-sm text-emerald-600/70">{t.perNight}</p>
                      </div>
                    </div>
                    {room.amenities && (
                      <div className="flex flex-wrap gap-2 mb-4">
                        {room.amenities.split(',').slice(0, 3).map((amenity, idx) => (
                          <Badge key={idx} variant="outline" className="border-emerald-300 text-emerald-700 text-xs">
                            {amenity.trim()}
                          </Badge>
                        ))}
                      </div>
                    )}
                    <Button
                      onClick={() => handleMakeReservation(room)}
                      disabled={room.status !== 'AVAILABLE'}
                      className={`
                        w-full font-semibold h-12
                        ${room.status === 'AVAILABLE'
                          ? 'bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white shadow-lg shadow-emerald-200'
                          : 'bg-emerald-100 text-emerald-400 cursor-not-allowed'
                        }
                      `}
                    >
                      {t.bookNow}
                      <ChevronRight className="w-5 h-5 ml-2" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-emerald-800 to-green-900 text-white py-16 mt-auto">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                  <Building2 className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-xl font-bold">Arika Homestay</h4>
                  <p className="text-sm text-emerald-200">{t.tagline}</p>
                </div>
              </div>
              <p className="text-emerald-100/80 text-sm leading-relaxed">
                {language === 'id'
                  ? 'Tempat peristirahatan sempurna Anda dengan kenyamanan dan gaya. Kami berkomitmen memberikan pengalaman menginap terbaik.'
                  : 'Your perfect getaway destination with comfort and style. We are committed to providing the best stay experience.'
                }
              </p>
            </div>
            <div>
              <h4 className="font-bold text-lg mb-6">{t.contactUs}</h4>
              <div className="space-y-4">
                <div className="flex items-center gap-3 text-emerald-100/90">
                  <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
                    <Phone className="w-5 h-5" />
                  </div>
                  <span className="text-sm">+62 812 3456 7890</span>
                </div>
                <div className="flex items-center gap-3 text-emerald-100/90">
                  <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
                    <Mail className="w-5 h-5" />
                  </div>
                  <span className="text-sm">info@arikahomestay.com</span>
                </div>
                <div className="flex items-center gap-3 text-emerald-100/90">
                  <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <span className="text-sm">Jakarta, Indonesia</span>
                </div>
              </div>
            </div>
            <div>
              <h4 className="font-bold text-lg mb-6">{t.quickLinks}</h4>
              <div className="space-y-3 text-sm text-emerald-100/90">
                <a href="#" className="block hover:text-white transition-colors">{t.nav.home}</a>
                <a href="#" className="block hover:text-white transition-colors">{t.nav.about}</a>
                <a href="#" className="block hover:text-white transition-colors">{t.ourRooms}</a>
                <a href="#" className="block hover:text-white transition-colors">{t.nav.contact}</a>
              </div>
            </div>
          </div>
          <Separator className="my-8 bg-emerald-700/50" />
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-center text-sm text-emerald-200/80">{t.rights}</p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setLanguage(language === 'id' ? 'en' : 'id')}
              className="border-emerald-500 text-emerald-200 hover:bg-emerald-700/50"
            >
              <Languages className="w-4 h-4 mr-2" />
              {language === 'id' ? 'English' : 'Bahasa Indonesia'}
            </Button>
          </div>
        </div>
      </footer>

      {/* Reservation Dialog */}
      <ReservationDialog
        open={reservationDialogOpen}
        onOpenChange={setReservationDialogOpen}
        room={selectedRoom}
        form={reservationForm}
        setForm={setReservationForm}
        onSubmit={submitReservation}
        language={language}
        t={t}
      />
    </>
  );
}

function ReservationDialog({
  open,
  onOpenChange,
  room,
  form,
  setForm,
  onSubmit,
  language,
  t
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  room: Room | null;
  form: any;
  setForm: (form: any) => void;
  onSubmit: () => void;
  language: Language;
  t: typeof translations.en;
}) {
  if (!room) return null;

  const nights = Math.ceil((new Date(form.checkOutDate).getTime() - new Date(form.checkInDate).getTime()) / (1000 * 60 * 60 * 24));
  const totalCost = nights * room.price;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] border-emerald-200">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-emerald-900">{t.makeReservation}</DialogTitle>
          <DialogDescription className="text-emerald-700">
            {t.room} {room.roomNumber} - {room.type}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div>
            <Label htmlFor="guestName" className="text-emerald-800 font-medium">{t.fullName}</Label>
            <Input
              id="guestName"
              value={form.guestName}
              onChange={(e) => setForm({ ...form, guestName: e.target.value })}
              className="border-emerald-300 focus:border-emerald-500 h-11"
            />
          </div>
          <div>
            <Label htmlFor="guestEmail" className="text-emerald-800 font-medium">{t.email}</Label>
            <Input
              id="guestEmail"
              type="email"
              value={form.guestEmail}
              onChange={(e) => setForm({ ...form, guestEmail: e.target.value })}
              className="border-emerald-300 focus:border-emerald-500 h-11"
            />
          </div>
          <div>
            <Label htmlFor="guestPhone" className="text-emerald-800 font-medium">{t.phone}</Label>
            <Input
              id="guestPhone"
              value={form.guestPhone}
              onChange={(e) => setForm({ ...form, guestPhone: e.target.value })}
              className="border-emerald-300 focus:border-emerald-500 h-11"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="checkIn" className="text-emerald-800 font-medium">{t.checkIn}</Label>
              <Input
                id="checkIn"
                type="date"
                value={form.checkInDate}
                onChange={(e) => setForm({ ...form, checkInDate: e.target.value })}
                className="border-emerald-300 focus:border-emerald-500 h-11"
              />
            </div>
            <div>
              <Label htmlFor="checkOut" className="text-emerald-800 font-medium">{t.checkOut}</Label>
              <Input
                id="checkOut"
                type="date"
                value={form.checkOutDate}
                onChange={(e) => setForm({ ...form, checkOutDate: e.target.value })}
                className="border-emerald-300 focus:border-emerald-500 h-11"
              />
            </div>
          </div>
          <div className="bg-emerald-50 rounded-xl p-4 border border-emerald-200">
            <div className="flex justify-between text-emerald-800 mb-2">
              <span>{nights} {t.nights}</span>
              <span className="font-semibold">Rp {(nights * room.price).toLocaleString('id-ID')}</span>
            </div>
            <Separator className="my-2 bg-emerald-300" />
            <div className="flex justify-between text-lg font-bold text-emerald-900">
              <span>{t.total}</span>
              <span>Rp {totalCost.toLocaleString('id-ID')}</span>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="border-emerald-300 text-emerald-700 hover:bg-emerald-50 h-11"
          >
            {t.cancel}
          </Button>
          <Button
            onClick={onSubmit}
            className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white font-semibold h-11 px-8 shadow-lg shadow-emerald-200"
          >
            {t.confirm}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function AdminDashboard({
  onBackToPublic,
  language,
  setLanguage,
  t
}: {
  onBackToPublic: () => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations.en;
}) {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [guests, setGuests] = useState<Guest[]>([]);
  const [activeTab, setActiveTab] = useState<'rooms' | 'bookings' | 'guests'>('rooms');
  const [searchQuery, setSearchQuery] = useState('');
  const [newRoom, setNewRoom] = useState<Partial<Room>>({
    roomNumber: '',
    type: 'Standard',
    price: 0,
    status: 'AVAILABLE',
    amenities: 'WiFi,AC,TV'
  });
  const [editingRoom, setEditingRoom] = useState<Room | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);

  const loadData = async () => {
    try {
      const [roomsRes, bookingsRes, guestsRes] = await Promise.all([
        fetch('/api/rooms'),
        fetch('/api/bookings'),
        fetch('/api/guests')
      ]);
      const roomsData = await roomsRes.json();
      const bookingsData = await bookingsRes.json();
      const guestsData = await guestsRes.json();

      setRooms(roomsData);
      setBookings(bookingsData.map((b: any) => ({
        ...b,
        checkInDate: new Date(b.checkInDate).toISOString(),
        checkOutDate: new Date(b.checkOutDate).toISOString()
      })));
      setGuests(guestsData);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    loadData();
  }, []);

  const getRoomTypeTranslation = (type: string) => {
    const typeMap: Record<string, string> = {
      'Standard': t.standard,
      'Deluxe': t.deluxe,
      'Suite': t.suite,
      'Family': t.family
    };
    return typeMap[type] || type;
  };

  const getStatusTranslation = (status: string) => {
    const statusMap: Record<string, string> = {
      'AVAILABLE': t.available,
      'BOOKED': t.booked,
      'MAINTENANCE': t.maintenance,
      'CONFIRMED': t.confirmed,
      'CANCELED': t.canceled,
      'COMPLETED': t.completed,
      'CHECKED_IN': t.checkedIn
    };
    return statusMap[status] || status;
  };

  const createRoom = async () => {
    try {
      await fetch('/api/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newRoom)
      });
      setNewRoom({
        roomNumber: '',
        type: 'Standard',
        price: 0,
        status: 'AVAILABLE',
        amenities: 'WiFi,AC,TV'
      });
      await loadData();
      alert(t.roomCreated);
    } catch (error) {
      alert(t.errorCreatingRoom);
    }
  };

  const editRoom = (room: Room) => {
    setEditingRoom(room);
    setNewRoom({
      roomNumber: room.roomNumber,
      type: room.type,
      price: room.price,
      status: room.status,
      amenities: room.amenities
    });
    setEditDialogOpen(true);
  };

  const updateExistingRoom = async () => {
    if (!editingRoom) return;
    try {
      await fetch(`/api/rooms/${editingRoom.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roomNumber: newRoom.roomNumber,
          type: newRoom.type,
          price: newRoom.price,
          amenities: newRoom.amenities
        })
      });
      setEditingRoom(null);
      setEditDialogOpen(false);
      await loadData();
      alert(t.roomUpdated);
    } catch (error) {
      alert(t.errorCreatingRoom);
    }
  };

  const updateBookingStatus = async (bookingId: string, status: string) => {
    try {
      await fetch(`/api/bookings/${bookingId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });

      const booking = bookings.find(b => b.id === bookingId);
      if (booking) {
        const newRoomStatus = status === 'CONFIRMED' ? 'BOOKED' :
                              status === 'CHECKED_IN' ? 'BOOKED' :
                              status === 'COMPLETED' || status === 'CANCELED' ? 'AVAILABLE' : 'AVAILABLE';
        await fetch(`/api/rooms/${booking.roomId}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: newRoomStatus })
        });
      }
      await loadData();
      alert(t.bookingStatusUpdated);
    } catch (error) {
      alert(t.errorCancelingBooking);
    }
  };

  const cancelBooking = async (bookingId: string) => {
    try {
      await updateBookingStatus(bookingId, 'CANCELED');
    } catch (error) {
      alert(t.errorCancelingBooking);
    }
  };

  const deleteRoom = async (roomId: string) => {
    if (confirm(t.deleteRoomConfirm)) {
      try {
        await fetch(`/api/rooms/${roomId}`, {
          method: 'DELETE'
        });
        await loadData();
        alert(t.roomDeleted);
      } catch (error) {
        alert(t.errorCreatingRoom);
      }
    }
  };

  const updateRoomStatus = async (roomId: string, status: string) => {
    try {
      await fetch(`/api/rooms/${roomId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      await loadData();
      alert(t.roomStatusUpdated);
    } catch (error) {
      alert(t.errorUpdatingRoom);
    }
  };

  // Calculate metrics
  const totalRooms = rooms.length;
  const availableToday = rooms.filter(r => r.status === 'AVAILABLE').length;
  const today = new Date();
  const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  const lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
  const monthlyBookings = bookings.filter(b => {
    const bookingDate = new Date(b.checkInDate);
    return bookingDate >= firstDayOfMonth && bookingDate < lastDayOfMonth;
  });
  const monthlyRevenue = monthlyBookings.reduce((sum, booking) => {
    if (booking.status === 'CONFIRMED' || booking.status === 'COMPLETED' || booking.status === 'CHECKED_IN') {
      return sum + booking.totalCost;
    }
    return sum;
  }, 0);

  const filteredRooms = rooms.filter(room =>
    room.roomNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    room.type.toLowerCase().includes(searchQuery.toLowerCase())
  );
  const filteredBookings = bookings.filter(booking =>
    booking.reservationId.toLowerCase().includes(searchQuery.toLowerCase())
  );
  const filteredGuests = guests.filter(guest =>
    guest.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    guest.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-emerald-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-lg border-b border-emerald-100 shadow-sm">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-200">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-emerald-800 tracking-tight">{t.adminPanel}</h1>
                <p className="text-sm text-emerald-600">{t.tagline}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLanguage(language === 'id' ? 'en' : 'id')}
                className="border-emerald-400 text-emerald-700 hover:bg-emerald-50 hover:border-emerald-500 font-medium"
              >
                <Globe className="w-4 h-4 mr-2" />
                {language === 'id' ? 'EN' : 'ID'}
              </Button>
              <Button
                onClick={onBackToPublic}
                className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white shadow-lg shadow-emerald-200 font-medium"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                {t.backToPublic}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex-1 flex">
        {/* Sidebar */}
        <aside className="w-72 bg-white border-r border-emerald-100 min-h-[calc(100vh-5rem)] hidden lg:block shadow-lg">
          <div className="p-6">
            {/* Metrics */}
            <h3 className="text-sm font-bold text-emerald-900 uppercase tracking-wider mb-4">{t.dashboardSummary}</h3>
            <div className="space-y-3 mb-8">
              <div className="bg-gradient-to-br from-emerald-50 to-green-50 p-4 rounded-xl border border-emerald-200">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-green-600 rounded-lg flex items-center justify-center shadow-md">
                    <Building2 className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-xs font-medium text-emerald-600">{t.totalRooms}</p>
                    <p className="text-2xl font-bold text-emerald-800">{totalRooms}</p>
                  </div>
                </div>
              </div>
              <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-4 rounded-xl border border-green-200">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg flex items-center justify-center shadow-md">
                    <CheckCircle className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-xs font-medium text-green-600">{t.availableToday}</p>
                    <p className="text-2xl font-bold text-green-800">{availableToday}</p>
                  </div>
                </div>
              </div>
              <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-4 rounded-xl border border-amber-200">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-600 rounded-lg flex items-center justify-center shadow-md">
                    <Calendar className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-xs font-medium text-amber-600">{t.monthlyRevenue}</p>
                    <p className="text-xl font-bold text-amber-800">Rp {monthlyRevenue.toLocaleString('id-ID')}</p>
                  </div>
                </div>
              </div>
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-4 rounded-xl border border-blue-200">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center shadow-md">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-xs font-medium text-blue-600">{t.stats.totalBookingsThisMonth}</p>
                    <p className="text-xl font-bold text-blue-800">{monthlyBookings.length}</p>
                  </div>
                </div>
              </div>
            </div>

            <Separator className="my-6 bg-emerald-200" />

            {/* Navigation */}
            <nav className="space-y-2">
              <Button
                variant={activeTab === 'rooms' ? 'default' : 'ghost'}
                onClick={() => setActiveTab('rooms')}
                className={`
                  w-full justify-start h-12 font-medium
                  ${activeTab === 'rooms'
                    ? 'bg-gradient-to-r from-emerald-600 to-green-600 text-white shadow-lg shadow-emerald-200'
                    : 'text-emerald-700 hover:bg-emerald-50'
                  }
                `}
              >
                <Bed className="w-5 h-5 mr-3" />
                {t.roomsTab}
              </Button>
              <Button
                variant={activeTab === 'bookings' ? 'default' : 'ghost'}
                onClick={() => setActiveTab('bookings')}
                className={`
                  w-full justify-start h-12 font-medium
                  ${activeTab === 'bookings'
                    ? 'bg-gradient-to-r from-emerald-600 to-green-600 text-white shadow-lg shadow-emerald-200'
                    : 'text-emerald-700 hover:bg-emerald-50'
                  }
                `}
              >
                <Calendar className="w-5 h-5 mr-3" />
                {t.bookingsTab}
              </Button>
              <Button
                variant={activeTab === 'guests' ? 'default' : 'ghost'}
                onClick={() => setActiveTab('guests')}
                className={`
                  w-full justify-start h-12 font-medium
                  ${activeTab === 'guests'
                    ? 'bg-gradient-to-r from-emerald-600 to-green-600 text-white shadow-lg shadow-emerald-200'
                    : 'text-emerald-700 hover:bg-emerald-50'
                  }
                `}
              >
                <Users className="w-5 h-5 mr-3" />
                {t.guestsTab}
              </Button>
            </nav>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 lg:p-8 overflow-y-auto">
          <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
            <div className="mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h2 className="text-3xl font-bold text-emerald-900 capitalize">{activeTab}</h2>
                <p className="text-emerald-700/80 mt-1">
                  {language === 'id' ? 'Kelola data ' + activeTab : 'Manage ' + activeTab}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <div className="relative w-72">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-emerald-400" />
                  <Input
                    placeholder={t.search}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 border-emerald-300 focus:border-emerald-500 h-12"
                  />
                </div>
                {activeTab === 'rooms' && (
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white font-semibold h-12 shadow-lg shadow-emerald-200">
                        <Plus className="w-5 h-5 mr-2" />
                        {t.addRoom}
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="border-emerald-200">
                      <DialogHeader>
                        <DialogTitle className="text-xl font-bold text-emerald-900">{t.addNewRoom}</DialogTitle>
                        <DialogDescription className="text-emerald-700">{t.enterRoomDetails}</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div>
                          <Label htmlFor="roomNumber" className="text-emerald-800 font-medium">{t.roomNumber}</Label>
                          <Input
                            id="roomNumber"
                            value={newRoom.roomNumber}
                            onChange={(e) => setNewRoom({ ...newRoom, roomNumber: e.target.value })}
                            className="border-emerald-300 focus:border-emerald-500 h-11"
                          />
                        </div>
                        <div>
                          <Label htmlFor="roomType" className="text-emerald-800 font-medium">{t.roomType}</Label>
                          <Select value={newRoom.type} onValueChange={(value) => setNewRoom({ ...newRoom, type: value })}>
                            <SelectTrigger className="border-emerald-300 focus:border-emerald-500 h-11">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Standard">{t.standard}</SelectItem>
                              <SelectItem value="Deluxe">{t.deluxe}</SelectItem>
                              <SelectItem value="Suite">{t.suite}</SelectItem>
                              <SelectItem value="Family">{t.family}</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="price" className="text-emerald-800 font-medium">{t.pricePerNight}</Label>
                          <Input
                            id="price"
                            type="number"
                            value={newRoom.price}
                            onChange={(e) => setNewRoom({ ...newRoom, price: Number(e.target.value) })}
                            className="border-emerald-300 focus:border-emerald-500 h-11"
                          />
                        </div>
                        <div>
                          <Label htmlFor="amenities" className="text-emerald-800 font-medium">{t.amenities}</Label>
                          <Input
                            id="amenities"
                            value={newRoom.amenities}
                            onChange={(e) => setNewRoom({ ...newRoom, amenities: e.target.value })}
                            className="border-emerald-300 focus:border-emerald-500 h-11"
                          />
                        </div>
                        <div>
                          <Label htmlFor="status" className="text-emerald-800 font-medium">{t.status}</Label>
                          <Select value={newRoom.status} onValueChange={(value) => setNewRoom({ ...newRoom, status: value as any })}>
                            <SelectTrigger className="border-emerald-300 focus:border-emerald-500 h-11">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="AVAILABLE">{t.available}</SelectItem>
                              <SelectItem value="BOOKED">{t.booked}</SelectItem>
                              <SelectItem value="MAINTENANCE">{t.maintenance}</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button onClick={createRoom} className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white font-semibold h-11 px-8 shadow-lg shadow-emerald-200">
                          {t.createRoom}
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                )}
              </div>
            </div>

            {/* Rooms Tab */}
            <TabsContent value="rooms">
              <Card className="border-emerald-200 shadow-lg">
                <ScrollArea className="max-h-[calc(100vh-300px)]">
                  <div className="divide-y divide-emerald-100">
                    {filteredRooms.length === 0 ? (
                      <CardContent className="p-12 text-center">
                        <Bed className="w-16 h-16 text-emerald-400 mx-auto mb-4" />
                        <h3 className="text-xl font-bold text-emerald-900 mb-2">{t.noRooms}</h3>
                      </CardContent>
                    ) : (
                      filteredRooms.map((room) => (
                        <div key={room.id} className="p-6 hover:bg-emerald-50/50 transition-colors">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <div className="w-12 h-12 bg-gradient-to-br from-emerald-100 to-green-100 rounded-lg flex items-center justify-center">
                                  <Bed className="w-6 h-6 text-emerald-600" />
                                </div>
                                <div>
                                  <h4 className="text-lg font-bold text-emerald-900">{t.room} {room.roomNumber}</h4>
                                  <p className="text-emerald-700/80">{getRoomTypeTranslation(room.type)}</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-4 mt-3">
                                <Badge className={`
                                  px-3 py-1 font-medium
                                  ${room.status === 'AVAILABLE' ? 'bg-emerald-500 text-white' : ''}
                                  ${room.status === 'BOOKED' ? 'bg-amber-500 text-white' : ''}
                                  ${room.status === 'MAINTENANCE' ? 'bg-red-500 text-white' : ''}
                                `}>
                                  {getStatusTranslation(room.status)}
                                </Badge>
                                <span className="text-emerald-700 font-semibold">Rp {room.price.toLocaleString('id-ID')}</span>
                                {room.amenities && (
                                  <span className="text-sm text-emerald-600/70 truncate max-w-xs">
                                    {room.amenities}
                                  </span>
                                )}
                              </div>
                            </div>
                            <div className="flex gap-2 ml-4">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => editRoom(room)}
                                className="border-emerald-300 text-emerald-700 hover:bg-emerald-50"
                              >
                                <Edit className="w-4 h-4 mr-1" />
                                {t.editRoom}
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => deleteRoom(room.id)}
                                className="border-red-300 text-red-600 hover:bg-red-50"
                              >
                                <Trash2 className="w-4 h-4 mr-1" />
                                {t.deleteRoom}
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </Card>
            </TabsContent>

            {/* Bookings Tab */}
            <TabsContent value="bookings">
              <Card className="border-emerald-200 shadow-lg">
                <ScrollArea className="max-h-[calc(100vh-300px)]">
                  <div className="divide-y divide-emerald-100">
                    {filteredBookings.length === 0 ? (
                      <CardContent className="p-12 text-center">
                        <Calendar className="w-16 h-16 text-emerald-400 mx-auto mb-4" />
                        <h3 className="text-xl font-bold text-emerald-900 mb-2">{language === 'id' ? 'Tidak ada pemesanan' : 'No bookings'}</h3>
                      </CardContent>
                    ) : (
                      filteredBookings.map((booking) => (
                        <div key={booking.id} className="p-6 hover:bg-emerald-50/50 transition-colors">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-lg flex items-center justify-center">
                                  <Calendar className="w-6 h-6 text-blue-600" />
                                </div>
                                <div>
                                  <h4 className="text-lg font-bold text-emerald-900">{booking.reservationId}</h4>
                                  <p className="text-emerald-700/80">
                                    {booking.room ? `${t.room} ${booking.room.roomNumber}` : 'N/A'} - {booking.guest?.name}
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center gap-4 mt-3">
                                <Badge className={`
                                  px-3 py-1 font-medium
                                  ${booking.status === 'CONFIRMED' ? 'bg-blue-500 text-white' : ''}
                                  ${booking.status === 'CHECKED_IN' ? 'bg-green-500 text-white' : ''}
                                  ${booking.status === 'COMPLETED' ? 'bg-gray-500 text-white' : ''}
                                  ${booking.status === 'CANCELED' ? 'bg-red-500 text-white' : ''}
                                `}>
                                  {getStatusTranslation(booking.status)}
                                </Badge>
                                <span className="text-emerald-700/80 text-sm">
                                  {new Date(booking.checkInDate).toLocaleDateString('id-ID')} - {new Date(booking.checkOutDate).toLocaleDateString('id-ID')}
                                </span>
                                <span className="text-emerald-700 font-semibold">Rp {booking.totalCost.toLocaleString('id-ID')}</span>
                              </div>
                            </div>
                            <div className="flex gap-2 ml-4">
                              <Select
                                value={booking.status}
                                onValueChange={(value) => updateBookingStatus(booking.id, value)}
                                className="w-44"
                              >
                                <SelectTrigger className="border-emerald-300 h-10">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="CONFIRMED">{t.confirmed}</SelectItem>
                                  <SelectItem value="CHECKED_IN">{t.checkedIn}</SelectItem>
                                  <SelectItem value="COMPLETED">{t.completed}</SelectItem>
                                  <SelectItem value="CANCELED">{t.canceled}</SelectItem>
                                </SelectContent>
                              </Select>
                              {booking.status === 'CONFIRMED' && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => cancelBooking(booking.id)}
                                  className="border-red-300 text-red-600 hover:bg-red-50"
                                >
                                  <XCircle className="w-4 h-4" />
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </Card>
            </TabsContent>

            {/* Guests Tab */}
            <TabsContent value="guests">
              <Card className="border-emerald-200 shadow-lg">
                <ScrollArea className="max-h-[calc(100vh-300px)]">
                  <div className="divide-y divide-emerald-100">
                    {filteredGuests.length === 0 ? (
                      <CardContent className="p-12 text-center">
                        <Users className="w-16 h-16 text-emerald-400 mx-auto mb-4" />
                        <h3 className="text-xl font-bold text-emerald-900 mb-2">{language === 'id' ? 'Tidak ada tamu' : 'No guests'}</h3>
                      </CardContent>
                    ) : (
                      filteredGuests.map((guest) => (
                        <div key={guest.id} className="p-6 hover:bg-emerald-50/50 transition-colors">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-4">
                              <div className="w-12 h-12 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full flex items-center justify-center">
                                <Users className="w-6 h-6 text-purple-600" />
                              </div>
                              <div>
                                <h4 className="text-lg font-bold text-emerald-900">{guest.name}</h4>
                                <div className="flex flex-col gap-1 mt-1">
                                  <div className="flex items-center gap-2 text-emerald-700/80 text-sm">
                                    <Mail className="w-4 h-4" />
                                    <span>{guest.email}</span>
                                  </div>
                                  <div className="flex items-center gap-2 text-emerald-700/80 text-sm">
                                    <Phone className="w-4 h-4" />
                                    <span>{guest.phone}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>

      {/* Edit Room Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="border-emerald-200">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-emerald-900">{t.editRoom}</DialogTitle>
            <DialogDescription className="text-emerald-700">{t.enterRoomDetails}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="editRoomNumber" className="text-emerald-800 font-medium">{t.roomNumber}</Label>
              <Input
                id="editRoomNumber"
                value={newRoom.roomNumber}
                onChange={(e) => setNewRoom({ ...newRoom, roomNumber: e.target.value })}
                className="border-emerald-300 focus:border-emerald-500 h-11"
              />
            </div>
            <div>
              <Label htmlFor="editRoomType" className="text-emerald-800 font-medium">{t.roomType}</Label>
              <Select value={newRoom.type} onValueChange={(value) => setNewRoom({ ...newRoom, type: value })}>
                <SelectTrigger className="border-emerald-300 focus:border-emerald-500 h-11">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Standard">{t.standard}</SelectItem>
                  <SelectItem value="Deluxe">{t.deluxe}</SelectItem>
                  <SelectItem value="Suite">{t.suite}</SelectItem>
                  <SelectItem value="Family">{t.family}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="editPrice" className="text-emerald-800 font-medium">{t.pricePerNight}</Label>
              <Input
                id="editPrice"
                type="number"
                value={newRoom.price}
                onChange={(e) => setNewRoom({ ...newRoom, price: Number(e.target.value) })}
                className="border-emerald-300 focus:border-emerald-500 h-11"
              />
            </div>
            <div>
              <Label htmlFor="editAmenities" className="text-emerald-800 font-medium">{t.amenities}</Label>
              <Input
                id="editAmenities"
                value={newRoom.amenities}
                onChange={(e) => setNewRoom({ ...newRoom, amenities: e.target.value })}
                className="border-emerald-300 focus:border-emerald-500 h-11"
              />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={updateExistingRoom} className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white font-semibold h-11 px-8 shadow-lg shadow-emerald-200">
              {t.updateRoom}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
