'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth, isSuperAdmin } from '@/contexts/AuthContext';
import { Building2, Menu, X, ArrowLeft, Plus, Edit, Trash2, Search, Shield, Users, Calendar, Clock, ChevronRight, CheckCircle, LogOut, UserPlus, Activity, Settings, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

type Language = 'id' | 'en';

interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  role: 'SUPER_ADMIN' | 'FRONT_DESK' | 'HOUSEKEEPING';
  isActive: boolean;
  createdAt: string;
}

interface ActivityLog {
  id: string;
  userId: string;
  action: string;
  entityType?: string;
  entityId?: string;
  details?: string;
  ipAddress?: string;
  createdAt: string;
  user?: {
    id: string;
    name: string;
    email: string;
    role: string;
  };
}

const translations = {
  id: {
    adminPanel: 'Dasbor Admin',
    users: 'Pengguna',
    activityLogs: 'Log Aktivitas',
    addUser: 'Tambah Pengguna',
    editUser: 'Edit Pengguna',
    deleteUser: 'Hapus Pengguna',
    email: 'Email',
    name: 'Nama',
    phone: 'Telepon',
    role: 'Peran',
    status: 'Status',
    active: 'Aktif',
    inactive: 'Nonaktif',
    action: 'Aksi',
    confirmDelete: 'Apakah Anda yakin ingin menghapus pengguna ini?',
    search: 'Cari...',
    addNewUser: 'Tambah Pengguna Baru',
    userDetails: 'Detail Pengguna',
    create: 'Buat',
    update: 'Perbarui',
    cancel: 'Batal',
    save: 'Simpan',
    userCreated: 'Pengguna berhasil dibuat',
    userUpdated: 'Pengguna berhasil diperbarui',
    userDeleted: 'Pengguna berhasil dihapus',
    roles: {
      SUPER_ADMIN: 'Super Admin',
      FRONT_DESK: 'Front Desk',
      HOUSEKEEPING: 'Housekeeping'
    },
    actions: {
      LOGIN: 'Login',
      LOGOUT: 'Logout',
      USER_CREATED: 'User Dibuat',
      USER_UPDATED: 'User Diperbarui',
      USER_DELETED: 'User Dihapus',
      ROOM_CREATED: 'Kamar Dibuat',
      ROOM_UPDATED: 'Kamar Diperbarui',
      ROOM_DELETED: 'Kamar Dihapus',
      BOOKING_CREATED: 'Reservasi Dibuat',
      BOOKING_UPDATED: 'Reservasi Diperbarui',
      BOOKING_CANCELED: 'Reservasi Dibatalkan',
      BOOKING_CHECKED_IN: 'Check-In Dilakukan',
      BOOKING_COMPLETED: 'Reservasi Selesai'
    }
  },
  en: {
    adminPanel: 'Admin Panel',
    users: 'Users',
    activityLogs: 'Activity Logs',
    addUser: 'Add User',
    editUser: 'Edit User',
    deleteUser: 'Delete User',
    email: 'Email',
    name: 'Name',
    phone: 'Phone',
    role: 'Role',
    status: 'Status',
    active: 'Active',
    inactive: 'Inactive',
    action: 'Actions',
    confirmDelete: 'Are you sure you want to delete this user?',
    search: 'Search...',
    addNewUser: 'Add New User',
    userDetails: 'User Details',
    create: 'Create',
    update: 'Update',
    cancel: 'Cancel',
    save: 'Save',
    userCreated: 'User created successfully',
    userUpdated: 'User updated successfully',
    userDeleted: 'User deleted successfully',
    roles: {
      SUPER_ADMIN: 'Super Admin',
      FRONT_DESK: 'Front Desk',
      HOUSEKEEPING: 'Housekeeping'
    },
    actions: {
      LOGIN: 'Login',
      LOGOUT: 'Logout',
      USER_CREATED: 'User Created',
      USER_UPDATED: 'User Updated',
      USER_DELETED: 'User Deleted',
      ROOM_CREATED: 'Room Created',
      ROOM_UPDATED: 'Room Updated',
      ROOM_DELETED: 'Room Deleted',
      BOOKING_CREATED: 'Booking Created',
      BOOKING_UPDATED: 'Booking Updated',
      BOOKING_CANCELED: 'Booking Canceled',
      BOOKING_CHECKED_IN: 'Check-In Done',
      BOOKING_COMPLETED: 'Booking Completed'
    }
  }
};

export default function AdminPage() {
  const router = useRouter();
  const { user, isAuthenticated, logout } = useAuth();
  const [language, setLanguage] = useState<Language>('id');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'users' | 'activity'>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [users, setUsers] = useState<User[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [newUser, setNewUser] = useState<Partial<User>>({
    email: '',
    name: '',
    phone: '',
    role: 'FRONT_DESK',
    isActive: true
  });
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const t = translations[language];

  const loadUsers = async () => {
    try {
      const response = await fetch('/api/users');
      const data = await response.json();
      setUsers(data);
    } catch (error) {
      console.error('Failed to load users:', error);
    }
  };

  const loadActivityLogs = async () => {
    try {
      const response = await fetch('/api/activity-logs?limit=50');
      const data = await response.json();
      setActivityLogs(data.logs || []);
    } catch (error) {
      console.error('Failed to load activity logs:', error);
    }
  };

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login');
      return;
    }
    // Load data when authenticated
    /* eslint-disable react-hooks/set-state-in-effect */
    void loadUsers();
    void loadActivityLogs();
    /* eslint-enable react-hooks/set-state-in-effect */
  }, [isAuthenticated]);

  const handleCreateUser = async () => {
    try {
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newUser)
      });

      if (response.ok) {
        setNewUser({
          email: '',
          name: '',
          phone: '',
          role: 'FRONT_DESK',
          isActive: true
        });
        setDialogOpen(false);
        loadUsers();
        alert(t.userCreated);
      } else {
        const error = await response.json();
        alert(error.error || 'Failed to create user');
      }
    } catch (error) {
      console.error('Failed to create user:', error);
      alert('Failed to create user');
    }
  };

  const handleUpdateUser = async () => {
    if (!editingUser) return;

    try {
      const response = await fetch(`/api/users/${editingUser.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newUser,
          password: newUser.password // Only include if changing password
        })
      });

      if (response.ok) {
        setEditingUser(null);
        setDialogOpen(false);
        setNewUser({
          email: '',
          name: '',
          phone: '',
          role: 'FRONT_DESK',
          isActive: true
        });
        loadUsers();
        alert(t.userUpdated);
      } else {
        const error = await response.json();
        alert(error.error || 'Failed to update user');
      }
    } catch (error) {
      console.error('Failed to update user:', error);
      alert('Failed to update user');
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm(t.confirmDelete)) return;

    try {
      const response = await fetch(`/api/users/${userId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        loadUsers();
        alert(t.userDeleted);
      } else {
        const error = await response.json();
        alert(error.error || 'Failed to delete user');
      }
    } catch (error) {
      console.error('Failed to delete user:', error);
      alert('Failed to delete user');
    }
  };

  const handleEditUser = (user: User) => {
    setEditingUser(user);
    setNewUser({
      email: user.email,
      name: user.name,
      phone: user.phone,
      role: user.role,
      isActive: user.isActive
    });
    setDialogOpen(true);
  };

  const handleLogout = () => {
    logout();
    router.push('/login');
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'SUPER_ADMIN':
        return 'bg-purple-500 text-white';
      case 'FRONT_DESK':
        return 'bg-blue-500 text-white';
      case 'HOUSEKEEPING':
        return 'bg-amber-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  const getActionBadgeColor = (action: string) => {
    if (action.includes('CREATED')) return 'bg-green-100 text-green-700 border-green-200';
    if (action.includes('UPDATED')) return 'bg-blue-100 text-blue-700 border-blue-200';
    if (action.includes('DELETED')) return 'bg-red-100 text-red-700 border-red-200';
    if (action.includes('LOGIN')) return 'bg-emerald-100 text-emerald-700 border-emerald-200';
    if (action.includes('LOGOUT')) return 'bg-gray-100 text-gray-700 border-gray-200';
    return 'bg-gray-100 text-gray-700 border-gray-200';
  };

  const filteredUsers = users.filter(u =>
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredActivityLogs = activityLogs.filter(log =>
    log.user?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    log.action.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-emerald-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-lg border-b border-emerald-100 shadow-sm">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-200">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-emerald-800 tracking-tight">{t.adminPanel}</h1>
                <p className="text-sm text-emerald-600">Arika Homestay Management System</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge className={`
                px-3 py-1 font-semibold text-sm
                ${user?.role === 'SUPER_ADMIN' ? 'bg-purple-500 text-white' : ''}
                ${user?.role === 'FRONT_DESK' ? 'bg-blue-500 text-white' : ''}
                ${user?.role === 'HOUSEKEEPING' ? 'bg-amber-500 text-white' : ''}
              `}>
                {t.roles[user?.role || 'FRONT_DESK']}
              </Badge>
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="border-emerald-400 text-emerald-700 hover:bg-emerald-50 hover:border-emerald-500"
              >
                <LogOut className="w-4 h-4 mr-2" />
                {language === 'id' ? 'Keluar' : 'Logout'}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex-1 flex">
        {/* Sidebar */}
        <aside className={`${sidebarOpen ? 'w-72' : 'w-0'} bg-white border-r border-emerald-100 min-h-[calc(100vh-5rem)] hidden lg:block overflow-hidden transition-all duration-300 shadow-lg`}>
          <div className="p-6 h-full">
            <nav className="space-y-2">
              <Button
                variant={activeTab === 'dashboard' ? 'default' : 'ghost'}
                onClick={() => setActiveTab('dashboard')}
                className={`
                  w-full justify-start h-12 font-medium
                  ${activeTab === 'dashboard'
                    ? 'bg-gradient-to-r from-emerald-600 to-green-600 text-white shadow-lg shadow-emerald-200'
                    : 'text-emerald-700 hover:bg-emerald-50'
                  }
                `}
              >
                <Settings className="w-5 h-5 mr-3" />
                {language === 'id' ? 'Ringkasan' : 'Dashboard'}
              </Button>
              {isSuperAdmin(user?.role) && (
                <Button
                  variant={activeTab === 'users' ? 'default' : 'ghost'}
                  onClick={() => setActiveTab('users')}
                  className={`
                    w-full justify-start h-12 font-medium
                    ${activeTab === 'users'
                      ? 'bg-gradient-to-r from-emerald-600 to-green-600 text-white shadow-lg shadow-emerald-200'
                      : 'text-emerald-700 hover:bg-emerald-50'
                    }
                  `}
                >
                  <Users className="w-5 h-5 mr-3" />
                  {t.users}
                </Button>
              )}
              <Button
                variant={activeTab === 'activity' ? 'default' : 'ghost'}
                onClick={() => setActiveTab('activity')}
                className={`
                  w-full justify-start h-12 font-medium
                  ${activeTab === 'activity'
                    ? 'bg-gradient-to-r from-emerald-600 to-green-600 text-white shadow-lg shadow-emerald-200'
                    : 'text-emerald-700 hover:bg-emerald-50'
                  }
                `}
              >
                <Activity className="w-5 h-5 mr-3" />
                {t.activityLogs}
              </Button>
            </nav>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 lg:p-8 overflow-y-auto">
          {/* Dashboard Tab */}
          {activeTab === 'dashboard' && (
            <Card className="border-emerald-200 shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-emerald-900">
                  {language === 'id' ? 'Selamat Datang' : 'Welcome'}, {user?.name}
                </CardTitle>
                <CardDescription className="text-emerald-700 text-base">
                  {user?.role === 'SUPER_ADMIN' && language === 'id'
                    ? 'Anda memiliki akses penuh sebagai Super Admin'
                    : user?.role === 'SUPER_ADMIN'
                    ? 'You have full access as Super Admin'
                    : user?.role === 'FRONT_DESK' && language === 'id'
                    ? 'Anda dapat mengelola reservasi dan check-in/out'
                    : user?.role === 'FRONT_DESK'
                    ? 'You can manage reservations and check-in/out'
                    : language === 'id'
                    ? 'Anda dapat mengelola status kebersihan kamar'
                    : 'You can manage room cleanliness status'
                  }
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-gradient-to-br from-emerald-50 to-green-50 p-6 rounded-xl border border-emerald-200">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 bg-gradient-to-br from-emerald-500 to-green-600 rounded-xl flex items-center justify-center shadow-md">
                        <Users className="w-7 h-7 text-white" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-emerald-600">Total Users</p>
                        <p className="text-3xl font-bold text-emerald-800">{users.length}</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-6 rounded-xl border border-blue-200">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl flex items-center justify-center shadow-md">
                        <Shield className="w-7 h-7 text-white" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-blue-600">Super Admins</p>
                        <p className="text-3xl font-bold text-blue-800">{users.filter(u => u.role === 'SUPER_ADMIN').length}</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-xl border border-amber-200">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl flex items-center justify-center shadow-md">
                        <Activity className="w-7 h-7 text-white" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-amber-600">Activity Logs</p>
                        <p className="text-3xl font-bold text-amber-800">{activityLogs.length}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Users Tab - Super Admin Only */}
          {activeTab === 'users' && isSuperAdmin(user?.role) && (
            <>
              <div className="mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <h2 className="text-3xl font-bold text-emerald-900">{t.users}</h2>
                  <p className="text-emerald-700/80 mt-1">
                    {language === 'id' ? 'Kelola pengguna sistem' : 'Manage system users'}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="relative w-72">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-emerald-400" />
                    <Input
                      placeholder={t.search}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 border-emerald-300 focus:border-emerald-500 h-12"
                    />
                  </div>
                  <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                    <DialogTrigger asChild>
                      <Button className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white font-semibold h-12 shadow-lg shadow-emerald-200">
                        <UserPlus className="w-5 h-5 mr-2" />
                        {t.addNewUser}
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="border-emerald-200">
                      <DialogHeader>
                        <DialogTitle className="text-xl font-bold text-emerald-900">
                          {editingUser ? t.editUser : t.addNewUser}
                        </DialogTitle>
                        <DialogDescription className="text-emerald-700">{t.userDetails}</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div>
                          <Label htmlFor="userName" className="text-emerald-800 font-medium">{t.name}</Label>
                          <Input
                            id="userName"
                            value={newUser.name}
                            onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                            className="border-emerald-300 focus:border-emerald-500 h-11"
                          />
                        </div>
                        <div>
                          <Label htmlFor="userEmail" className="text-emerald-800 font-medium">{t.email}</Label>
                          <Input
                            id="userEmail"
                            type="email"
                            value={newUser.email}
                            onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                            className="border-emerald-300 focus:border-emerald-500 h-11"
                          />
                        </div>
                        <div>
                          <Label htmlFor="userPhone" className="text-emerald-800 font-medium">{t.phone}</Label>
                          <Input
                            id="userPhone"
                            value={newUser.phone}
                            onChange={(e) => setNewUser({ ...newUser, phone: e.target.value })}
                            className="border-emerald-300 focus:border-emerald-500 h-11"
                          />
                        </div>
                        <div>
                          <Label htmlFor="userRole" className="text-emerald-800 font-medium">{t.role}</Label>
                          <Select value={newUser.role} onValueChange={(value: any) => setNewUser({ ...newUser, role: value })}>
                            <SelectTrigger className="border-emerald-300 focus:border-emerald-500 h-11">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="SUPER_ADMIN">{t.roles.SUPER_ADMIN}</SelectItem>
                              <SelectItem value="FRONT_DESK">{t.roles.FRONT_DESK}</SelectItem>
                              <SelectItem value="HOUSEKEEPING">{t.roles.HOUSEKEEPING}</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="userStatus" className="text-emerald-800 font-medium">{t.status}</Label>
                          <Select value={newUser.isActive ? 'true' : 'false'} onValueChange={(value) => setNewUser({ ...newUser, isActive: value === 'true' })}>
                            <SelectTrigger className="border-emerald-300 focus:border-emerald-500 h-11">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="true">{t.active}</SelectItem>
                              <SelectItem value="false">{t.inactive}</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button
                          variant="outline"
                          onClick={() => { setDialogOpen(false); setEditingUser(null); }}
                          className="border-emerald-300 text-emerald-700 hover:bg-emerald-50 h-11"
                        >
                          {t.cancel}
                        </Button>
                        <Button
                          onClick={editingUser ? handleUpdateUser : handleCreateUser}
                          className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white font-semibold h-11 px-8 shadow-lg shadow-emerald-200"
                        >
                          {editingUser ? t.update : t.create}
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>

              <Card className="border-emerald-200 shadow-lg">
                <ScrollArea className="max-h-[calc(100vh-300px)]">
                  <div className="divide-y divide-emerald-100">
                    {filteredUsers.length === 0 ? (
                      <CardContent className="p-12 text-center">
                        <Users className="w-16 h-16 text-emerald-400 mx-auto mb-4" />
                        <h3 className="text-xl font-bold text-emerald-900 mb-2">
                          {language === 'id' ? 'Tidak ada pengguna' : 'No users'}
                        </h3>
                      </CardContent>
                    ) : (
                      filteredUsers.map((userItem) => (
                        <div key={userItem.id} className="p-6 hover:bg-emerald-50/50 transition-colors">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-3">
                                <div className="w-12 h-12 bg-gradient-to-br from-purple-100 to-indigo-100 rounded-lg flex items-center justify-center">
                                  <Users className="w-6 h-6 text-purple-600" />
                                </div>
                                <div>
                                  <h4 className="text-lg font-bold text-emerald-900">{userItem.name}</h4>
                                  <p className="text-emerald-700/80 text-sm">{userItem.email}</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-3">
                                <Badge className={`px-3 py-1 font-medium ${getRoleColor(userItem.role)}`}>
                                  {t.roles[userItem.role]}
                                </Badge>
                                {userItem.phone && (
                                  <span className="text-sm text-emerald-700/80">{userItem.phone}</span>
                                )}
                                <Badge className={userItem.isActive ? 'bg-emerald-100 text-emerald-700 border-emerald-200' : 'bg-red-100 text-red-700 border-red-200'}>
                                  {userItem.isActive ? t.active : t.inactive}
                                </Badge>
                              </div>
                            </div>
                            <div className="flex gap-2 ml-4">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleEditUser(userItem)}
                                className="border-emerald-300 text-emerald-700 hover:bg-emerald-50"
                                disabled={userItem.id === user?.id}
                              >
                                <Edit className="w-4 h-4 mr-1" />
                                {t.editUser}
                              </Button>
                              {userItem.id !== user?.id && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleDeleteUser(userItem.id)}
                                  className="border-red-300 text-red-600 hover:bg-red-50"
                                >
                                  <Trash2 className="w-4 h-4 mr-1" />
                                  {t.deleteUser}
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </Card>
            </>
          )}

          {/* Activity Logs Tab */}
          {activeTab === 'activity' && (
            <>
              <div className="mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <h2 className="text-3xl font-bold text-emerald-900">{t.activityLogs}</h2>
                  <p className="text-emerald-700/80 mt-1">
                    {language === 'id' ? 'Riwayat aktivitas pengguna' : 'User activity history'}
                  </p>
                </div>
                <div className="relative w-72">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-emerald-400" />
                  <Input
                    placeholder={t.search}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 border-emerald-300 focus:border-emerald-500 h-12"
                  />
                </div>
              </div>

              <Card className="border-emerald-200 shadow-lg">
                <ScrollArea className="max-h-[calc(100vh-300px)]">
                  <div className="divide-y divide-emerald-100">
                    {filteredActivityLogs.length === 0 ? (
                      <CardContent className="p-12 text-center">
                        <Activity className="w-16 h-16 text-emerald-400 mx-auto mb-4" />
                        <h3 className="text-xl font-bold text-emerald-900 mb-2">
                          {language === 'id' ? 'Tidak ada log aktivitas' : 'No activity logs'}
                        </h3>
                      </CardContent>
                    ) : (
                      filteredActivityLogs.map((log) => (
                        <div key={log.id} className="p-6 hover:bg-emerald-50/50 transition-colors">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-3">
                                <div className="w-10 h-10 bg-gradient-to-br from-emerald-100 to-green-100 rounded-full flex items-center justify-center">
                                  <Clock className="w-5 h-5 text-emerald-600" />
                                </div>
                                <div>
                                  <h4 className="text-base font-bold text-emerald-900">{t.actions[log.action as keyof typeof t.actions] || log.action}</h4>
                                  <p className="text-emerald-700/80 text-sm">
                                    {log.user?.name} ({log.user?.email})
                                  </p>
                                </div>
                              </div>
                              {log.details && (
                                <p className="text-sm text-emerald-700/70 mt-2">{log.details}</p>
                              )}
                              {log.entityType && log.entityId && (
                                <div className="mt-2 flex items-center gap-2 text-sm text-emerald-700/80">
                                  <span className="font-medium">{log.entityType}:</span>
                                  <span className="bg-emerald-100 px-2 py-1 rounded font-mono text-xs">{log.entityId}</span>
                                </div>
                              )}
                              <div className="flex items-center gap-4 mt-3 text-xs text-emerald-600/70">
                                <div className="flex items-center gap-2">
                                  <Calendar className="w-3 h-3" />
                                  <span>{new Date(log.createdAt).toLocaleString('id-ID')}</span>
                                </div>
                                {log.ipAddress && (
                                  <div className="flex items-center gap-2">
                                    <Shield className="w-3 h-3" />
                                    <span>IP: {log.ipAddress}</span>
                                  </div>
                                )}
                              </div>
                            </div>
                            <Badge className={`px-3 py-1 font-medium text-xs ${getActionBadgeColor(log.action)}`}>
                              {t.actions[log.action as keyof typeof t.actions] || log.action}
                            </Badge>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </Card>
            </>
          )}
        </main>
      </div>
    </div>
  );
}
