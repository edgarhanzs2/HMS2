import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST() {
  try {
    const rooms = [
      {
        roomNumber: '101',
        type: 'Standard',
        price: 350000,
        status: 'AVAILABLE' as const,
        amenities: 'WiFi, AC, TV, Hot Water'
      },
      {
        roomNumber: '102',
        type: 'Standard',
        price: 350000,
        status: 'AVAILABLE' as const,
        amenities: 'WiFi, AC, TV, Hot Water'
      },
      {
        roomNumber: '103',
        type: 'Deluxe',
        price: 500000,
        status: 'AVAILABLE' as const,
        amenities: 'WiFi, AC, TV, Hot Water, Mini Bar, Balcony'
      },
      {
        roomNumber: '104',
        type: 'Deluxe',
        price: 500000,
        status: 'AVAILABLE' as const,
        amenities: 'WiFi, AC, TV, Hot Water, Mini Bar, Balcony'
      },
      {
        roomNumber: '201',
        type: 'Suite',
        price: 750000,
        status: 'AVAILABLE' as const,
        amenities: 'WiFi, AC, TV, Hot Water, Mini Bar, Living Room, Kitchenette'
      },
      {
        roomNumber: '202',
        type: 'Suite',
        price: 750000,
        status: 'AVAILABLE' as const,
        amenities: 'WiFi, AC, TV, Hot Water, Mini Bar, Living Room, Kitchenette'
      },
      {
        roomNumber: '301',
        type: 'Family',
        price: 900000,
        status: 'AVAILABLE' as const,
        amenities: 'WiFi, AC, TV, Hot Water, Mini Bar, 2 Bedrooms, Kitchen'
      },
      {
        roomNumber: '302',
        type: 'Family',
        price: 900000,
        status: 'AVAILABLE' as const,
        amenities: 'WiFi, AC, TV, Hot Water, Mini Bar, 2 Bedrooms, Kitchen'
      }
    ];

    for (const room of rooms) {
      await db.room.upsert({
        where: { roomNumber: room.roomNumber },
        update: room,
        create: room
      });
    }

    return NextResponse.json({ success: true, message: 'Database seeded successfully' });
  } catch (error) {
    console.error('Error seeding database:', error);
    return NextResponse.json({ error: 'Failed to seed database' }, { status: 500 });
  }
}
