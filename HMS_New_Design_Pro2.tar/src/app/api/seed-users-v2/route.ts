import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function POST() {
  try {
    console.log('Starting user seed...');
    
    // Check if super admin exists
    const existingAdmin = await prisma.user.findFirst({
      where: { role: 'SUPER_ADMIN' }
    });

    if (existingAdmin) {
      console.log('Super admin already exists');
      return NextResponse.json({ message: 'Super admin sudah ada', users: [] });
    }

    // Import bcrypt
    const bcrypt = await import('bcryptjs');

    // Create super admin user
    console.log('Creating super admin...');
    const hashedAdminPassword = await bcrypt.hash('admin123', 10);
    const superAdmin = await prisma.user.create({
      data: {
        email: 'admin@arika.com',
        password: hashedAdminPassword,
        name: 'Super Admin',
        phone: '+62 812 3456 7890',
        role: 'SUPER_ADMIN',
        isActive: true
      }
    });
    console.log('Super admin created:', superAdmin.id);

    // Create front desk user
    console.log('Creating front desk...');
    const frontDeskPassword = await bcrypt.hash('frontdesk123', 10);
    const frontDesk = await prisma.user.create({
      data: {
        email: 'frontdesk@arika.com',
        password: frontDeskPassword,
        name: 'Front Desk Staff',
        phone: '+62 812 3456 7891',
        role: 'FRONT_DESK',
        isActive: true
      }
    });
    console.log('Front desk created:', frontDesk.id);

    // Create housekeeping user
    console.log('Creating housekeeping...');
    const housekeepingPassword = await bcrypt.hash('housekeeping123', 10);
    const housekeeping = await prisma.user.create({
      data: {
        email: 'housekeeping@arika.com',
        password: housekeepingPassword,
        name: 'Housekeeping Staff',
        phone: '+62 812 3456 7892',
        role: 'HOUSEKEEPING',
        isActive: true
      }
    });
    console.log('Housekeeping created:', housekeeping.id);

    const users = await prisma.user.findMany();
    console.log('Total users:', users.length);

    return NextResponse.json({
      message: 'Default users created successfully',
      users: users.map(u => ({ email: u.email, name: u.name, role: u.role }))
    });
  } catch (error) {
    console.error('Seed users error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
