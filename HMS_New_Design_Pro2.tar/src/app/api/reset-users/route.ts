import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST() {
  try {
    // Delete all activity logs first (foreign key constraint)
    const allActivityLogs = await db.activityLog.findMany();
    for (const log of allActivityLogs) {
      await db.activityLog.delete({ where: { id: log.id } });
    }

    // Delete all users
    const allUsers = await db.user.findMany();
    for (const user of allUsers) {
      await db.user.delete({ where: { id: user.id } });
    }

    console.log(`Deleted ${allUsers.length} users and ${allActivityLogs.length} activity logs`);

    // Call seed users
    const seedResponse = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000'}/api/seed-users`, {
      method: 'POST'
    });

    const seedData = await seedResponse.json();

    return NextResponse.json({
      message: 'Users reset and reseeded successfully',
      deletedUsers: allUsers.length,
      deletedLogs: allActivityLogs.length,
      ...seedData
    });
  } catch (error) {
    console.error('Reset users error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
