import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST() {
  try {
    // Check if super admin exists
    const existingAdmin = await db.user.findFirst({
      where: { role: 'SUPER_ADMIN' }
    });

    if (existingAdmin) {
      return NextResponse.json({ message: 'Super admin sudah ada' });
    }

    // Import bcrypt dynamically
    const bcrypt = await import('bcryptjs');

    // Create super admin user
    const hashedPassword = await bcrypt.hash('admin123', 10);

    const superAdmin = await db.user.create({
      data: {
        email: 'admin@arika.com',
        password: hashedPassword,
        name: 'Super Admin',
        phone: '+62 812 3456 7890',
        role: 'SUPER_ADMIN',
        isActive: true
      }
    });

    // Create front desk user
    const frontDeskPassword = await bcrypt.hash('frontdesk123', 10);
    await db.user.create({
      data: {
        email: 'frontdesk@arika.com',
        password: frontDeskPassword,
        name: 'Front Desk Staff',
        phone: '+62 812 3456 7891',
        role: 'FRONT_DESK',
        isActive: true
      }
    });

    // Create housekeeping user
    const housekeepingPassword = await bcrypt.hash('housekeeping123', 10);
    await db.user.create({
      data: {
        email: 'housekeeping@arika.com',
        password: housekeepingPassword,
        name: 'Housekeeping Staff',
        phone: '+62 812 3456 7892',
        role: 'HOUSEKEEPING',
        isActive: true
      }
    });

    return NextResponse.json({
      message: 'Default users created successfully',
      users: [
        { email: 'admin@arika.com', password: 'admin123', role: 'SUPER_ADMIN', name: 'Super Admin' },
        { email: 'frontdesk@arika.com', password: 'frontdesk123', role: 'FRONT_DESK', name: 'Front Desk Staff' },
        { email: 'housekeeping@arika.com', password: 'housekeeping123', role: 'HOUSEKEEPING', name: 'Housekeeping Staff' }
      ]
    });
  } catch (error) {
    console.error('Seed users error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
