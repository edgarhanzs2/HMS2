'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, UserPlus, ArrowRight } from 'lucide-react';

export default function SetupPage() {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [users, setUsers] = useState<any[]>([]);

  const handleSeedUsers = async () => {
    setLoading(true);
    setMessage('');

    try {
      const response = await fetch('/api/seed-users', {
        method: 'POST'
      });

      const data = await response.json();

      if (response.ok) {
        setMessage('✅ ' + data.message);
        setUsers(data.users || []);

        // Auto-redirect to login after 3 seconds
        setTimeout(() => {
          window.location.href = '/login';
        }, 3000);
      } else {
        setMessage('❌ ' + (data.error || 'Failed to seed users'));
      }
    } catch (error) {
      console.error('Seed error:', error);
      setMessage('❌ Failed to create default users');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50 via-green-50 to-emerald-100 px-4">
      <Card className="w-full max-w-lg shadow-2xl border-emerald-200">
        <CardHeader className="space-y-2 text-center pb-8">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-green-600 rounded-2xl flex items-center justify-center shadow-lg">
              <UserPlus className="w-8 h-8 text-white" />
            </div>
          </div>
          <CardTitle className="text-3xl font-bold text-emerald-900">
            Setup Akun Default
          </CardTitle>
          <CardDescription className="text-emerald-700 text-base">
            Buat akun pengguna default untuk pertama kali penggunaan sistem
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {message && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 px-4 py-4 rounded-lg">
              <p className="whitespace-pre-line">{message}</p>
            </div>
          )}

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="font-bold text-blue-900 mb-4 flex items-center gap-2">
              <CheckCircle className="w-5 h-5" />
              Akun yang Akan Dibuat:
            </h3>
            <div className="space-y-3">
              <div className="bg-white p-4 rounded-lg border border-blue-200">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-white font-bold text-sm">SA</span>
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-gray-900">Super Admin</p>
                    <div className="text-sm text-gray-700 mt-1 space-y-1">
                      <p><span className="font-medium">Email:</span> admin@arika.com</p>
                      <p><span className="font-medium">Password:</span> admin123</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white p-4 rounded-lg border border-blue-200">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-white font-bold text-sm">FD</span>
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-gray-900">Front Desk Staff</p>
                    <div className="text-sm text-gray-700 mt-1 space-y-1">
                      <p><span className="font-medium">Email:</span> frontdesk@arika.com</p>
                      <p><span className="font-medium">Password:</span> frontdesk123</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white p-4 rounded-lg border border-blue-200">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-amber-500 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-white font-bold text-sm">HK</span>
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-gray-900">Housekeeping Staff</p>
                    <div className="text-sm text-gray-700 mt-1 space-y-1">
                      <p><span className="font-medium">Email:</span> housekeeping@arika.com</p>
                      <p><span className="font-medium">Password:</span> housekeeping123</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <Button
            onClick={handleSeedUsers}
            disabled={loading}
            className="w-full bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white font-semibold h-12 text-base shadow-lg shadow-emerald-200"
          >
            {loading ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Membuat Akun...
              </>
            ) : (
              <>
                Buat Akun Default
                <ArrowRight className="w-5 h-5 ml-2" />
              </>
            )}
          </Button>

          <div className="text-center">
            <a href="/login" className="text-emerald-700 hover:text-emerald-900 font-medium flex items-center justify-center gap-2 text-sm">
              Sudah punya akun? Login di sini
              <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
