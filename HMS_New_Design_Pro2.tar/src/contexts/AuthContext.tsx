'use client';

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  role: 'SUPER_ADMIN' | 'FRONT_DESK' | 'HOUSEKEEPING';
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (user: User) => void;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  // Check for stored user on mount
  const storedUser = typeof window !== 'undefined' ? localStorage.getItem('user') : null;
  const [user, setUser] = useState<User | null>(() => {
    if (storedUser) {
      try {
        return JSON.parse(storedUser);
      } catch (error) {
        console.error('Failed to parse stored user:', error);
        return null;
      }
    }
    return null;
  });
  const [isLoading, setIsLoading] = useState(false);

  const login = (userData: User) => {
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const value = {
    user,
    isAuthenticated: !!user,
    login,
    logout,
    isLoading
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export function canAccess(requiredRole: 'SUPER_ADMIN' | 'FRONT_DESK' | 'HOUSEKEEPING', userRole?: string): boolean {
  if (!userRole) return false;

  const roleHierarchy: Record<string, number> = {
    SUPER_ADMIN: 3,
    FRONT_DESK: 2,
    HOUSEKEEPING: 1
  };

  return roleHierarchy[userRole] >= roleHierarchy[requiredRole];
}

export function isSuperAdmin(userRole?: string): boolean {
  return userRole === 'SUPER_ADMIN';
}
