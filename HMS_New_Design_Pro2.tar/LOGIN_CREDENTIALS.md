# Login Credentials - Default Users

This document contains the default user credentials for the Arika Homestay Management System.

## Default Users Created via API

These users will be automatically created when you call the seed API.

### 1. Super Admin
- **Email:** admin@arika.com
- **Password:** admin123
- **Role:** SUPER_ADMIN
- **Access:** Full access to all features including user management

### 2. Front Desk Staff
- **Email:** frontdesk@arika.com
- **Password:** frontdesk123
- **Role:** FRONT_DESK
- **Access:** Can manage reservations, check-in/out, view bookings

### 3. Housekeeping Staff
- **Email:** housekeeping@arika.com
- **Password:** housekeeping123
- **Role:** HOUSEKEEPING
- **Access:** Can manage room cleanliness status

## How to Seed Users

### Method 1: Via Browser Console
```javascript
fetch('/api/seed-users-v2', { method: 'POST' })
  .then(r => r.json())
  .then(data => console.log(data))
```

### Method 2: Via curl Command
```bash
curl -X POST http://localhost:3000/api/seed-users-v2
```

## How to Login

1. Open browser to: http://localhost:3000/login
2. Enter email and password from above
3. Click "Masuk Sekarang" button

## Troubleshooting

If login fails with "Internal server error":

1. Check browser console for errors
2. Check dev server logs: `tail -50 /home/z/my-project/dev.log`
3. Ensure Next.js dev server is running
4. The server may need to regenerate Prisma client - clearing .next folder may help

## Role-Based Access Control

- **SUPER_ADMIN**: Can access all tabs including "Pengguna" (Users)
- **FRONT_DESK**: Can access Dashboard, Rooms, Bookings, Guests (but not Users)
- **HOUSEKEEPING**: Can access Dashboard, Rooms (but limited access)

## Important Notes

- All passwords are simple for development/testing purposes
- In production, use strong passwords
- Change default passwords before deploying to production
