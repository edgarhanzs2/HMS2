
import React, { useState } from 'react';
import { Room, RoomType, UserRole } from '../types';
import { Plus, Edit2, Trash2, X, AlertTriangle } from 'lucide-react';
import { ROOM_TYPES } from '../constants';

interface ManageRoomsProps {
  rooms: Room[];
  onAdd: (room: Omit<Room, 'id'>) => void;
  onUpdate: (room: Room) => void;
  onDelete: (id: string) => void;
  userRole?: UserRole;
}

const ManageRooms: React.FC<ManageRoomsProps> = ({ rooms, onAdd, onUpdate, onDelete, userRole }) => {
  const [isModalOpen, setModalOpen] = useState(false);
  const [editingRoom, setEditingRoom] = useState<Room | null>(null);

  const [roomNumber, setRoomNumber] = useState('');
  const [roomType, setRoomType] = useState<RoomType>('Standard');
  const [price, setPrice] = useState(0);

  const isHK = userRole === 'Housekeeping';
  const canEditDetails = userRole === 'Super Admin' || userRole === 'Front Desk';

  const openAddModal = () => {
    setEditingRoom(null);
    setRoomNumber('');
    setRoomType('Standard');
    setPrice(500000);
    setModalOpen(true);
  };

  const openEditModal = (room: Room) => {
    setEditingRoom(room);
    setRoomNumber(room.roomNumber);
    setRoomType(room.type);
    setPrice(room.price);
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingRoom) {
      onUpdate({ ...editingRoom, roomNumber, type: roomType, price });
    } else {
      onAdd({ roomNumber, type: roomType, price, status: 'Available' });
    }
    setModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Inventory Management</h2>
          <p className="text-slate-500">
            {isHK ? 'Update room maintenance status.' : 'Add, edit, or remove hotel rooms from the system.'}
          </p>
        </div>
        {!isHK && (
          <button 
            onClick={openAddModal}
            className="bg-teal-600 text-white px-6 py-2.5 rounded-xl hover:bg-teal-700 transition flex items-center font-bold shadow-lg shadow-teal-100"
          >
            <Plus size={20} className="mr-2" />
            Add New Room
          </button>
        )}
      </div>

      {isHK && (
        <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex items-start space-x-3">
           <AlertTriangle className="text-amber-600 flex-shrink-0" />
           <p className="text-sm text-amber-800">
             <strong>Housekeeping Access:</strong> You can view and update room cleaning status. To change prices or room types, please contact the Front Desk.
           </p>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-100 text-xs uppercase font-bold text-slate-400">
            <tr>
              <th className="px-6 py-4">Room No</th>
              <th className="px-6 py-4">Type</th>
              <th className="px-6 py-4">Price / Night</th>
              <th className="px-6 py-4">Status</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rooms.map((room) => (
              <tr key={room.id} className="hover:bg-slate-50 transition group">
                <td className="px-6 py-4 font-bold text-slate-700">{room.roomNumber}</td>
                <td className="px-6 py-4 text-slate-600">
                  <span className="px-2 py-1 bg-slate-100 rounded text-xs font-semibold">{room.type}</span>
                </td>
                <td className="px-6 py-4 text-slate-600 font-medium">Rp {room.price.toLocaleString()}</td>
                <td className="px-6 py-4">
                  <button 
                    disabled={!isHK && !canEditDetails}
                    onClick={() => {
                      if (isHK || canEditDetails) {
                        const nextStatus = room.status === 'Available' ? 'Booked' : 'Available';
                        onUpdate({...room, status: nextStatus});
                      }
                    }}
                    className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold transition ${
                      room.status === 'Available' ? 'bg-teal-100 text-teal-700' : 'bg-rose-100 text-rose-700'
                    } ${isHK || canEditDetails ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}`}
                  >
                    {room.status}
                  </button>
                </td>
                <td className="px-6 py-4 text-right">
                  {!isHK && (
                    <div className="flex justify-end space-x-2 opacity-0 group-hover:opacity-100 transition">
                      <button onClick={() => openEditModal(room)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"><Edit2 size={18} /></button>
                      {userRole === 'Super Admin' && (
                        <button onClick={() => onDelete(room.id)} className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg"><Trash2 size={18} /></button>
                      )}
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && !isHK && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden animate-in zoom-in duration-200">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-xl font-bold text-slate-800">{editingRoom ? 'Edit Room' : 'Add New Room'}</h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={24} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-sm font-semibold text-slate-600">Room Number</label>
                <input required type="text" value={roomNumber} onChange={(e) => setRoomNumber(e.target.value)} className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none" />
              </div>
              <div className="space-y-1">
                <label className="text-sm font-semibold text-slate-600">Room Type</label>
                <select value={roomType} onChange={(e) => setRoomType(e.target.value as RoomType)} className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none">
                  {ROOM_TYPES.map(type => <option key={type} value={type}>{type}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-sm font-semibold text-slate-600">Price per Night (Rp)</label>
                <input required type="number" value={price} onChange={(e) => setPrice(Number(e.target.value))} className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none" />
              </div>
              <div className="pt-4 flex space-x-3">
                <button type="button" onClick={() => setModalOpen(false)} className="flex-1 px-4 py-3 border border-slate-200 text-slate-600 font-bold rounded-xl hover:bg-slate-50">Cancel</button>
                <button type="submit" className="flex-1 bg-teal-600 text-white font-bold rounded-xl hover:bg-teal-700 shadow-lg shadow-teal-100">
                  {editingRoom ? 'Save Changes' : 'Create Room'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManageRooms;
