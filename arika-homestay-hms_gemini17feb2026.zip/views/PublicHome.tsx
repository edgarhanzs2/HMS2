
import React, { useState } from 'react';
import { Room, Guest } from '../types';
import { Search, Info, CheckCircle, CreditCard, TreePine } from 'lucide-react';

interface PublicHomeProps {
  rooms: Room[];
  onBook: (data: { room: Room, guest: Omit<Guest, 'id'>, checkIn: string, checkOut: string }) => void;
}

const PublicHome: React.FC<PublicHomeProps> = ({ rooms, onBook }) => {
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [bookingStep, setBookingStep] = useState<'search' | 'details'>('search');
  
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [guestPhone, setGuestPhone] = useState('');

  const availableRooms = rooms.filter(r => r.status === 'Available');

  const handleBookNow = (room: Room) => {
    setSelectedRoom(room);
    setBookingStep('details');
  };

  const handleSubmitBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRoom) return;
    onBook({
      room: selectedRoom,
      guest: { name: guestName, email: guestEmail, phone: guestPhone },
      checkIn,
      checkOut
    });
    setBookingStep('search');
    setSelectedRoom(null);
  };

  return (
    <div className="space-y-12 pb-20">
      {/* Hero Section */}
      <section className="relative h-[500px] flex items-center justify-center text-white overflow-hidden">
        <div className="absolute inset-0 bg-green-950">
          <img 
            src="https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1920&q=80" 
            className="w-full h-full object-cover opacity-40 scale-105"
            alt="Hero Background"
          />
        </div>
        <div className="relative z-10 text-center space-y-6 px-4">
          <div className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-full border border-white/20 mb-4">
            <TreePine className="text-green-300 w-4 h-4" />
            <span className="text-sm font-bold uppercase tracking-widest text-green-100">Welcome to Nature</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight">Your Green Sanctuary</h1>
          <p className="text-xl md:text-2xl text-green-100 max-w-3xl mx-auto font-light leading-relaxed">
            Experience the harmony of nature and comfort at <span className="font-bold border-b-2 border-green-400">Arika Homestay</span>.
          </p>
        </div>
      </section>

      {/* Search Bar */}
      <div className="max-w-4xl mx-auto -mt-20 relative z-20 px-4">
        <div className="bg-white p-8 rounded-[2.5rem] shadow-2xl shadow-green-900/10 border border-slate-100 flex flex-col md:flex-row items-end gap-6">
          <div className="flex-1 w-full space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Arrival Date</label>
            <input 
              type="date" 
              className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-green-500 outline-none transition font-medium"
              value={checkIn}
              onChange={(e) => setCheckIn(e.target.value)}
            />
          </div>
          <div className="flex-1 w-full space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Departure Date</label>
            <input 
              type="date" 
              className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-green-500 outline-none transition font-medium"
              value={checkOut}
              onChange={(e) => setCheckOut(e.target.value)}
            />
          </div>
          <button className="bg-green-600 text-white h-[60px] px-10 rounded-2xl hover:bg-green-700 transition flex items-center justify-center font-bold w-full md:w-auto text-lg shadow-lg shadow-green-100">
            <Search className="w-5 h-5 mr-2" />
            Check Availability
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {bookingStep === 'search' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {availableRooms.map((room) => (
              <div key={room.id} className="bg-white rounded-3xl border border-slate-200 overflow-hidden hover:shadow-2xl hover:shadow-green-900/5 transition duration-500 group">
                <div className="h-64 overflow-hidden relative">
                  <img 
                    src={`https://images.unsplash.com/photo-${1500000000000 + parseInt(room.id) * 100000}?auto=format&fit=crop&w=800&q=80`} 
                    className="w-full h-full object-cover group-hover:scale-110 transition duration-700"
                    alt={`Room ${room.roomNumber}`}
                  />
                  <div className="absolute top-4 right-4">
                    <span className="bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold text-green-700 uppercase tracking-widest border border-green-100">
                      {room.type}
                    </span>
                  </div>
                </div>
                <div className="p-8 space-y-5">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-2xl font-extrabold text-slate-800 tracking-tight">Room {room.roomNumber}</h3>
                      <p className="text-sm text-slate-400 font-medium">Full garden view terrace</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-black text-green-700">Rp {room.price.toLocaleString()}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">per night</p>
                    </div>
                  </div>
                  <div className="flex space-x-4 py-2 text-sm text-slate-500 font-medium">
                    <div className="flex items-center"><Info className="w-4 h-4 mr-1.5 text-green-500" /> 2 Adults</div>
                    <div className="flex items-center"><Info className="w-4 h-4 mr-1.5 text-green-500" /> Breakfast Inc.</div>
                  </div>
                  <button 
                    onClick={() => handleBookNow(room)}
                    className="w-full bg-slate-900 text-white py-4 rounded-2xl hover:bg-green-600 transition font-bold text-lg"
                  >
                    Select Room
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="max-w-2xl mx-auto bg-white p-10 rounded-[2.5rem] shadow-2xl shadow-green-900/5 border border-slate-100">
            <button 
              onClick={() => setBookingStep('search')}
              className="mb-8 text-sm text-green-600 font-bold hover:text-green-800 transition flex items-center"
            >
              &larr; Return to Selection
            </button>
            <h2 className="text-3xl font-black text-slate-800 mb-8 tracking-tight">Secure Your Stay</h2>
            
            <div className="bg-green-50 p-6 rounded-2xl border border-green-100 mb-8 flex items-center justify-between">
               <div>
                  <p className="text-xs text-green-600 font-bold uppercase tracking-widest mb-1">Stay Duration</p>
                  <p className="font-bold text-slate-800">Room {selectedRoom?.roomNumber} • {checkIn || 'TBD'} - {checkOut || 'TBD'}</p>
               </div>
               <div className="text-right">
                  <p className="text-xs text-green-600 font-bold uppercase tracking-widest mb-1">Total Stay</p>
                  <p className="text-xl font-black text-green-700">Rp {(selectedRoom!.price * 2).toLocaleString()}</p>
               </div>
            </div>

            <form onSubmit={handleSubmitBooking} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-600 ml-1">Full Guest Name</label>
                  <input 
                    required
                    type="text" 
                    className="w-full p-4 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-green-500 outline-none transition"
                    placeholder="E.g. John Smith"
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-600 ml-1">Phone Number</label>
                  <input 
                    required
                    type="tel" 
                    className="w-full p-4 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-green-500 outline-none transition"
                    placeholder="0812 XXXX XXXX"
                    value={guestPhone}
                    onChange={(e) => setGuestPhone(e.target.value)}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-600 ml-1">Contact Email</label>
                <input 
                  required
                  type="email" 
                  className="w-full p-4 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-green-500 outline-none transition"
                  placeholder="john@example.com"
                  value={guestEmail}
                  onChange={(e) => setGuestEmail(e.target.value)}
                />
              </div>

              <div className="pt-8">
                <button 
                  type="submit"
                  className="w-full bg-green-700 text-white py-5 rounded-2xl hover:bg-green-800 transition font-black text-xl shadow-xl shadow-green-100 flex items-center justify-center space-x-3"
                >
                  <CheckCircle className="w-6 h-6" />
                  <span>Confirm Reservation</span>
                </button>
                <div className="flex items-center justify-center space-x-2 mt-6">
                  <CreditCard className="w-4 h-4 text-slate-400" />
                  <p className="text-xs text-slate-400 font-medium">Payment processed securely upon check-in</p>
                </div>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};

export default PublicHome;
