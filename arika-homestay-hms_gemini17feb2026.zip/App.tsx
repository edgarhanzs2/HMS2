
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import Layout from './components/Layout';
import PublicHome from './views/PublicHome';
import AdminDashboard from './views/AdminDashboard';
import ManageRooms from './views/ManageRooms';
import ManageBookings from './views/ManageBookings';
import ManageUsers from './views/ManageUsers';
import AuditLogs from './views/AuditLogs';
import AdminLogin from './views/AdminLogin';
import { Room, Guest, Booking, DashboardMetrics, User, ActivityLog } from './types';
import { INITIAL_ROOMS, INITIAL_BOOKINGS, INITIAL_GUESTS, INITIAL_USERS, INITIAL_LOGS } from './constants';

const App: React.FC = () => {
  // Application State
  const [isAdmin, setIsAdmin] = useState(false);
  const [currentPath, setCurrentPath] = useState('home');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  
  // Simulated Database
  const [rooms, setRooms] = useState<Room[]>(INITIAL_ROOMS);
  const [guests, setGuests] = useState<Guest[]>(INITIAL_GUESTS);
  const [bookings, setBookings] = useState<Booking[]>(INITIAL_BOOKINGS);
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>(INITIAL_LOGS);

  // Activity Logger Utility
  const logActivity = useCallback((action: string, details: string) => {
    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: currentUser?.id || 'anonymous',
      username: currentUser?.name || 'System Guest',
      action,
      details
    };
    setActivityLogs(prev => [newLog, ...prev]);
  }, [currentUser]);

  // Routing Logic
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '') || 'home';
      setCurrentPath(hash);
      
      const is_admin_path = hash.startsWith('admin');
      setIsAdmin(is_admin_path);

      // Simple Auth Guard
      if (is_admin_path && hash !== 'admin-login' && !currentUser) {
        window.location.hash = 'admin-login';
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    handleHashChange();
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [currentUser]);

  const navigate = (path: string) => {
    window.location.hash = path;
  };

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    logActivity('Login', `User ${user.name} logged in as ${user.role}`);
    navigate('admin-dashboard');
  };

  const handleLogout = () => {
    logActivity('Logout', `User ${currentUser?.name} logged out`);
    setCurrentUser(null);
    setIsAdmin(false);
    navigate('home');
  };

  const toggleView = () => {
    if (isAdmin) {
      navigate('home');
    } else {
      navigate(currentUser ? 'admin-dashboard' : 'admin-login');
    }
  };

  // State Handlers
  const addRoom = (room: Omit<Room, 'id'>) => {
    const newRoom = { ...room, id: Date.now().toString() };
    setRooms(prev => [...prev, newRoom]);
    logActivity('Create Room', `Added Room ${newRoom.roomNumber} (${newRoom.type})`);
  };

  const updateRoom = (updatedRoom: Room) => {
    setRooms(prev => prev.map(r => r.id === updatedRoom.id ? updatedRoom : r));
    logActivity('Update Room', `Modified Room ${updatedRoom.roomNumber}`);
  };

  const deleteRoom = (id: string) => {
    const r = rooms.find(item => item.id === id);
    setRooms(prev => prev.filter(item => item.id !== id));
    logActivity('Delete Room', `Removed Room ${r?.roomNumber}`);
  };

  const addBooking = (bookingData: { room: Room, guest: Omit<Guest, 'id'>, checkIn: string, checkOut: string }) => {
    const guestId = `g${Date.now()}`;
    const newGuest: Guest = { ...bookingData.guest, id: guestId };
    const bookingId = `b${Date.now()}`;
    const newBooking: Booking = {
      id: bookingId,
      roomId: bookingData.room.id,
      guestId: guestId,
      checkInDate: bookingData.checkIn,
      checkOutDate: bookingData.checkOut,
      totalCost: bookingData.room.price * 2,
      status: 'Confirmed'
    };
    setGuests(prev => [...prev, newGuest]);
    setBookings(prev => [...prev, newBooking]);
    setRooms(prev => prev.map(r => r.id === bookingData.room.id ? { ...r, status: 'Booked' } : r));
    logActivity('New Booking', `Booking ${bookingId} for guest ${newGuest.name}`);
    alert(`Successfully booked! Reservation ID: ${bookingId}`);
    navigate('home');
  };

  const updateBookingStatus = (id: string, status: Booking['status']) => {
    setBookings(prev => prev.map(b => {
      if (b.id === id) {
        if (status === 'Canceled' || status === 'Checked-Out') {
          setRooms(rPrev => rPrev.map(r => r.id === b.roomId ? { ...r, status: 'Available' } : r));
        }
        logActivity('Update Booking', `Booking ${id} status changed to ${status}`);
        return { ...b, status };
      }
      return b;
    }));
  };

  // User CRUD
  const addUser = (userData: Omit<User, 'id'>) => {
    const newUser = { ...userData, id: `u${Date.now()}` };
    setUsers(prev => [...prev, newUser]);
    logActivity('Create User', `Added ${newUser.role}: ${newUser.name}`);
  };

  const updateUser = (updatedUser: User) => {
    setUsers(prev => prev.map(u => u.id === updatedUser.id ? updatedUser : u));
    logActivity('Update User', `Modified account for ${updatedUser.name}`);
  };

  const deleteUser = (id: string) => {
    const u = users.find(item => item.id === id);
    setUsers(prev => prev.filter(item => item.id !== id));
    logActivity('Delete User', `Removed user ${u?.name}`);
  };

  // Metrics
  const metrics: DashboardMetrics = useMemo(() => {
    const activeBookings = bookings.filter(b => b.status === 'Confirmed' || b.status === 'Checked-In');
    const revenue = bookings.filter(b => b.status !== 'Canceled').reduce((acc, b) => acc + b.totalCost, 0);
    return {
      totalOccupied: activeBookings.length,
      availableToday: rooms.filter(r => r.status === 'Available').length,
      monthlyRevenue: revenue
    };
  }, [rooms, bookings]);

  const renderView = () => {
    if (isAdmin && !currentUser && currentPath !== 'admin-login') {
       return <AdminLogin users={users} onLogin={handleLogin} />;
    }

    switch (currentPath) {
      case 'home': return <PublicHome rooms={rooms} onBook={addBooking} />;
      case 'admin-login': return <AdminLogin users={users} onLogin={handleLogin} />;
      case 'admin-dashboard': return <AdminDashboard metrics={metrics} bookings={bookings} rooms={rooms} />;
      case 'admin-rooms': return <ManageRooms rooms={rooms} onAdd={addRoom} onUpdate={updateRoom} onDelete={deleteRoom} userRole={currentUser?.role} />;
      case 'admin-bookings': return <ManageBookings bookings={bookings} rooms={rooms} guests={guests} onUpdateStatus={updateBookingStatus} />;
      case 'admin-users': return <ManageUsers users={users} onAdd={addUser} onUpdate={updateUser} onDelete={deleteUser} />;
      case 'admin-logs': return <AuditLogs logs={activityLogs} />;
      default: return <PublicHome rooms={rooms} onBook={addBooking} />;
    }
  };

  return (
    <Layout 
      isAdmin={isAdmin} 
      currentUser={currentUser}
      onViewToggle={toggleView} 
      currentPath={currentPath}
      onNavigate={navigate}
      onLogout={handleLogout}
    >
      {renderView()}
    </Layout>
  );
};

export default App;
