
export type RoomStatus = 'Available' | 'Booked';
export type RoomType = 'Standard' | 'Deluxe' | 'Suite' | 'Penthouse';
export type BookingStatus = 'Confirmed' | 'Checked-In' | 'Checked-Out' | 'Canceled';
export type UserRole = 'Super Admin' | 'Front Desk' | 'Housekeeping';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  password?: string;
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  userId: string;
  username: string;
  action: string;
  details: string;
}

export interface Room {
  id: string;
  roomNumber: string;
  type: RoomType;
  price: number;
  status: RoomStatus;
}

export interface Guest {
  id: string;
  name: string;
  email: string;
  phone: string;
}

export interface Booking {
  id: string;
  roomId: string;
  guestId: string;
  checkInDate: string;
  checkOutDate: string;
  totalCost: number;
  status: BookingStatus;
}

export interface DashboardMetrics {
  totalOccupied: number;
  availableToday: number;
  monthlyRevenue: number;
}
