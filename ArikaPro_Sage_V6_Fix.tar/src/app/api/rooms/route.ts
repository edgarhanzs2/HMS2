import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const rooms = await db.room.findMany({
      orderBy: { roomNumber: 'asc' }
    })
    return NextResponse.json(rooms)
  } catch (error) {
    console.error('Error fetching rooms:', error)
    return NextResponse.json(
      { error: 'Failed to fetch rooms' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { roomNumber, type, price, description, status, image } = body

    if (!roomNumber || !type || !price) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const room = await db.room.create({
      data: {
        roomNumber,
        type,
        price: parseFloat(price),
        description: description || null,
        status: status || 'Available',
        image: image || null
      }
    })

    return NextResponse.json(room, { status: 201 })
  } catch (error: any) {
    console.error('Error creating room:', error)
    if (error.code === 'P2002') {
      return NextResponse.json(
        { error: 'Room number already exists' },
        { status: 400 }
      )
    }
    return NextResponse.json(
      { error: 'Failed to create room' },
      { status: 500 }
    )
  }
}
