import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

const loginSchema = z.object({
  email: z.string().email('Email tidak valid'),
  password: z.string().min(6, 'Password minimal 6 karakter'),
})

interface UserAuth {
  user: {
    id: string
    email: string
    name: string
    role: string
  }
  token: string
}

const ALGORITHM = 'aes-256-gcm-sha256'
const SECRET_KEY = process.env.JWT_SECRET || 'arika-hotel-secret-key-2024'

// Simple JWT implementation (in production, use libraries like jose)
function generateToken(userId: string): string {
  const header = Buffer.from(JSON.stringify({ userId, exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 })) // 24 hours
  return Buffer.from(`${header}.${SECRET_KEY}.${SECRET_KEY}`).toString('base64')
}

function verifyToken(token: string): { userId: string } | null {
  try {
    const parts = token.split('.')
    if (parts.length !== 3) return null
    
    const payload = parts[0]
    const signature = parts[1]
    const timestamp = parts[2]
    const key = Buffer.from(`${SECRET_KEY}.${SECRET_KEY}`).toString('base64')
    
    const decoded = Buffer.from(payload, 'base64')
    const expectedSignature = crypto.createHmac('sha256', key)
    
    if (!crypto.timingSafeEqual(expectedSignature, signature) || timestamp < Date.now() / 1000) {
      return null
    }
    
    const data = JSON.parse(decoded.toString())
    return { userId: data.userId, exp: parseInt(timestamp) }
  } catch (error) {
    return null
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password } = loginSchema.parse(body)

    // Find user
    const user = await db.user.findUnique({
      where: { email, isActive: true }
    })

    if (!user) {
      return NextResponse.json(
        { error: 'Email atau password salah' },
        { status: 401 }
      )
    }

    if (user.password !== password) {
      return NextResponse.json(
        { error: 'Password salah' },
        { status: 401 }
      )
    }

    if (!user.isActive) {
      return NextResponse.json(
        { error: 'Akun dinonaktifkan' },
        { status: 403 }
      )
    }

    // Generate token
    const token = generateToken(user.id).toString('base64')

    // Create session
    const session = await db.session.create({
      data: {
        userId: user.id,
        token,
        expiresAt: new Date(Date.now() + 60 * 60 * 1000), // 1 hour
      }
    })

    // Log activity
    await db.activityLog.create({
      data: {
        userId: user.id,
        action: 'login',
        entity: 'User',
        details: JSON.stringify({ email: user.email }),
      }
    })

    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      },
      token,
      expiresIn: 3600, // 1 hour in seconds
    })
  } catch (error) {
    console.error('Login error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan internal' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization')
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const token = authHeader.substring(7)
    const payload = verifyToken(token)
    
    if (!payload) {
      return NextResponse.json(
        { error: 'Token tidak valid' },
        { status: 401 }
      )
    }

    const user = await db.user.findUnique({
      where: { id: payload.userId }
    })

    if (!user || !user.isActive) {
      return NextResponse.json(
        { error: 'User tidak ditemukan' },
        { status: 404 }
      )
    }

    // Check session
    const session = await db.session.findFirst({
      where: {
        token,
        expiresAt: { gt: new Date() }
      }
    })

    if (!session) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      },
      active: session.expiresAt > new Date(),
    })
  } catch (error) {
    console.error('Auth error:', error)
    return NextResponse.json(
      { error: 'Gagal memverifikasi authentikasi' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization')
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const token = authHeader.substring(7)
    const payload = verifyToken(token)
    
    if (!payload) {
      return NextResponse.json(
        { error: 'Token tidak valid' },
        { status: 401 }
      )
    }

    // Find session
    const session = await db.session.findFirst({
      where: {
        token,
        expiresAt: { gt: new Date() }
      }
    })

    if (!session) {
      return NextResponse.json(
        { error: 'Session tidak ditemukan' },
        { status: 404 }
      )
    }

    // Delete session
    await db.session.deleteMany({
      where: { token }
    })

    // Log activity
    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'logout',
        entity: 'User',
      }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Logout error:', error)
    return NextResponse.json(
      { error: 'Gagal logout' },
      { status: 500 }
    )
  }
}
