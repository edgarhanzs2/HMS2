import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Get all users
export async function GET(request: NextRequest) {
  try {
    const users = await db.user.findMany({
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        isActive: true,
        sessions: true,
        activityLogs: true,
        createdAt: true,
        updatedAt: true,
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json(users)
  } catch (error) {
    console.error('Error fetching users:', error)
    return NextResponse.json(
      { error: 'Gagal mengambil users' },
      { status: 500 }
    )
  }
}

// Create user
export async function POST(request: NextRequest) {
  try {
    const { email, password, name, role } = await request.json()

    if (!email || !password || !name) {
      return NextResponse.json(
        { error: 'Email, password, dan name harus diisi' },
        { status: 400 }
      )
    }

    // Check if user exists
    const existing = await db.user.findUnique({
      where: { email }
    })

    if (existing) {
      return NextResponse.json(
        { error: 'User dengan email ini sudah ada' },
        { status: 409 }
      )
    }

    const user = await db.user.create({
      data: {
        email,
        password, // In production, hash this!
        name,
        role: role || 'staff',
      }
    })

    return NextResponse.json({
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role
    })
  } catch (error) {
    console.error('Error creating user:', error)
    return NextResponse.json(
      { error: 'Gagal membuat user' },
      { status: 500 }
    )
  }
}

// Update user
export async function PUT(request: NextRequest) {
  try {
    const { id, email, password, name, role } = await request.json()

    if (!id) {
      return NextResponse.json(
        { error: 'User ID tidak ditemukan' },
        { status: 400 }
      )
    }

    const updateData: any = {}

    if (email) updateData.email = email
    if (password) updateData.password = password
    if (name) updateData.name = name
    if (role) updateData.role = role

    const updatedUser = await db.user.update({
      where: { id },
      data: updateData,
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
      }
    })

    return NextResponse.json(updatedUser)
  } catch (error) {
    console.error('Error updating user:', error)
    return NextResponse.json(
      { error: 'Gagal update user' },
      { status: 500 }
    )
  }
}

// Delete user
export async function DELETE(request: NextRequest) {
  try {
    const { id } = await request.json()

    if (!id) {
      return NextResponse.json(
        { error: 'User ID diperlukan' },
        { status: 400 }
      )
    }

    await db.session.deleteMany({
      where: { userId: id }
    })

    await db.user.delete({
      where: { id }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting user:', error)
    return NextResponse.json(
      { error: 'Gagal menghapus user' },
      { status: 500 }
    )
  }
}
