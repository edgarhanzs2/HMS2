import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const bookings = await db.booking.findMany({
      include: {
        room: true,
        guest: true
      },
      orderBy: { createdAt: 'desc' }
    })
    return NextResponse.json(bookings)
  } catch (error) {
    console.error('Error fetching bookings:', error)
    return NextResponse.json(
      { error: 'Failed to fetch bookings' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    console.log('Booking request body:', body)

    const { roomId, guestId, checkInDate, checkOutDate, totalCost, status, specialRequests } = body

    if (!roomId || !guestId || !checkInDate || !checkOutDate) {
      console.error('Missing required fields:', { roomId, guestId, checkInDate, checkOutDate })
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Validate guest exists
    const guest = await db.guest.findUnique({
      where: { id: guestId }
    })

    if (!guest) {
      console.error('Guest not found:', guestId)
      return NextResponse.json(
        { error: 'Guest not found' },
        { status: 404 }
      )
    }

    // Validate room exists
    const room = await db.room.findUnique({
      where: { id: roomId }
    })

    if (!room) {
      console.error('Room not found:', roomId)
      return NextResponse.json(
        { error: 'Room not found' },
        { status: 404 }
      )
    }

    // Validate dates
    const checkIn = new Date(checkInDate)
    const checkOut = new Date(checkOutDate)
    const nights = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24))

    if (nights <= 0) {
      console.error('Invalid dates:', { checkInDate, checkOutDate, nights })
      return NextResponse.json(
        { error: 'Check-out date must be after check-in date' },
        { status: 400 }
      )
    }

    // Create booking
    const booking = await db.booking.create({
      data: {
        roomId,
        guestId,
        checkInDate,
        checkOutDate,
        totalCost: totalCost || nights * room.price,
        status: status || 'Confirmed',
        specialRequests: specialRequests || null
      }
    })

    console.log('Booking created successfully:', booking.id)
    return NextResponse.json(booking, { status: 201 })
  } catch (error) {
    console.error('Error creating booking:', error)
    return NextResponse.json(
      { error: 'Failed to create booking' },
      { status: 500 }
    )
  }
}
