'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import {
  CalendarDays,
  Users,
  MapPin,
  Phone,
  Mail,
  LayoutDashboard,
  CheckCircle2,
  XCircle,
  Clock,
  Plus,
  Search,
  Filter,
  LogOut,
  Shield,
  User,
  Building2,
  Calendar as CalendarIcon,
  Trash2,
  Edit
} from 'lucide-react'
import { format, addDays, differenceInDays } from 'date-fns'
import { id } from 'date-fns/locale'

interface Room {
  id: string
  roomNumber: string
  type: string
  price: number
  status: string
  description: string | null
  image: string | null
}

interface Guest {
  id: string
  name: string
  email: string
  phone: string
}

interface Booking {
  id: string
  roomId: string
  guestId: string
  checkInDate: string
  checkOutDate: string
  totalCost: number
  status: string
  specialRequests: string | null
  createdAt: string
  room?: Room
  guest?: Guest
}

interface User {
  id: string
  email: string
  name: string
  role: string
}

type FormData = {
  email: string
  password: string
}

export default function HotelManagementSystem() {
  // Authentication state
  const [user, setUser] = useState<User | null>(null)
  const [showLogin, setShowLogin] = useState(false)
  const [authFormData, setAuthFormData] = useState<FormData>({ email: '', password: '' })
  const [authLoading, setAuthLoading] = useState(false)
  const [authError, setAuthError] = useState('')

  // Data state
  const [rooms, setRooms] = useState<Room[]>([])
  const [bookings, setBookings] = useState<Booking[]>([])
  const [guests, setGuests] = useState<Guest[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)

  // Search & Booking state
  const [checkInDate, setCheckInDate] = useState<Date | undefined>()
  const [checkOutDate, setCheckOutDate] = useState<Date | undefined>()
  const [guestCount, setGuestCount] = useState('2')
  const [roomType, setRoomType] = useState('all')
  const [searchResults, setSearchResults] = useState<Room[]>([])

  // Dialog states
  const [showBookingDialog, setShowBookingDialog] = useState(false)
  const [showRoomDialog, setShowRoomDialog] = useState(false)
  const [showUserDialog, setShowUserDialog] = useState(false)
  const [showRoomDetailDialog, setShowRoomDetailDialog] = useState(false)
  const [editingRoom, setEditingRoom] = useState<Room | null>(null)
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null)

  // Form states
  const [roomFormData, setRoomFormData] = useState({
    roomNumber: '',
    type: 'Standard',
    price: '',
    description: '',
    status: 'Available',
    image: ''
  })
  const [bookingFormData, setBookingFormData] = useState({
    roomId: '',
    guestId: '',
    guestName: '',
    guestEmail: '',
    guestPhone: '',
    specialRequests: ''
  })
  const [userFormData, setUserFormData] = useState({
    email: '',
    password: '',
    name: '',
    role: 'staff'
  })

  // Load authentication state on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('user')
    const storedToken = localStorage.getItem('token')
    if (storedUser && storedToken) {
      setUser(JSON.parse(storedUser))
    }
    fetchData()
  }, [])

  // Fetch data
  const fetchData = async () => {
    try {
      const [roomsRes, bookingsRes, guestsRes, usersRes] = await Promise.all([
        fetch('/api/rooms'),
        fetch('/api/bookings'),
        fetch('/api/guests'),
        fetch('/api/users')
      ])

      const [roomsData, bookingsData, guestsData, usersData] = await Promise.all([
        roomsRes.json(),
        bookingsRes.json(),
        guestsRes.json(),
        usersRes.json()
      ])

      setRooms(roomsData)
      setBookings(bookingsData)
      setGuests(guestsData)
      setUsers(usersData)
      setLoading(false)
    } catch (error) {
      console.error('Error fetching data:', error)
      setLoading(false)
    }
  }

  // Login handler
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setAuthLoading(true)
    setAuthError('')

    try {
      const response = await fetch('/api/auth-new', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(authFormData)
      })

      const data = await response.json()

      if (data.error) {
        setAuthError(data.error)
        setAuthLoading(false)
        return
      }

      if (data.token && data.user) {
        localStorage.setItem('token', data.token)
        localStorage.setItem('user', JSON.stringify(data.user))
        setUser(data.user)
        setShowLogin(false)
        setAuthFormData({ email: '', password: '' })
      }
    } catch (err) {
      setAuthError('Login gagal: ' + (err as Error).message)
    } finally {
      setAuthLoading(false)
    }
  }

  // Logout handler
  const handleLogout = async () => {
    const token = localStorage.getItem('token')
    if (token) {
      await fetch('/api/auth-new', {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      })
    }
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    setUser(null)
  }

  // Search rooms
  const handleSearch = () => {
    if (!checkInDate || !checkOutDate) {
      alert('Silakan pilih tanggal check-in dan check-out')
      return
    }

    const filtered = rooms.filter(room => {
      if (roomType && roomType !== 'all' && room.type !== roomType) return false

      const isBooked = bookings.some(booking => {
        if (booking.status === 'Canceled') return false
        if (booking.roomId !== room.id) return false
        const bookingStart = new Date(booking.checkInDate)
        const bookingEnd = new Date(booking.checkOutDate)
        return checkInDate < bookingEnd && checkOutDate > bookingStart
      })

      return !isBooked
    })

    setSearchResults(filtered)
  }

  // Create booking
  const handleCreateBooking = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!checkInDate || !checkOutDate) {
      alert('Silakan pilih tanggal check-in dan check-out')
      return
    }

    const nights = differenceInDays(checkOutDate, checkInDate)
    if (nights <= 0) {
      alert('Tanggal check-out harus setelah check-in')
      return
    }

    const selectedRoom = rooms.find(r => r.id === bookingFormData.roomId)
    if (!selectedRoom) {
      alert('Kamar tidak ditemukan')
      return
    }

    const totalCost = nights * selectedRoom.price

    try {
      // Create guest
      let guestId = bookingFormData.guestId
      if (!guestId) {
        const guestRes = await fetch('/api/guests', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: bookingFormData.guestName,
            email: bookingFormData.guestEmail,
            phone: bookingFormData.guestPhone
          })
        })

        if (!guestRes.ok) {
          const errorData = await guestRes.json()
          throw new Error(errorData.error || 'Gagal membuat guest')
        }

        const guestData = await guestRes.json()
        guestId = guestData.id
      }

      // Create booking
      const bookingRes = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roomId: bookingFormData.roomId,
          guestId: guestId,
          checkInDate: checkInDate.toISOString(),
          checkOutDate: checkOutDate.toISOString(),
          totalCost,
          status: 'Confirmed',
          specialRequests: bookingFormData.specialRequests || null
        })
      })

      if (!bookingRes.ok) {
        const errorData = await bookingRes.json()
        throw new Error(errorData.error || 'Gagal membuat reservasi')
      }

      // Update room status
      const roomRes = await fetch(`/api/rooms/${bookingFormData.roomId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'Booked' })
      })

      if (!roomRes.ok) {
        console.warn('Failed to update room status, but booking was created')
      }

      setShowBookingDialog(false)
      setBookingFormData({
        roomId: '',
        guestName: '',
        guestEmail: '',
        guestPhone: '',
        specialRequests: ''
      })
      setCheckInDate(undefined)
      setCheckOutDate(undefined)
      fetchData()
      alert('Reservasi berhasil dibuat!')
    } catch (error) {
      console.error('Error creating booking:', error)
      alert('Gagal membuat reservasi: ' + (error as Error).message)
    }
  }

  // Handle image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setRoomFormData(prev => ({ ...prev, image: reader.result as string }))
      }
      reader.readAsDataURL(file)
    }
  }

  // Create room
  const handleCreateRoom = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const response = await fetch('/api/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roomNumber: roomFormData.roomNumber,
          type: roomFormData.type,
          price: parseFloat(roomFormData.price),
          description: roomFormData.description || null,
          status: roomFormData.status,
          image: roomFormData.image || null
        })
      })

      if (!response.ok) {
        throw new Error('Gagal menambah kamar')
      }

      setShowRoomDialog(false)
      setRoomFormData({
        roomNumber: '',
        type: 'Standard',
        price: '',
        description: '',
        status: 'Available',
        image: ''
      })
      fetchData()
      alert('Kamar berhasil ditambahkan!')
    } catch (error) {
      console.error('Error creating room:', error)
      alert('Gagal menambah kamar: ' + (error as Error).message)
    }
  }

  // Update room
  const handleUpdateRoom = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!editingRoom) return

    try {
      const response = await fetch(`/api/rooms/${editingRoom.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roomNumber: roomFormData.roomNumber,
          type: roomFormData.type,
          price: parseFloat(roomFormData.price),
          description: roomFormData.description || null,
          status: roomFormData.status,
          image: roomFormData.image || null
        })
      })

      if (!response.ok) {
        throw new Error('Gagal mengupdate kamar')
      }

      setShowRoomDialog(false)
      setEditingRoom(null)
      setRoomFormData({
        roomNumber: '',
        type: 'Standard',
        price: '',
        description: '',
        status: 'Available',
        image: ''
      })
      fetchData()
      alert('Kamar berhasil diupdate!')
    } catch (error) {
      console.error('Error updating room:', error)
      alert('Gagal mengupdate kamar: ' + (error as Error).message)
    }
  }

  // Delete room
  const handleDeleteRoom = async (roomId: string) => {
    if (!confirm('Yakin ingin menghapus kamar ini?')) return

    try {
      const response = await fetch(`/api/rooms/${roomId}`, {
        method: 'DELETE'
      })

      if (!response.ok) {
        throw new Error('Gagal menghapus kamar')
      }

      fetchData()
      alert('Kamar berhasil dihapus!')
    } catch (error) {
      console.error('Error deleting room:', error)
      alert('Gagal menghapus kamar: ' + (error as Error).message)
    }
  }

  // Create user
  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userFormData)
      })

      if (!response.ok) {
        throw new Error('Gagal menambah pengguna')
      }

      setShowUserDialog(false)
      setUserFormData({
        email: '',
        password: '',
        name: '',
        role: 'staff'
      })
      fetchData()
      alert('Pengguna berhasil ditambahkan!')
    } catch (error) {
      console.error('Error creating user:', error)
      alert('Gagal menambah pengguna: ' + (error as Error).message)
    }
  }

  // Update user
  const handleUpdateUser = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!editingUser) return

    try {
      const response = await fetch('/api/users', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: editingUser.id,
          ...userFormData
        })
      })

      if (!response.ok) {
        throw new Error('Gagal mengupdate pengguna')
      }

      setShowUserDialog(false)
      setEditingUser(null)
      setUserFormData({
        email: '',
        password: '',
        name: '',
        role: 'staff'
      })
      fetchData()
      alert('Pengguna berhasil diupdate!')
    } catch (error) {
      console.error('Error updating user:', error)
      alert('Gagal mengupdate pengguna: ' + (error as Error).message)
    }
  }

  // Delete user
  const handleDeleteUser = async (userId: string, userName: string) => {
    if (!confirm(`Yakin ingin menghapus pengguna "${userName}"?`)) return

    try {
      const response = await fetch('/api/users', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: userId })
      })

      if (!response.ok) {
        throw new Error('Gagal menghapus pengguna')
      }

      fetchData()
      alert('Pengguna berhasil dihapus!')
    } catch (error) {
      console.error('Error deleting user:', error)
      alert('Gagal menghapus pengguna: ' + (error as Error).message)
    }
  }

  // Open user dialog for editing
  const openEditUserDialog = (user: User) => {
    setEditingUser(user)
    setUserFormData({
      email: user.email,
      password: '',
      name: user.name,
      role: user.role
    })
    setShowUserDialog(true)
  }

  // Update booking status
  const handleUpdateBookingStatus = async (bookingId: string, status: string) => {
    try {
      const response = await fetch(`/api/bookings/${bookingId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      })

      if (!response.ok) {
        throw new Error('Gagal mengupdate booking')
      }

      fetchData()
      alert('Booking berhasil diupdate!')
    } catch (error) {
      console.error('Error updating booking:', error)
      alert('Gagal mengupdate booking: ' + (error as Error).message)
    }
  }

  // Open room dialog for editing
  const openEditRoomDialog = (room: Room) => {
    setEditingRoom(room)
    setRoomFormData({
      roomNumber: room.roomNumber,
      type: room.type,
      price: room.price.toString(),
      description: room.description || '',
      status: room.status,
      image: room.image || ''
    })
    setShowRoomDialog(true)
  }

  // Open room detail dialog
  const openRoomDetailDialog = (room: Room) => {
    setSelectedRoom(room)
    setShowRoomDetailDialog(true)
  }

  // Open booking dialog
  const openBookingDialog = (roomId: string) => {
    setBookingFormData(prev => ({ ...prev, roomId }))
    setShowBookingDialog(true)
  }

  if (showLogin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-stone-50 via-emerald-50/30 to-emerald-50/20">
        {/* Header */}
        <header className="bg-white/80 backdrop-blur-sm border-b border-stone-200 sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center shadow-lg overflow-hidden bg-white">
                <img
                  src="/logo.png"
                  alt="Arika Homestay Logo"
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <h1 className="text-xl font-bold text-stone-900">Arika Homestay</h1>
                <p className="text-xs text-stone-500">Rehat Sejenak, Senyaman Rumah.</p>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="container mx-auto px-4 py-12">
          <div className="max-w-md mx-auto">
            <Card className="bg-white border-stone-200 shadow-xl">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-stone-900">Login Staff</CardTitle>
                <CardDescription>
                  Masukan email dan password staff untuk masuk ke dashboard
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-6">
                {authError && (
                  <div className="p-4 bg-red-50 border-red-200 rounded-lg flex items-center gap-2">
                    <XCircle className="w-10 h-10 text-red-500" />
                    <div>
                      <p className="font-semibold text-red-900">{authError}</p>
                      <p className="text-red-700 text-sm">{authError}</p>
                    </div>
                  </div>
                )}

                <form onSubmit={handleLogin}>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="staff@arika.com"
                        value={authFormData.email}
                        onChange={(e) => setAuthFormData(prev => ({ ...prev, email: e.target.value }))}
                        disabled={authLoading}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="password">Password</Label>
                      <Input
                        id="password"
                        type="password"
                        placeholder="•••••••••••"
                        value={authFormData.password}
                        onChange={(e) => setAuthFormData(prev => ({ ...prev, password: e.target.value }))}
                        disabled={authLoading}
                        required
                      />
                    </div>

                    <div className="pt-6">
                      <Button
                        type="submit"
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                        disabled={authLoading || !authFormData.email || !authFormData.password}
                      >
                        {authLoading ? 'Memproses...' : 'Login'}
                      </Button>
                    </div>

                    <div className="pt-4">
                      <Button
                        type="button"
                        variant="ghost"
                        className="w-full"
                        onClick={() => setShowLogin(false)}
                      >
                        Kembali ke Halaman Utama
                      </Button>
                    </div>
                  </div>
                </form>

                <div className="p-4 bg-stone-50 border border-stone-200 rounded-lg text-sm">
                  <p className="font-semibold text-stone-900 mb-2">Akun Demo:</p>
                  <p className="text-stone-700">
                    Admin: <span className="font-mono">admin@arika.com</span> / <span className="font-mono">admin123</span>
                  </p>
                  <p className="text-stone-700 mt-1">
                    Front Desk: <span className="font-mono">frontdesk@arika.com</span> / <span className="font-mono">frontdesk123</span>
                  </p>
                  <p className="text-stone-700 mt-1">
                    Housekeeping: <span className="font-mono">housekeeping@arika.com</span> / <span className="font-mono">housekeeping123</span>
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>

        {/* Footer */}
        <footer className="mt-auto bg-white border-t border-stone-200">
          <div className="container mx-auto px-4 py-6">
            <div className="text-center text-stone-600">
              <p className="text-sm">© 2026 Arika Homestay. All rights reserved.</p>
            </div>
          </div>
        </footer>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-50 via-emerald-50/30 to-emerald-50/20 flex flex-col">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-stone-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center shadow-lg overflow-hidden bg-white">
                <img
                  src="/logo.png"
                  alt="Arika Homestay Logo"
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-stone-900">Arika Homestay</h1>
                <p className="text-sm text-stone-500">Rehat Sejenak, Senyaman Rumah.</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              {user ? (
                <>
                  <div className="hidden md:flex items-center gap-2 text-stone-700">
                    <User className="w-4 h-4" />
                    <span className="font-medium">{user.name}</span>
                    <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-xs rounded-full">
                      {user.role === 'super_admin' ? 'Super Admin' :
                       user.role === 'admin' ? 'Admin' :
                       user.role === 'front_desk' ? 'Front Desk' : 'Housekeeping'}
                    </span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleLogout}
                    className="border-stone-300 text-stone-700 hover:bg-stone-50"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </Button>
                </>
              ) : (
                <Button
                  onClick={() => setShowLogin(true)}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  <LayoutDashboard className="w-4 h-4 mr-2" />
                  Login Admin
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-8">
        {!user ? (
          // Public View
          <div className="space-y-8">
            {/* Hero Section */}
            <section className="text-center py-12 bg-emerald-600 rounded-2xl shadow-lg p-8">
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
                Selamat Datang di Arika Homestay
              </h2>
              <p className="text-lg text-emerald-50 mb-8 max-w-2xl mx-auto">
                Nikmati kenyamanan dan kemewahan dengan harga terjangkau. Pesan kamar impian Anda sekarang!
              </p>

              {/* Search Form */}
              <Card className="max-w-4xl mx-auto">
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    {/* Check In Date */}
                    <div className="space-y-2">
                      <Label className="text-stone-700 flex items-center gap-2">
                        <CalendarDays className="w-4 h-4" />
                        Check In
                      </Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="w-full justify-start text-left font-normal border-stone-300 text-stone-700"
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {checkInDate ? format(checkInDate, 'PPP', { locale: id }) : 'Pilih tanggal'}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={checkInDate}
                            onSelect={(date) => {
                              setCheckInDate(date)
                              if (date && checkOutDate && date > checkOutDate) {
                                setCheckOutDate(addDays(date, 1))
                              }
                            }}
                            disabled={(date) => date < new Date()}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>

                    {/* Check Out Date */}
                    <div className="space-y-2">
                      <Label className="text-stone-700 flex items-center gap-2">
                        <CalendarDays className="w-4 h-4" />
                        Check Out
                      </Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="w-full justify-start text-left font-normal border-stone-300 text-stone-700"
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {checkOutDate ? format(checkOutDate, 'PPP', { locale: id }) : 'Pilih tanggal'}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={checkOutDate}
                            onSelect={(date) => {
                              setCheckOutDate(date)
                            }}
                            disabled={(date) => !checkInDate || date <= checkInDate}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>

                    {/* Guest Count */}
                    <div className="space-y-2">
                      <Label className="text-stone-700 flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        Tamu
                      </Label>
                      <Select value={guestCount} onValueChange={setGuestCount}>
                        <SelectTrigger className="border-stone-300 text-stone-700">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 Tamu</SelectItem>
                          <SelectItem value="2">2 Tamu</SelectItem>
                          <SelectItem value="3">3 Tamu</SelectItem>
                          <SelectItem value="4">4+ Tamu</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Room Type */}
                    <div className="space-y-2">
                      <Label className="text-stone-700 flex items-center gap-2">
                        <Building2 className="w-4 h-4" />
                        Tipe Kamar
                      </Label>
                      <Select value={roomType} onValueChange={setRoomType}>
                        <SelectTrigger className="border-stone-300 text-stone-700">
                          <SelectValue placeholder="Semua tipe" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Semua tipe</SelectItem>
                          <SelectItem value="Standard">Standard</SelectItem>
                          <SelectItem value="Deluxe">Deluxe</SelectItem>
                          <SelectItem value="Suite">Suite</SelectItem>
                          <SelectItem value="Presidential">Presidential</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="mt-6">
                    <Button
                      onClick={handleSearch}
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                      size="lg"
                    >
                      <Search className="w-5 h-5 mr-2" />
                      Cari Ketersediaan
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </section>

            {/* Search Results */}
            {searchResults.length > 0 && (
              <section>
                <h3 className="text-2xl font-bold text-stone-900 mb-6">Kamar Tersedia</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {searchResults.map((room) => (
                    <Card
                      key={room.id}
                      className="bg-white border-stone-200 shadow-lg hover:shadow-xl transition-shadow cursor-pointer overflow-hidden"
                      onClick={() => openRoomDetailDialog(room)}
                    >
                      {/* Room Image */}
                      <div className="relative w-full h-48 bg-stone-100">
                        {room.image ? (
                          <img
                            src={room.image}
                            alt={`Kamar ${room.roomNumber}`}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-stone-300">
                            <Building2 className="w-16 h-16" />
                          </div>
                        )}
                        <div className="absolute top-3 right-3">
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                            room.status === 'Available' ? 'bg-emerald-500 text-white' :
                            room.status === 'Booked' ? 'bg-red-500 text-white' :
                            'bg-amber-500 text-white'
                          }`}>
                            {room.status === 'Available' ? 'Tersedia' :
                             room.status === 'Booked' ? 'Terpesan' : 'Maintenance'}
                          </span>
                        </div>
                      </div>
                      <CardContent className="p-6">
                        <div className="mb-4">
                          <h4 className="text-xl font-bold text-stone-900">Kamar {room.roomNumber}</h4>
                          <p className="text-stone-600">{room.type}</p>
                        </div>

                        {room.description && (
                          <p className="text-stone-600 mb-4 line-clamp-2">{room.description}</p>
                        )}

                        <div className="flex items-baseline gap-1 mb-4">
                          <span className="text-3xl font-bold text-emerald-600">
                            Rp {room.price.toLocaleString('id-ID')}
                          </span>
                          <span className="text-stone-600">/malam</span>
                        </div>

                        {room.status === 'Available' && (
                          <Button
                            onClick={(e) => {
                              e.stopPropagation()
                              openBookingDialog(room.id)
                            }}
                            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                          >
                            Pesan Sekarang
                          </Button>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </section>
            )}

            {/* All Rooms */}
            <section>
              <h3 className="text-2xl font-bold text-stone-900 mb-6">Semua Kamar Kami</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {rooms.map((room) => (
                  <Card
                    key={room.id}
                    className="bg-white border-stone-200 shadow-lg hover:shadow-xl transition-shadow cursor-pointer overflow-hidden"
                    onClick={() => openRoomDetailDialog(room)}
                  >
                    {/* Room Image */}
                    <div className="relative w-full h-48 bg-stone-100">
                      {room.image ? (
                        <img
                          src={room.image}
                          alt={`Kamar ${room.roomNumber}`}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-stone-300">
                          <Building2 className="w-16 h-16" />
                        </div>
                      )}
                      <div className="absolute top-3 right-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          room.status === 'Available' ? 'bg-emerald-500 text-white' :
                          room.status === 'Booked' ? 'bg-red-500 text-white' :
                          'bg-amber-500 text-white'
                        }`}>
                          {room.status === 'Available' ? 'Tersedia' :
                           room.status === 'Booked' ? 'Terpesan' : 'Maintenance'}
                        </span>
                      </div>
                    </div>
                    <CardContent className="p-6">
                      <div className="mb-4">
                        <h4 className="text-lg font-bold text-stone-900">Kamar {room.roomNumber}</h4>
                        <p className="text-sm text-stone-600">{room.type}</p>
                      </div>

                      {room.description && (
                        <p className="text-sm text-stone-600 mb-3 line-clamp-2">{room.description}</p>
                      )}

                      <div className="flex items-baseline gap-1">
                        <span className="text-2xl font-bold text-emerald-600">
                          Rp {room.price.toLocaleString('id-ID')}
                        </span>
                        <span className="text-sm text-stone-600">/malam</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>
          </div>
        ) : (
          // Admin Dashboard
          <div className="space-y-8">
            {/* Dashboard Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card className="bg-white border-stone-200 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-stone-600">Total Kamar</p>
                      <p className="text-3xl font-bold text-stone-900">{rooms.length}</p>
                    </div>
                    <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center">
                      <Building2 className="w-6 h-6 text-emerald-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white border-stone-200 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-stone-600">Total Booking</p>
                      <p className="text-3xl font-bold text-stone-900">{bookings.length}</p>
                    </div>
                    <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                      <CalendarDays className="w-6 h-6 text-blue-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white border-stone-200 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-stone-600">Total Tamu</p>
                      <p className="text-3xl font-bold text-stone-900">{guests.length}</p>
                    </div>
                    <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center">
                      <Users className="w-6 h-6 text-purple-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white border-stone-200 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-stone-600">Kamar Tersedia</p>
                      <p className="text-3xl font-bold text-stone-900">
                        {rooms.filter(r => r.status === 'Available').length}
                      </p>
                    </div>
                    <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                      <CheckCircle2 className="w-6 h-6 text-green-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Management Tabs */}
            <Tabs defaultValue="rooms" className="space-y-6">
              <TabsList className="bg-white border-stone-200">
                <TabsTrigger value="rooms" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                  <Building2 className="w-4 h-4 mr-2" />
                  Manajemen Kamar
                </TabsTrigger>
                <TabsTrigger value="bookings" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                  <CalendarDays className="w-4 h-4 mr-2" />
                  Manajemen Booking
                </TabsTrigger>
                <TabsTrigger value="guests" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                  <Users className="w-4 h-4 mr-2" />
                  Manajemen Tamu
                </TabsTrigger>
                {user?.role === 'super_admin' && (
                  <TabsTrigger value="users" className="data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                    <Shield className="w-4 h-4 mr-2" />
                    Manajemen Pengguna
                  </TabsTrigger>
                )}
              </TabsList>

              {/* Rooms Tab */}
              <TabsContent value="rooms">
                <Card className="bg-white border-stone-200">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>Daftar Kamar</CardTitle>
                        <CardDescription>Kelola semua kamar di Arika Homestay</CardDescription>
                      </div>
                      {(user?.role === 'super_admin' || user?.role === 'admin') && (
                        <Button
                          onClick={() => {
                            setEditingRoom(null)
                            setRoomFormData({
                              roomNumber: '',
                              type: 'Standard',
                              price: '',
                              description: '',
                              status: 'Available',
                              image: ''
                            })
                            setShowRoomDialog(true)
                          }}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white"
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Tambah Kamar
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="rounded-md border border-stone-200">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-stone-50">
                            <TableHead>Nomor</TableHead>
                            <TableHead>Tipe</TableHead>
                            <TableHead>Harga</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Deskripsi</TableHead>
                            <TableHead className="text-right">Aksi</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {rooms.map((room) => (
                            <TableRow key={room.id}>
                              <TableCell className="font-medium">
                                <button
                                  onClick={() => openRoomDetailDialog(room)}
                                  className="text-emerald-600 hover:text-emerald-700 hover:underline font-medium"
                                >
                                  {room.roomNumber}
                                </button>
                              </TableCell>
                              <TableCell>{room.type}</TableCell>
                              <TableCell>Rp {room.price.toLocaleString('id-ID')}</TableCell>
                              <TableCell>
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                  room.status === 'Available' ? 'bg-emerald-100 text-emerald-700' :
                                  room.status === 'Booked' ? 'bg-red-100 text-red-700' :
                                  'bg-amber-100 text-amber-700'
                                }`}>
                                  {room.status === 'Available' ? 'Tersedia' :
                                   room.status === 'Booked' ? 'Terpesan' : 'Maintenance'}
                                </span>
                              </TableCell>
                              <TableCell className="max-w-xs truncate">{room.description || '-'}</TableCell>
                              <TableCell className="text-right">
                                <div className="flex items-center justify-end gap-2">
                                  {(user?.role === 'super_admin' || user?.role === 'admin') && (
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => openEditRoomDialog(room)}
                                      className="border-stone-300 text-stone-700"
                                    >
                                      <Edit className="w-4 h-4" />
                                    </Button>
                                  )}
                                  {user?.role === 'super_admin' && (
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleDeleteRoom(room.id)}
                                      className="border-red-300 text-red-600 hover:bg-red-50"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </Button>
                                  )}
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Bookings Tab */}
              <TabsContent value="bookings">
                <Card className="bg-white border-stone-200">
                  <CardHeader>
                    <div>
                      <CardTitle>Daftar Booking</CardTitle>
                      <CardDescription>Kelola semua reservasi tamu</CardDescription>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="rounded-md border border-stone-200">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-stone-50">
                            <TableHead>ID Booking</TableHead>
                            <TableHead>Kamar</TableHead>
                            <TableHead>Tamu</TableHead>
                            <TableHead>Check In</TableHead>
                            <TableHead>Check Out</TableHead>
                            <TableHead>Total</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead className="text-right">Aksi</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {bookings.map((booking) => (
                            <TableRow key={booking.id}>
                              <TableCell className="font-medium text-xs">{booking.id.slice(0, 8)}...</TableCell>
                              <TableCell>{booking.room?.roomNumber || '-'}</TableCell>
                              <TableCell>{booking.guest?.name || '-'}</TableCell>
                              <TableCell>{format(new Date(booking.checkInDate), 'dd MMM yyyy', { locale: id })}</TableCell>
                              <TableCell>{format(new Date(booking.checkOutDate), 'dd MMM yyyy', { locale: id })}</TableCell>
                              <TableCell>Rp {booking.totalCost.toLocaleString('id-ID')}</TableCell>
                              <TableCell>
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                  booking.status === 'Confirmed' ? 'bg-emerald-100 text-emerald-700' :
                                  booking.status === 'Completed' ? 'bg-blue-100 text-blue-700' :
                                  'bg-red-100 text-red-700'
                                }`}>
                                  {booking.status === 'Confirmed' ? 'Confirmed' :
                                   booking.status === 'Completed' ? 'Completed' : 'Canceled'}
                                </span>
                              </TableCell>
                              <TableCell className="text-right">
                                {booking.status === 'Confirmed' && (
                                  <div className="flex items-center justify-end gap-2">
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleUpdateBookingStatus(booking.id, 'Completed')}
                                      className="border-emerald-300 text-emerald-600"
                                    >
                                      <CheckCircle2 className="w-4 h-4" />
                                    </Button>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleUpdateBookingStatus(booking.id, 'Canceled')}
                                      className="border-red-300 text-red-600"
                                    >
                                      <XCircle className="w-4 h-4" />
                                    </Button>
                                  </div>
                                )}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Guests Tab */}
              <TabsContent value="guests">
                <Card className="bg-white border-stone-200">
                  <CardHeader>
                    <div>
                      <CardTitle>Daftar Tamu</CardTitle>
                      <CardDescription>Informasi semua tamu yang pernah menginap</CardDescription>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="rounded-md border border-stone-200">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-stone-50">
                            <TableHead>Nama</TableHead>
                            <TableHead>Email</TableHead>
                            <TableHead>Telepon</TableHead>
                            <TableHead>Total Booking</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {guests.map((guest) => (
                            <TableRow key={guest.id}>
                              <TableCell className="font-medium">{guest.name}</TableCell>
                              <TableCell>{guest.email}</TableCell>
                              <TableCell>{guest.phone}</TableCell>
                              <TableCell>
                                {bookings.filter(b => b.guestId === guest.id).length} booking
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Users Tab - Only for Super Admin */}
              {user?.role === 'super_admin' && (
                <TabsContent value="users">
                  <Card className="bg-white border-stone-200">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle>Daftar Pengguna</CardTitle>
                          <CardDescription>Kelola akses staf dan admin sistem</CardDescription>
                        </div>
                        <Dialog open={showUserDialog} onOpenChange={setShowUserDialog}>
                          <DialogTrigger asChild>
                            <Button
                              onClick={() => {
                                setEditingUser(null)
                                setUserFormData({
                                  email: '',
                                  password: '',
                                  name: '',
                                  role: 'staff'
                                })
                              }}
                              className="bg-emerald-600 hover:bg-emerald-700 text-white"
                            >
                              <Plus className="w-4 h-4 mr-2" />
                              Tambah Pengguna
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="sm:max-w-[500px]">
                            <DialogHeader>
                              <DialogTitle>
                                {editingUser ? 'Edit Pengguna' : 'Tambah Pengguna Baru'}
                              </DialogTitle>
                              <DialogDescription>
                                {editingUser
                                  ? 'Update informasi pengguna. Password boleh dikosongkan jika tidak ingin diubah.'
                                  : 'Buat akun baru untuk staf atau admin.'}
                              </DialogDescription>
                            </DialogHeader>
                            <form onSubmit={editingUser ? handleUpdateUser : handleCreateUser}>
                              <div className="space-y-4 py-4">
                                <div className="space-y-2">
                                  <Label htmlFor="userName">Nama Lengkap</Label>
                                  <Input
                                    id="userName"
                                    value={userFormData.name}
                                    onChange={(e) => setUserFormData({ ...userFormData, name: e.target.value })}
                                    placeholder="Masukkan nama lengkap"
                                    required
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="userEmail">Email</Label>
                                  <Input
                                    id="userEmail"
                                    type="email"
                                    value={userFormData.email}
                                    onChange={(e) => setUserFormData({ ...userFormData, email: e.target.value })}
                                    placeholder="contoh@arika.com"
                                    required
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="userPassword">
                                    Password {editingUser && '(Kosongkan jika tidak ingin diubah)'}
                                  </Label>
                                  <Input
                                    id="userPassword"
                                    type="password"
                                    value={userFormData.password}
                                    onChange={(e) => setUserFormData({ ...userFormData, password: e.target.value })}
                                    placeholder={!editingUser ? 'Masukkan password minimal 6 karakter' : 'Kosongkan untuk tetap sama'}
                                    required={!editingUser}
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="userRole">Role</Label>
                                  <Select
                                    value={userFormData.role}
                                    onValueChange={(value) => setUserFormData({ ...userFormData, role: value })}
                                  >
                                    <SelectTrigger>
                                      <SelectValue placeholder="Pilih role pengguna" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="super_admin">Super Admin</SelectItem>
                                      <SelectItem value="admin">Front Desk</SelectItem>
                                      <SelectItem value="housekeeping">Housekeeping</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                              </div>
                              <div className="flex justify-end gap-3">
                                <Button
                                  type="button"
                                  variant="outline"
                                  onClick={() => setShowUserDialog(false)}
                                >
                                  Batal
                                </Button>
                                <Button
                                  type="submit"
                                  className="bg-emerald-600 hover:bg-emerald-700 text-white"
                                >
                                  {editingUser ? 'Update' : 'Tambah'}
                                </Button>
                              </div>
                            </form>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="rounded-md border border-stone-200 overflow-hidden">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-stone-50">
                              <TableHead>Nama</TableHead>
                              <TableHead>Email</TableHead>
                              <TableHead>Role</TableHead>
                              <TableHead className="text-right">Aksi</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {users.length === 0 ? (
                              <TableRow>
                                <TableCell colSpan={4} className="text-center text-stone-500 py-8">
                                  Belum ada pengguna. Klik "Tambah Pengguna" untuk membuat akun baru.
                                </TableCell>
                              </TableRow>
                            ) : (
                              users.map((u) => (
                                <TableRow key={u.id}>
                                  <TableCell className="font-medium">{u.name}</TableCell>
                                  <TableCell>{u.email}</TableCell>
                                  <TableCell>
                                    <span
                                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                        u.role === 'super_admin'
                                          ? 'bg-purple-100 text-purple-800'
                                          : u.role === 'admin'
                                          ? 'bg-blue-100 text-blue-800'
                                          : 'bg-green-100 text-green-800'
                                      }`}
                                    >
                                      {u.role === 'super_admin' ? 'Super Admin' :
                                       u.role === 'admin' ? 'Front Desk' : 'Housekeeping'}
                                    </span>
                                  </TableCell>
                                  <TableCell className="text-right">
                                    <div className="flex items-center justify-end gap-2">
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => openEditUserDialog(u)}
                                        className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                                      >
                                        <Edit className="w-4 h-4" />
                                      </Button>
                                      {u.role !== 'super_admin' && (
                                        <Button
                                          variant="ghost"
                                          size="sm"
                                          onClick={() => handleDeleteUser(u.id, u.name)}
                                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                        >
                                          <Trash2 className="w-4 h-4" />
                                        </Button>
                                      )}
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))
                            )}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              )}
            </Tabs>
          </div>
        )}
      </main>

      {/* Room Detail Dialog */}
      <Dialog open={showRoomDetailDialog} onOpenChange={setShowRoomDetailDialog}>
        <DialogContent className="bg-white max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">Detail Kamar {selectedRoom?.roomNumber}</DialogTitle>
            <DialogDescription>Informasi lengkap tentang kamar</DialogDescription>
          </DialogHeader>
          {selectedRoom && (
            <div className="space-y-6">
              {/* Room Image */}
              <div className="relative w-full h-64 md:h-80 rounded-lg overflow-hidden border border-stone-200 bg-stone-100">
                {selectedRoom.image ? (
                  <img
                    src={selectedRoom.image}
                    alt={`Kamar ${selectedRoom.roomNumber}`}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-stone-400">
                    <div className="text-center">
                      <Building2 className="w-16 h-16 mx-auto mb-2" />
                      <p>Tidak ada foto</p>
                    </div>
                  </div>
                )}
                <div className="absolute top-3 right-3">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    selectedRoom.status === 'Available' ? 'bg-emerald-500 text-white' :
                    selectedRoom.status === 'Booked' ? 'bg-red-500 text-white' :
                    'bg-amber-500 text-white'
                  }`}>
                    {selectedRoom.status === 'Available' ? 'Tersedia' :
                     selectedRoom.status === 'Booked' ? 'Terpesan' : 'Maintenance'}
                  </span>
                </div>
              </div>

              {/* Room Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold text-stone-900 mb-2">Informasi Dasar</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between py-2 border-b border-stone-100">
                        <span className="text-stone-600">Nomor Kamar</span>
                        <span className="font-medium">{selectedRoom.roomNumber}</span>
                      </div>
                      <div className="flex justify-between py-2 border-b border-stone-100">
                        <span className="text-stone-600">Tipe Kamar</span>
                        <span className="font-medium">{selectedRoom.type}</span>
                      </div>
                      <div className="flex justify-between py-2 border-b border-stone-100">
                        <span className="text-stone-600">Harga per Malam</span>
                        <span className="font-medium text-emerald-600">
                          Rp {selectedRoom.price.toLocaleString('id-ID')}
                        </span>
                      </div>
                      <div className="flex justify-between py-2 border-b border-stone-100">
                        <span className="text-stone-600">Status</span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          selectedRoom.status === 'Available' ? 'bg-emerald-100 text-emerald-700' :
                          selectedRoom.status === 'Booked' ? 'bg-red-100 text-red-700' :
                          'bg-amber-100 text-amber-700'
                        }`}>
                          {selectedRoom.status === 'Available' ? 'Tersedia' :
                           selectedRoom.status === 'Booked' ? 'Terpesan' : 'Maintenance'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-stone-900 mb-2">Deskripsi</h3>
                  <p className="text-stone-600 leading-relaxed">
                    {selectedRoom.description || 'Tidak ada deskripsi'}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4 border-t border-stone-200">
                {selectedRoom.status === 'Available' && (
                  <Button
                    onClick={() => {
                      setShowRoomDetailDialog(false)
                      openBookingDialog(selectedRoom.id)
                    }}
                    className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white"
                  >
                    <CalendarDays className="w-4 h-4 mr-2" />
                    Booking Kamar Ini
                  </Button>
                )}
                {(user?.role === 'super_admin' || user?.role === 'admin') && (
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowRoomDetailDialog(false)
                      openEditRoomDialog(selectedRoom)
                    }}
                    className="border-stone-300 text-stone-700"
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Edit Kamar
                  </Button>
                )}
                <Button
                  variant="outline"
                  onClick={() => setShowRoomDetailDialog(false)}
                  className="border-stone-300 text-stone-700"
                >
                  Tutup
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Footer */}
      <footer className="mt-auto bg-white border-t border-stone-200">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center text-stone-600">
            <p className="text-sm">© 2026 Arika Homestay. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Booking Dialog */}
      <Dialog open={showBookingDialog} onOpenChange={setShowBookingDialog}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle className="text-2xl">Booking Form</DialogTitle>
            <DialogDescription>
              Lengkapi informasi untuk reservasi kamar
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCreateBooking} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Check In</Label>
                <div className="p-3 bg-stone-50 rounded-md border border-stone-200">
                  {checkInDate ? format(checkInDate, 'PPP', { locale: id }) : '-'}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Check Out</Label>
                <div className="p-3 bg-stone-50 rounded-md border border-stone-200">
                  {checkOutDate ? format(checkOutDate, 'PPP', { locale: id }) : '-'}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Nama Lengkap</Label>
                <Input
                  value={bookingFormData.guestName}
                  onChange={(e) => setBookingFormData(prev => ({ ...prev, guestName: e.target.value }))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input
                  type="email"
                  value={bookingFormData.guestEmail}
                  onChange={(e) => setBookingFormData(prev => ({ ...prev, guestEmail: e.target.value }))}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>No. Telepon</Label>
              <Input
                value={bookingFormData.guestPhone}
                onChange={(e) => setBookingFormData(prev => ({ ...prev, guestPhone: e.target.value }))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label>Permintaan Khusus</Label>
              <Textarea
                placeholder="Contoh: Kamar lantai 2, tambahan handuk, dll."
                value={bookingFormData.specialRequests}
                onChange={(e) => setBookingFormData(prev => ({ ...prev, specialRequests: e.target.value }))}
                rows={3}
              />
            </div>

            <div className="pt-4 flex gap-3">
              <Button type="button" variant="outline" onClick={() => setShowBookingDialog(false)} className="flex-1 border-stone-300 text-stone-700">
                Batal
              </Button>
              <Button type="submit" className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white">
                Konfirmasi Booking
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Room Dialog */}
      <Dialog open={showRoomDialog} onOpenChange={setShowRoomDialog}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle className="text-2xl">
              {editingRoom ? 'Edit Kamar' : 'Tambah Kamar Baru'}
            </DialogTitle>
            <DialogDescription>
              {editingRoom ? 'Update informasi kamar' : 'Lengkapi informasi untuk menambah kamar baru'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={editingRoom ? handleUpdateRoom : handleCreateRoom} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Nomor Kamar</Label>
                <Input
                  value={roomFormData.roomNumber}
                  onChange={(e) => setRoomFormData(prev => ({ ...prev, roomNumber: e.target.value }))}
                  placeholder="Contoh: 101"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Tipe Kamar</Label>
                <Select value={roomFormData.type} onValueChange={(value) => setRoomFormData(prev => ({ ...prev, type: value }))}>
                  <SelectTrigger className="border-stone-300">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Standard">Standard</SelectItem>
                    <SelectItem value="Deluxe">Deluxe</SelectItem>
                    <SelectItem value="Suite">Suite</SelectItem>
                    <SelectItem value="Presidential">Presidential</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Harga per Malam (Rp)</Label>
              <Input
                type="number"
                value={roomFormData.price}
                onChange={(e) => setRoomFormData(prev => ({ ...prev, price: e.target.value }))}
                placeholder="Contoh: 500000"
                required
              />
            </div>

            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={roomFormData.status} onValueChange={(value) => setRoomFormData(prev => ({ ...prev, status: value }))}>
                <SelectTrigger className="border-stone-300">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Available">Available</SelectItem>
                  <SelectItem value="Booked">Booked</SelectItem>
                  <SelectItem value="Maintenance">Maintenance</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Deskripsi</Label>
              <Textarea
                placeholder="Deskripsi kamar, fasilitas, dll."
                value={roomFormData.description}
                onChange={(e) => setRoomFormData(prev => ({ ...prev, description: e.target.value }))}
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label>Foto Kamar</Label>
              <div className="space-y-3">
                {roomFormData.image && (
                  <div className="relative w-full h-48 rounded-lg overflow-hidden border border-stone-200">
                    <img
                      src={roomFormData.image}
                      alt="Preview kamar"
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => setRoomFormData(prev => ({ ...prev, image: '' }))}
                      className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full hover:bg-red-600"
                    >
                      <XCircle className="w-5 h-5" />
                    </button>
                  </div>
                )}
                <div className="flex items-center gap-3">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="flex-1"
                  />
                  {!roomFormData.image && (
                    <span className="text-sm text-stone-500">
                      Upload foto kamar (opsional)
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="pt-4 flex gap-3">
              <Button type="button" variant="outline" onClick={() => setShowRoomDialog(false)} className="flex-1 border-stone-300 text-stone-700">
                Batal
              </Button>
              <Button type="submit" className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white">
                {editingRoom ? 'Update' : 'Simpan'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
// Trigger recompile
